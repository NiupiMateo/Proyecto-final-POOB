package BadDopoCream.dominio;

import java.util.ArrayList;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.componentes.helados.HeladoVainilla;
import BadDopoCream.dominio.componentes.helados.HeladoFresa;
import BadDopoCream.dominio.componentes.helados.HeladoChocolate;
import BadDopoCream.dominio.componentes.frutas.Fruta;
import BadDopoCream.dominio.componentes.frutas.Uva;
import BadDopoCream.dominio.componentes.frutas.Platano;
import BadDopoCream.dominio.componentes.frutas.Pina;
import BadDopoCream.dominio.componentes.frutas.Cereza;
import BadDopoCream.dominio.componentes.enemigos.Enemigo;
import BadDopoCream.dominio.componentes.enemigos.Troll;
import BadDopoCream.dominio.componentes.enemigos.Maceta;
import BadDopoCream.dominio.componentes.enemigos.CalamarNaranja;

/**
 * Clase Nivel - Define la configuración de cada nivel (1, 2, 3).
 * Especifica: qué frutas hay, cuántos enemigos, tipos de enemigos, tamaño del tablero.
 * Nivel 1: Uvas y Plátanos, 2 Trolls (fácil)
 * Nivel 2: Piñas y Plátanos, 1 Maceta (medio)
 * Nivel 3: Piñas y Cerezas, 1 Calamar Naranja (difícil)
 */
public class Nivel {
    private int numeroNivel;
    private int ancho;
    private int alto;
    private String tipoHelado;
    private ArrayList<ConfiguracionFruta> frutas;
    private ArrayList<ConfiguracionEnemigo> enemigos;
    private Posicion posicionInicialHelado;
    
    /**
     * Constructor de Nivel
     * @param numeroNivel número del nivel (1, 2, 3)
     */
    public Nivel(int numeroNivel) {
        this.numeroNivel = numeroNivel;
        this.ancho = 15;
        this.alto = 12;
        this.frutas = new ArrayList<>();
        this.enemigos = new ArrayList<>();
        configurarNivel();
    }
    
    /**
     * Configura las características específicas de cada nivel
     */
    private void configurarNivel() {
        switch (numeroNivel) {
            case 1:
                configurarNivel1();
                break;
            case 2:
                configurarNivel2();
                break;
            case 3:
                configurarNivel3();
                break;
        }
    }
    
    /**
     * Configuración del Nivel 1: 8 Uvas, 8 Plátanos, 2 Trolls
     */
    private void configurarNivel1() {
        posicionInicialHelado = new Posicion(7, 6);
        
        // 8 Uvas
        for (int i = 0; i < 8; i++) {
            frutas.add(new ConfiguracionFruta("Uva"));
        }
        
        // 8 Plátanos
        for (int i = 0; i < 8; i++) {
            frutas.add(new ConfiguracionFruta("Platano"));
        }
        
        // 2 Trolls
        enemigos.add(new ConfiguracionEnemigo("Troll", new Posicion(2, 2)));
        enemigos.add(new ConfiguracionEnemigo("Troll", new Posicion(12, 9)));
    }
    
    /**
     * Configuración del Nivel 2: 8 Piñas, 8 Plátanos, 1 Maceta
     */
    private void configurarNivel2() {
        posicionInicialHelado = new Posicion(7, 6);
        
        // 8 Piñas
        for (int i = 0; i < 8; i++) {
            frutas.add(new ConfiguracionFruta("Pina"));
        }
        
        // 8 Plátanos
        for (int i = 0; i < 8; i++) {
            frutas.add(new ConfiguracionFruta("Platano"));
        }
        
        // 1 Maceta
        enemigos.add(new ConfiguracionEnemigo("Maceta", new Posicion(2, 2)));
    }
    
    /**
     * Configuración del Nivel 3: 8 Piñas, 8 Cerezas, 1 Calamar Naranja
     */
    private void configurarNivel3() {
        posicionInicialHelado = new Posicion(7, 6);
        
        // 8 Piñas
        for (int i = 0; i < 8; i++) {
            frutas.add(new ConfiguracionFruta("Pina"));
        }
        
        // 8 Cerezas
        for (int i = 0; i < 8; i++) {
            frutas.add(new ConfiguracionFruta("Cereza"));
        }
        
        // 1 Calamar Naranja
        enemigos.add(new ConfiguracionEnemigo("CalamarNaranja", new Posicion(2, 2)));
    }
    
    /**
     * Crea el tablero con toda la configuración del nivel.
     * Pasos: 1) Crea tablero vacío, 2) Coloca helado, 3) Coloca frutas en posiciones aleatorias,
     * 4) Coloca enemigos en posiciones definidas.
     * @param tipoHelado tipo de helado elegido por el jugador (Vainilla, Fresa, Chocolate)
     * @return tablero completamente configurado y listo para jugar
     */
    public Tablero crearTablero(String tipoHelado) {
        Tablero tablero = new Tablero(alto, ancho);
        
        // Crear helado
        Helado helado = crearHelado(tipoHelado, posicionInicialHelado);
        tablero.setHelado(helado);
        
        // Crear frutas
        for (ConfiguracionFruta config : frutas) {
            Posicion pos = obtenerPosicionAleatoria(tablero);
            Fruta fruta = crearFruta(config.tipo, pos);
            tablero.agregarFruta(fruta);
        }
        
        // Crear enemigos
        for (ConfiguracionEnemigo config : enemigos) {
            Enemigo enemigo = crearEnemigo(config.tipo, config.posicion);
            tablero.agregarEnemigo(enemigo);
        }
        
        return tablero;
    }
    
    /**
     * Crea un helado según el tipo especificado
     */
    private Helado crearHelado(String tipo, Posicion pos) {
        switch (tipo) {
            case "Vainilla":
                return new HeladoVainilla(pos);
            case "Fresa":
                return new HeladoFresa(pos);
            case "Chocolate":
                return new HeladoChocolate(pos);
            default:
                return new HeladoVainilla(pos);
        }
    }
    
    /**
     * Crea una fruta según el tipo especificado
     */
    private Fruta crearFruta(String tipo, Posicion pos) {
        switch (tipo) {
            case "Uva":
                return new Uva(pos);
            case "Platano":
                return new Platano(pos);
            case "Pina":
                return new Pina(pos);
            case "Cereza":
                return new Cereza(pos);
            default:
                return new Uva(pos);
        }
    }
    
    /**
     * Crea un enemigo según el tipo especificado
     */
    private Enemigo crearEnemigo(String tipo, Posicion pos) {
        switch (tipo) {
            case "Troll":
                return new Troll(pos);
            case "Maceta":
                return new Maceta(pos);
            case "CalamarNaranja":
                return new CalamarNaranja(pos);
            default:
                return new Troll(pos);
        }
    }
    
    /**
     * Obtiene una posición aleatoria válida en el tablero
     */
    private Posicion obtenerPosicionAleatoria(Tablero tablero) {
        java.util.Random random = new java.util.Random();
        Posicion pos;
        int intentos = 0;
        do {
            int x = random.nextInt(ancho);
            int y = random.nextInt(alto);
            pos = new Posicion(x, y);
            intentos++;
        } while (!tablero.esPosicionVacia(pos) && intentos < 100);
        return pos;
    }
    
    public int getNumeroNivel() {
        return numeroNivel;
    }
    
    /**
     * Clase interna para configuración de frutas
     */
    private class ConfiguracionFruta {
        String tipo;
        
        ConfiguracionFruta(String tipo) {
            this.tipo = tipo;
        }
    }
    
    /**
     * Clase interna para configuración de enemigos
     */
    private class ConfiguracionEnemigo {
        String tipo;
        Posicion posicion;
        
        ConfiguracionEnemigo(String tipo, Posicion posicion) {
            this.tipo = tipo;
            this.posicion = posicion;
        }
    }
}

