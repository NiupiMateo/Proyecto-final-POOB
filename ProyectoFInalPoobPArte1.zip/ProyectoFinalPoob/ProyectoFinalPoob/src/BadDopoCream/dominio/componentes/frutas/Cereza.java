package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;

import java.util.Random;

/**
 * Fruta Cereza.
 *
 * Es la fruta más difícil de atrapar del nivel 3.
 * A diferencia de otras frutas, la Cereza se teletransporta
 * a posiciones aleatorias del tablero.
 *
 * Comportamiento:
 * - Cada 3 segundos (180 frames) se teletransporta.
 * - Aparece en una nueva posición vacía aleatoria.
 * - El jugador debe ser rápido para recolectarla.
 *
 * Otorga 30 puntos al ser recolectada.
 */
public class Cereza extends Fruta {
    /** Generador de números aleatorios para teletransporte */
    private Random random;
    
    /** Contador de frames para controlar el teletransporte */
    private int contadorTeletransporte;
    
    /** Tiempo entre teletransportes (aprox 3 segundos) */
    private static final int TIEMPO_TELETRANSPORTE = 180;
    
    /**
     * Constructor de la Cereza.
     *
     * @param posicion posición inicial de la cereza en el tablero
     */
    public Cereza(Posicion posicion) {
        super(posicion, 30);
        this.random = new Random();
        this.contadorTeletransporte = 0;
    }
    
    /**
     * Actualiza el estado de la cereza.
     *
     * Incrementa el contador de teletransporte en cada frame.
     */
    @Override
    public void actualizar() {
        contadorTeletransporte++;
    }
    
    /**
     * Verifica si la cereza debe teletransportarse.
     *
     * @return true si ha pasado suficiente tiempo, false en caso contrario
     */
    public boolean debeTeletransportarse() {
        return contadorTeletransporte >= TIEMPO_TELETRANSPORTE;
    }
    
    /**
     * Teletransporta la cereza a una nueva posición aleatoria.
     *
     * Busca una posición vacía aleatoria en el tablero (hasta 100 intentos).
     * Si encuentra una posición válida, mueve la cereza y resetea el contador.
     *
     * @param tablero tablero del juego donde se teletransporta
     */
    public void teletransportar(Tablero tablero) {
        Posicion nuevaPos;
        int intentos = 0;
        do {
            int x = random.nextInt(tablero.getColumnas());
            int y = random.nextInt(tablero.getFilas());
            nuevaPos = new Posicion(x, y);
            intentos++;
        } while (!tablero.esPosicionVacia(nuevaPos) && intentos < 100);
        
        if (intentos < 100) {
            // Mover en la matriz del tablero
            tablero.moverComponente(posicion, nuevaPos);
            this.posicion = nuevaPos;
            contadorTeletransporte = 0;
        }
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Cereza"
     */
    @Override
    public String getTipo() {
        return "Cereza";
    }
}


