package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;

import java.util.Random;

/**
 * Fruta Piña.
 *
 * Es una fruta móvil presente en niveles 2 y 3.
 * A diferencia de Uva y Plátano, la Piña se mueve constantemente.
 *
 * Comportamiento:
 * - Se mueve en una dirección aleatoria cada 20 frames.
 * - Cambia de dirección cuando choca con un obstáculo.
 * - También puede cambiar de dirección aleatoriamente (30% de probabilidad).
 *
 * Otorga 20 puntos al ser recolectada.
 */
public class Pina extends Fruta {
    /** Dirección actual del movimiento de la piña */
    private Direccion direccionActual;
    
    /** Generador de números aleatorios para movimiento */
    private Random random;
    
    /** Contador de frames para controlar velocidad de movimiento */
    private int contadorMovimiento;
    
    /** Velocidad de movimiento (frames entre cada movimiento) */
    private static final int VELOCIDAD = 20;
    
    /**
     * Constructor de la Piña.
     *
     * @param posicion posición inicial de la piña en el tablero
     */
    public Pina(Posicion posicion) {
        super(posicion, 20);
        this.random = new Random();
        int[] direcciones = {Direccion.ARRIBA, Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.DERECHA};
        this.direccionActual = new Direccion(direcciones[random.nextInt(4)]);
        this.contadorMovimiento = 0;
    }
    
    /**
     * Actualiza el estado de la piña.
     *
     * Incrementa el contador de movimiento y cada VELOCIDAD frames
     * puede cambiar de dirección aleatoriamente (30% de probabilidad).
     */
    @Override
    public void actualizar() {
        contadorMovimiento++;
        if (contadorMovimiento >= VELOCIDAD) {
            contadorMovimiento = 0;
            // Cambiar dirección aleatoriamente a veces (30% de probabilidad)
            if (random.nextInt(10) < 3) {
                int[] direcciones = {Direccion.ARRIBA, Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.DERECHA};
                direccionActual = new Direccion(direcciones[random.nextInt(4)]);
            }
        }
    }
    
    /**
     * Mueve la piña en el tablero.
     *
     * Intenta moverse en la dirección actual.
     * Si encuentra un obstáculo o borde, cambia a la dirección opuesta.
     *
     * @param tablero tablero del juego donde se mueve la piña
     */
    public void mover(Tablero tablero) {
        Posicion nuevaPos = direccionActual.mover(posicion);
        if (tablero.esPosicionValida(nuevaPos)) {
            Celda celdaDestino = tablero.getCelda(nuevaPos);
            if (celdaDestino != null && celdaDestino.esTransitable() && !celdaDestino.tieneComponente()) {
                tablero.moverComponente(posicion, nuevaPos);
                this.posicion = nuevaPos;
            } else {
                // Cambiar dirección si choca con obstáculo
                direccionActual = direccionActual.opuesta();
            }
        } else {
            // Cambiar dirección si choca con borde del tablero
            direccionActual = direccionActual.opuesta();
        }
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Pina"
     */
    @Override
    public String getTipo() {
        return "Pina";
    }
}


