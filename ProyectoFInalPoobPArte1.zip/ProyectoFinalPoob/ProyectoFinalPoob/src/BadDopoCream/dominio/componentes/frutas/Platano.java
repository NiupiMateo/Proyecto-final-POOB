package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Fruta Plátano.
 *
 * Es una fruta estática presente en niveles 1 y 2.
 * No se mueve durante el juego, permanece en su posición inicial.
 * Otorga 15 puntos al ser recolectada.
 */
public class Platano extends Fruta {
    
    /**
     * Constructor del Plátano.
     *
     * @param posicion posición inicial del plátano en el tablero
     */
    public Platano(Posicion posicion) {
        super(posicion, 15);
    }
    
    /**
     * Actualiza el estado del plátano.
     * Los plátanos no tienen comportamiento dinámico (no se mueven).
     */
    @Override
    public void actualizar() {
        // Los plátanos no se mueven
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Platano"
     */
    @Override
    public String getTipo() {
        return "Platano";
    }
}


