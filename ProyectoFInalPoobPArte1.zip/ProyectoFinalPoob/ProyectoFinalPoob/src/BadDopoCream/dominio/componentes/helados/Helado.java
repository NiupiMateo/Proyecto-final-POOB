package BadDopoCream.dominio.componentes.helados;

import java.util.ArrayList;
import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.tablero.BloqueHielo;
import BadDopoCream.dominio.tablero.TipoCelda;

/**
 * Clase abstracta Helado.
 *
 * Representa al personaje principal del juego (el jugador).
 *
 * Capacidades del helado:
 * - Moverse en 4 direcciones (arriba, abajo, izquierda, derecha).
 * - Crear bloques de hielo en la dirección hacia donde mira.
 * - Romper bloques de hielo con efecto dominó.
 *
 * Objetivo:
 * Recolectar todas las frutas del nivel sin tocar enemigos
 * y antes de que se acabe el tiempo.
 *
 * Sabores disponibles:
 * - Vainilla (color blanco)
 * - Fresa (color rosado)
 * - Chocolate (color café)
 */
public abstract class Helado extends Componente {
    /** Dirección actual hacia donde mira el helado */
    protected Direccion direccion;
    
    /** Vidas restantes del helado (inicia con 3) */
    protected int vidas;
    
    /** Puntaje acumulado al recolectar frutas */
    protected int puntaje;
    
    /** Lista de bloques de hielo creados por el helado */
    protected ArrayList<BloqueHielo> bloquesCreados;
    
    /**
     * Constructor del Helado.
     *
     * @param posicion posición inicial del helado en el tablero
     */
    public Helado(Posicion posicion) {
        super(posicion);
        this.direccion = new Direccion(Direccion.ABAJO);
        this.vidas = 3;
        this.puntaje = 0;
        this.bloquesCreados = new ArrayList<>();
    }
    
    /**
     * Mueve el helado en una dirección específica.
     *
     * Verifica que:
     * 1. La nueva posición esté dentro de los límites del tablero.
     * 2. La celda destino sea transitable (no sea muro ni bloque de hielo).
     *
     * Si ambas condiciones se cumplen, actualiza la posición
     * del helado en la matriz del tablero.
     *
     * @param dir dirección del movimiento (ARRIBA/ABAJO/IZQUIERDA/DERECHA)
     * @param tablero tablero del juego
     * @return true si se movió exitosamente, false si encontró un obstáculo
     */
    public boolean mover(Direccion dir, Tablero tablero) {
        this.direccion = dir;
        Posicion nuevaPos = dir.mover(posicion);
        
        if (tablero.esPosicionValida(nuevaPos)) {
            Celda celdaDestino = tablero.getCelda(nuevaPos);
            if (celdaDestino != null && celdaDestino.esTransitable()) {
                // Mover en la matriz
                tablero.moverComponente(posicion, nuevaPos);
                this.posicion = nuevaPos;
                return true;
            }
        }
        return false;
    }
    
    /**
     * Crea un bloque de hielo en la dirección actual del helado.
     *
     * El bloque solo se crea si:
     * 1. La posición está dentro de los límites del tablero.
     * 2. La celda está completamente vacía (sin enemigos, frutas ni bloques).
     *
     * El bloque creado se agrega al tablero y a la lista
     * de bloques creados por el helado.
     *
     * @param tablero tablero del juego
     * @return true si se creó el bloque, false si no se pudo crear
     */
    public boolean crearBloque(Tablero tablero) {
        Posicion posBloque = direccion.mover(posicion);
        
        if (tablero.esPosicionValida(posBloque) && 
            tablero.esPosicionVacia(posBloque) &&
            !tablero.hayBloqueEn(posBloque)) {
            
            BloqueHielo bloque = new BloqueHielo(posBloque);
            tablero.agregarBloque(bloque);
            bloquesCreados.add(bloque);
            return true;
        }
        return false;
    }
    
    /**
     * Rompe bloques de hielo con efecto dominó.
     *
     * Comportamiento:
     * Avanza en la dirección actual del helado rompiendo todos
     * los bloques de hielo consecutivos que encuentre.
     * 
     * Se detiene cuando encuentra una celda vacía, un muro
     * o el límite del tablero. Puede destruir varios bloques
     * de una vez.
     *
     * @param tablero tablero del juego
     */
    public void romperBloques(Tablero tablero) {
        Posicion posActual = direccion.mover(posicion);
        
        while (tablero.esPosicionValida(posActual) && tablero.hayBloqueEn(posActual)) {
            tablero.eliminarBloqueEn(posActual);
            posActual = direccion.mover(posActual);
        }
    }
    
    /**
     * Obtiene la dirección actual del helado.
     *
     * @return dirección hacia donde mira el helado
     */
    public Direccion getDireccion() {
        return direccion;
    }
    
    /**
     * Obtiene el puntaje acumulado.
     *
     * @return puntaje actual del helado
     */
    public int getPuntaje() {
        return puntaje;
    }
    
    /**
     * Añade puntos al puntaje del helado.
     * Se llama cuando recolecta una fruta.
     *
     * @param puntos cantidad de puntos a agregar
     */
    public void agregarPuntaje(int puntos) {
        this.puntaje += puntos;
    }
    
    /**
     * Obtiene las vidas restantes del helado.
     *
     * @return número de vidas actuales
     */
    public int getVidas() {
        return vidas;
    }
    
    /**
     * Reduce las vidas del helado en 1.
     * Se llama cuando el helado colisiona con un enemigo.
     */
    public void perderVida() {
        this.vidas--;
    }
    
    /**
     * Actualiza el estado del helado.
     * Lógica básica de actualización en cada frame.
     */
    @Override
    public void actualizar() {
        // Lógica de actualización básica
    }
    
    /**
     * Obtiene el color del helado.
     *
     * @return cadena con el color (para renderizado)
     */
    public abstract String getColor();
}

