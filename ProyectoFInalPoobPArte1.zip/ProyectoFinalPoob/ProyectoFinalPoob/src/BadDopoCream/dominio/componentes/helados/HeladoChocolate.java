package BadDopoCream.dominio.componentes.helados;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Helado de Chocolate.
 *
 * Es uno de los tres sabores disponibles para el jugador.
 * Su color característico es café oscuro.
 */
public class HeladoChocolate extends Helado {
    
    /**
     * Constructor del Helado de Chocolate.
     *
     * @param posicion posición inicial en el tablero
     */
    public HeladoChocolate(Posicion posicion) {
        super(posicion);
    }
    
    /**
     * Retorna el tipo de helado.
     *
     * @return "HeladoChocolate"
     */
    @Override
    public String getTipo() {
        return "HeladoChocolate";
    }
    
    /**
     * Retorna el color del helado.
     *
     * @return "cafe"
     */
    @Override
    public String getColor() {
        return "cafe";
    }
}


