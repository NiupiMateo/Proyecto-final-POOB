package BadDopoCream.dominio.tablero;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase que representa un bloque de hielo creado por el helado.
 * Los bloques pueden ser destruidos por el helado (efecto dominó) o por ciertos enemigos.
 * Se usan como obstáculos y estrategia para atrapar enemigos.
 */
public class BloqueHielo {
    private Posicion posicion;
    private boolean destruible;
    
    /**
     * Constructor de BloqueHielo
     * @param posicion posición del bloque
     */
    public BloqueHielo(Posicion posicion) {
        this.posicion = posicion;
        this.destruible = true;
    }
    
    /**
     * Obtiene la posición del bloque
     * @return posición del bloque
     */
    public Posicion getPosicion() {
        return posicion;
    }
    
    /**
     * Verifica si el bloque es destruible
     * @return true si es destruible
     */
    public boolean isDestruible() {
        return destruible;
    }
    
    /**
     * Establece si el bloque es destruible
     * @param destruible nuevo estado
     */
    public void setDestruible(boolean destruible) {
        this.destruible = destruible;
    }
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        BloqueHielo bloque = (BloqueHielo) obj;
        return posicion.equals(bloque.posicion);
    }
}


