package BadDopoCream.dominio.tablero;

import java.util.ArrayList;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.componentes.enemigos.Enemigo;
import BadDopoCream.dominio.componentes.frutas.Fruta;
import BadDopoCream.dominio.componentes.frutas.Pina;
import BadDopoCream.dominio.componentes.frutas.Cereza;

/**
 * Clase Tablero - Representa el campo de juego completo con estructura de matriz de Celdas.
 * Organización: Matriz de Celda[filas][columnas] donde cada celda puede contener componentes.
 * Los componentes son: Helado (jugador), Enemigos (Troll, Maceta, Calamar) y Frutas (Uva, Plátano, Piña, Cereza).
 * Contiene y administra: helado, enemigos, frutas y bloques de hielo.
 * Responsable de: detectar colisiones, verificar recolecciones, actualizar componentes.
 * Los bordes del tablero son muros permanentes.
 */
public class Tablero {
    private int filas;
    private int columnas;
    private Celda[][] matriz;
    private ArrayList<Fruta> frutas;
    private ArrayList<Enemigo> enemigos;
    private Helado helado;
    
    /**
     * Constructor del Tablero con matriz de Celdas.
     * Inicializa la matriz y coloca muros en los bordes.
     * @param filas número de filas del tablero
     * @param columnas número de columnas del tablero
     */
    public Tablero(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        this.matriz = new Celda[filas][columnas];
        this.frutas = new ArrayList<>();
        this.enemigos = new ArrayList<>();
        inicializarMatriz();
    }
    
    /**
     * Inicializa la matriz de celdas.
     * Crea todas las celdas: muros en los bordes, vacías en el interior.
     */
    private void inicializarMatriz() {
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                Posicion pos = new Posicion(col, fila);
                
                // Colocar muros en los bordes
                if (fila == 0 || fila == filas - 1 || col == 0 || col == columnas - 1) {
                    matriz[fila][col] = new Celda(pos, TipoCelda.MURO);
                } else {
                    matriz[fila][col] = new Celda(pos, TipoCelda.VACIO);
                }
            }
        }
    }
    
    /**
     * Obtiene el número de columnas del tablero
     * @return columnas
     */
    public int getColumnas() {
        return columnas;
    }
    
    /**
     * Obtiene el número de filas del tablero
     * @return filas
     */
    public int getFilas() {
        return filas;
    }
    
    /**
     * Obtiene la matriz completa de celdas
     * @return matriz de celdas
     */
    public Celda[][] getMatriz() {
        return matriz;
    }
    
    /**
     * Obtiene una celda específica
     * @param pos posición de la celda
     * @return celda en esa posición
     */
    public Celda getCelda(Posicion pos) {
        if (esPosicionValida(pos)) {
            return matriz[pos.getY()][pos.getX()];
        }
        return null;
    }
    
    // Métodos de compatibilidad con código antiguo
    public int getAncho() {
        return columnas;
    }
    
    public int getAlto() {
        return filas;
    }
    
    /**
     * Establece el helado jugador y lo coloca en el tablero
     * @param helado helado jugador
     */
    public void setHelado(Helado helado) {
        this.helado = helado;
        if (helado != null) {
            Posicion pos = helado.getPosicion();
            if (esPosicionValida(pos)) {
                matriz[pos.getY()][pos.getX()].setComponente(helado);
            }
        }
    }
    
    /**
     * Obtiene el helado jugador
     * @return helado
     */
    public Helado getHelado() {
        return helado;
    }
    
    /**
     * Agrega una fruta al tablero (lista y celda)
     * @param fruta fruta a agregar
     */
    public void agregarFruta(Fruta fruta) {
        frutas.add(fruta);
        Posicion pos = fruta.getPosicion();
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].setComponente(fruta);
        }
    }
    
    /**
     * Agrega un enemigo al tablero (lista y celda)
     * @param enemigo enemigo a agregar
     */
    public void agregarEnemigo(Enemigo enemigo) {
        enemigos.add(enemigo);
        Posicion pos = enemigo.getPosicion();
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].setComponente(enemigo);
        }
    }
    
    /**
     * Agrega un bloque de hielo al tablero
     * @param bloque bloque a agregar (ahora se maneja directamente en la celda)
     */
    public void agregarBloque(BloqueHielo bloque) {
        Posicion pos = bloque.getPosicion();
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].getTipo().setTipo(TipoCelda.BLOQUE_HIELO);
        }
    }
    
    /**
     * Obtiene todas las frutas del tablero
     * @return lista de frutas
     */
    public ArrayList<Fruta> getFrutas() {
        return frutas;
    }
    
    /**
     * Obtiene todos los enemigos del tablero
     * @return lista de enemigos
     */
    public ArrayList<Enemigo> getEnemigos() {
        return enemigos;
    }
    
    /**
     * Obtiene todos los bloques del tablero (recorre la matriz)
     * @return lista de posiciones con bloques de hielo
     */
    public ArrayList<Posicion> getBloques() {
        ArrayList<Posicion> bloques = new ArrayList<>();
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                if (matriz[fila][col].getTipo().esBloqueHielo()) {
                    bloques.add(new Posicion(col, fila));
                }
            }
        }
        return bloques;
    }
    
    /**
     * Verifica si una posición está dentro del tablero
     * @param pos posición a verificar
     * @return true si es válida (dentro de los límites)
     */
    public boolean esPosicionValida(Posicion pos) {
        return pos.getX() >= 0 && pos.getX() < columnas &&
               pos.getY() >= 0 && pos.getY() < filas;
    }
    
    /**
     * Verifica si hay un bloque de hielo en una posición
     * @param pos posición a verificar
     * @return true si hay un bloque
     */
    public boolean hayBloqueEn(Posicion pos) {
        if (!esPosicionValida(pos)) return false;
        return matriz[pos.getY()][pos.getX()].getTipo().esBloqueHielo();
    }
    
    /**
     * Elimina un bloque de hielo en una posición específica
     * @param pos posición del bloque a eliminar
     */
    public void eliminarBloqueEn(Posicion pos) {
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].getTipo().setTipo(TipoCelda.VACIO);
        }
    }
    
    /**
     * Verifica si una posición está completamente vacía (sin bloques, muros, enemigos ni frutas)
     * @param pos posición a verificar
     * @return true si está vacía y transitable
     */
    public boolean esPosicionVacia(Posicion pos) {
        if (!esPosicionValida(pos)) return false;
        
        Celda celda = matriz[pos.getY()][pos.getX()];
        
        // Verificar que no sea muro ni bloque
        if (!celda.getTipo().esVacio()) return false;
        
        // Verificar que no tenga componente
        if (celda.tieneComponente()) return false;
        
        return true;
    }
    
    /**
     * Mueve un componente de una posición a otra en la matriz
     * @param origen posición origen
     * @param destino posición destino
     */
    public void moverComponente(Posicion origen, Posicion destino) {
        if (!esPosicionValida(origen) || !esPosicionValida(destino)) return;
        
        Celda celdaOrigen = matriz[origen.getY()][origen.getX()];
        Celda celdaDestino = matriz[destino.getY()][destino.getX()];
        
        // Mover el componente
        Componente componente = celdaOrigen.getComponente();
        if (componente != null) {
            celdaDestino.setComponente(componente);
            celdaOrigen.removerComponente();
        }
    }
    
    /**
     * Verifica si el helado colisiona con algún enemigo
     * @return true si hay colisión
     */
    public boolean hayColisionConEnemigo() {
        if (helado == null) return false;
        
        Posicion posHelado = helado.getPosicion();
        for (Enemigo enemigo : enemigos) {
            if (enemigo.isActiva() && enemigo.getPosicion().equals(posHelado)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Verifica y recolecta frutas en la posición del helado
     */
    public void verificarRecoleccionFrutas() {
        if (helado == null) return;
        
        Posicion posHelado = helado.getPosicion();
        for (Fruta fruta : frutas) {
            if (fruta.isActiva() && fruta.getPosicion().equals(posHelado)) {
                fruta.recolectar();
                helado.agregarPuntaje(fruta.getPuntaje());
            }
        }
    }
    
    /**
     * Cuenta las frutas activas restantes
     * @return número de frutas sin recolectar
     */
    public int contarFrutasActivas() {
        int contador = 0;
        for (Fruta fruta : frutas) {
            if (fruta.isActiva()) {
                contador++;
            }
        }
        return contador;
    }
    
    /**
     * Actualiza todos los componentes del tablero cada frame.
     * 1. Actualiza frutas (mueve piñas, teletransporta cerezas)
     * 2. Actualiza enemigos (calcula y ejecuta movimientos)
     * 3. Verifica si el helado recogió frutas
     */
    public void actualizar() {
        // Actualizar frutas
        for (Fruta fruta : frutas) {
            if (fruta.isActiva()) {
                fruta.actualizar();
                
                // Lógica especial para frutas que se mueven
                if (fruta instanceof Pina) {
                    ((Pina) fruta).mover(this);
                } else if (fruta instanceof Cereza) {
                    Cereza cereza = (Cereza) fruta;
                    if (cereza.debeTeletransportarse()) {
                        cereza.teletransportar(this);
                    }
                }
            }
        }
        
        // Actualizar enemigos
        for (Enemigo enemigo : enemigos) {
            if (enemigo.isActiva()) {
                enemigo.actualizar();
                enemigo.calcularMovimiento(this, helado);
            }
        }
        
        // Verificar recolección de frutas
        verificarRecoleccionFrutas();
    }
    
    /**
     * Limpia todos los bloques del tablero
     */
    public void limpiarBloques() {
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                if (matriz[fila][col].getTipo().esBloqueHielo()) {
                    matriz[fila][col].getTipo().setTipo(TipoCelda.VACIO);
                }
            }
        }
    }
}

