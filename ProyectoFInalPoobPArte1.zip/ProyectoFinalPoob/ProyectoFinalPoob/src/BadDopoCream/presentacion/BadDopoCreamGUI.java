package BadDopoCream.presentacion;

import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import java.awt.Color;
import javax.swing.SwingConstants;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JOptionPane;
import BadDopoCream.dominio.Juego;

/**
 * Clase principal de la interfaz gráfica del juego Bad Dopo Cream.
 * Gestiona la ventana principal y la navegación entre diferentes pantallas:
 * - Pantalla de inicio (bienvenida)
 * - Menú principal (jugar, configuración, salir)
 * - Selección de modo de juego (PvsP, PvsM, MvsM)
 * - Panel de juego (tablero interactivo)
 * 
 * @author Camilo Aguirre-Mateo Sanchez
 * @version 2025/11/24
 */
public class BadDopoCreamGUI extends JFrame {

    private static final long serialVersionUID = 1L;

    /** Panel de la pantalla inicial (bienvenida) */
    private JPanel panelInicio;
    
    /** Panel del menú principal (Jugar/Configuración/Salir) */
    private JPanel panelModos;
    
    /** Panel de selección de modo de juego */
    private JPanel panelSeleccionModo;
    
    /** Panel donde se renderiza el juego */
    private TableroPanel panelJuego;
    
    /** Instancia de la lógica del juego */
    private Juego juego;
    
    /** Modo de juego actual */
    private String modoJuegoActual;

    /**
     * Constructor de la interfaz gráfica principal.
     * <p>
     * Inicializa la ventana con dimensiones 900x700 píxeles,
     * crea los tres paneles de navegación (inicio, modos, selección)
     * y configura todos los eventos de botones y ventana.
     * </p>
     */
    public BadDopoCreamGUI() {
        // Configuración básica de la ventana
        setTitle("Bad Dopo Cream");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null); // Centrar en pantalla
        setResizable(false); // Tamaño fijo
        getContentPane().setLayout(null); // Layout absoluto

        // Panel de inicio (Pantalla 1 Inicio de juego)
        panelInicio = new JPanel();
        panelInicio.setLayout(null);
        panelInicio.setBounds(0, 0, 900, 700);
        panelInicio.setOpaque(false); // Transparente para mostrar fondo

        // Título principal del juego
        JLabel titulo = new JLabel("BAD DOPO CREAM");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 40));
        titulo.setForeground(Color.BLACK);
        titulo.setBounds(250, 37, 450, 50);
        panelInicio.add(titulo);

        // Botón para iniciar navegación
        JButton botonStart = new JButton("Click Para Empezar");
        botonStart.setVerticalAlignment(SwingConstants.BOTTOM);
        botonStart.setFont(new Font("Segoe UI", Font.BOLD, 16));
        botonStart.setBounds(320, 623, 250, 28);
        botonStart.setBackground(Color.LIGHT_GRAY);
        botonStart.setForeground(Color.BLACK);
        botonStart.setFocusPainted(false);
        panelInicio.add(botonStart);

        // Cargar y escalar imagen de fondo
        ImageIcon imagenOriginal = new ImageIcon(
            getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg")
        );
        
        // Escalar imagen a 700x500 con interpolación suave
        java.awt.Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
        ImageIcon fondo = new ImageIcon(imagenEscalada);

        // Agregar imagen de fondo al panel
        JLabel fondoLabel = new JLabel(fondo);
        fondoLabel.setBounds(100, 100, 700, 500);
        panelInicio.add(fondoLabel);

        // Agregar panel de inicio al contenedor principal
        getContentPane().add(panelInicio);

        //Panel modos (Pantalla 2 - Menú Principal)
        panelModos = new JPanel();
        panelModos.setLayout(null);
        panelModos.setBounds(0, 0, 900, 700);
        panelModos.setOpaque(false);

        JLabel tituloModos = new JLabel("BAD DOPO CREAM");
        tituloModos.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tituloModos.setForeground(Color.BLACK);
        tituloModos.setBounds(250, 37, 450, 50);
        panelModos.add(tituloModos);

        // Botón para ir a selección de modo de juego
        JButton botonJugar = new JButton("Jugar");
        botonJugar.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonJugar.setBounds(200, 610, 150, 35);
        botonJugar.setBackground(Color.LIGHT_GRAY);
        botonJugar.setForeground(Color.BLACK);
        botonJugar.setFocusPainted(false);
        panelModos.add(botonJugar);

        // Botón para acceder a configuración (futuro: volumen, controles, etc.)
        JButton botonConfig = new JButton("Configuración");
        botonConfig.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonConfig.setBounds(370, 610, 180, 35);
        botonConfig.setBackground(Color.LIGHT_GRAY);
        botonConfig.setForeground(Color.BLACK);
        botonConfig.setFocusPainted(false);
        panelModos.add(botonConfig);

        // Botón para salir del juego con confirmación
        JButton botonSalir = new JButton("Salir");
        botonSalir.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonSalir.setBounds(570, 610, 150, 35);
        botonSalir.setBackground(Color.LIGHT_GRAY);
        botonSalir.setForeground(Color.BLACK);
        botonSalir.setFocusPainted(false);
        panelModos.add(botonSalir);

        // Agregar misma imagen de fondo que panel de inicio
        JLabel fondoModos = new JLabel(fondo);
        fondoModos.setBounds(100, 100, 700, 500);
        panelModos.add(fondoModos);

        // Ocultar panel hasta que se navegue a él
        panelModos.setVisible(false);
        getContentPane().add(panelModos);

        // Panel de seleccion modo de juego (Pantalla 3)
        panelSeleccionModo = new JPanel();
        panelSeleccionModo.setLayout(null);
        panelSeleccionModo.setBounds(0, 0, 900, 700);
        panelSeleccionModo.setOpaque(false);

        JLabel tituloSeleccion = new JLabel("Selecciona un modo");
        tituloSeleccion.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tituloSeleccion.setForeground(Color.BLACK);
        tituloSeleccion.setBounds(200, 37, 550, 50);
        panelSeleccionModo.add(tituloSeleccion);

        // Botón para modo Jugador vs Jugador (dos jugadores humanos)
        JButton botonPvsP = new JButton("Jugador vs Jugador");
        botonPvsP.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonPvsP.setBounds(300, 200, 300, 45);
        botonPvsP.setBackground(Color.LIGHT_GRAY);
        botonPvsP.setForeground(Color.BLACK);
        botonPvsP.setFocusPainted(false);
        panelSeleccionModo.add(botonPvsP);

        // Botón para modo Jugador vs Máquina (jugador humano vs enemigos IA)
        JButton botonPvsM = new JButton("Jugador vs Maquina");
        botonPvsM.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonPvsM.setBounds(300, 280, 300, 45);
        botonPvsM.setBackground(Color.LIGHT_GRAY);
        botonPvsM.setForeground(Color.BLACK);
        botonPvsM.setFocusPainted(false);
        panelSeleccionModo.add(botonPvsM);

        // Botón para modo Máquina vs Máquina (simulación automática)
        JButton botonMvsM = new JButton("Maquina vs Maquina");
        botonMvsM.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonMvsM.setBounds(300, 360, 300, 45);
        botonMvsM.setBackground(Color.LIGHT_GRAY);
        botonMvsM.setForeground(Color.BLACK);
        botonMvsM.setFocusPainted(false);
        panelSeleccionModo.add(botonMvsM);

        // Botón para regresar al menú principal
        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 440, 300, 45);
        botonVolver.setBackground(Color.LIGHT_GRAY);
        botonVolver.setForeground(Color.BLACK);
        botonVolver.setFocusPainted(false);
        panelSeleccionModo.add(botonVolver);

        // Mantener mismo fondo
        JLabel fondoSeleccion = new JLabel(fondo);
        fondoSeleccion.setBounds(100, 100, 700, 500);
        panelSeleccionModo.add(fondoSeleccion);

        panelSeleccionModo.setVisible(false);
        getContentPane().add(panelSeleccionModo);

   
        //Iniciar navegación (Del Inicio al Menú Principal)
        botonStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelInicio.setVisible(false);
                panelModos.setVisible(true);
            }
        });
        //Configuracion de las acciones del juego
        //Ir a selección de modo (Del Menú a Selección)
        botonJugar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelModos.setVisible(false);
                panelSeleccionModo.setVisible(true);
            }
        });

        //Abrir configuración (para futuro desarrollo)
        botonConfig.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Implementacion del panel de configuración. Tenemos ideas como sonido musica dificultad ect..
          
                System.out.println("Configuración");
            }
        });

        // Salir del juego con confirmación
        botonSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(
                    BadDopoCreamGUI.this, 
                    "¿Estás seguro que deseas salir del juego?", 
                    "Salir del Juego",
                    JOptionPane.YES_NO_OPTION
                );
                
                if (confirmar == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

        //Iniciar juego en modo Jugador vs Jugador
        botonPvsP.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarJuego("PvsP");
            }
        });

        // Acción: Iniciar juego en modo Jugador vs Máquina
        botonPvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarJuego("PvsM");
            }
        });

        // Acción: Iniciar juego en modo Máquina vs Máquina
        botonMvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                iniciarJuego("MvsM");
            }
        });

        // Acción: Volver al menú principal
        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionModo.setVisible(false);
                panelModos.setVisible(true);
            }
        });
        
        // Configurar comportamiento al cerrar ventana
        prepareActions();
    }
    
    /**
     * Inicia el juego con el modo seleccionado.
     * @param modoJuego modo seleccionado: "PvsP", "PvsM" o "MvsM"
     */
    private void iniciarJuego(String modoJuego) {
        modoJuegoActual = modoJuego;
        
        try {
            juego = new Juego();
            juego.iniciarJuego(1, "Vainilla", modoJuego);
            
            if (juego.getTablero() == null) {
                return;
            }
            
            if (panelJuego != null) {
                getContentPane().remove(panelJuego);
            }
            
            panelJuego = new TableroPanel(juego, modoJuego);
            panelJuego.setBounds(0, 0, 900, 700);
            
            panelInicio.setVisible(false);
            panelModos.setVisible(false);
            panelSeleccionModo.setVisible(false);
            
            getContentPane().add(panelJuego);
            panelJuego.setVisible(true);
            panelJuego.requestFocusInWindow();
            
            getContentPane().revalidate();
            getContentPane().repaint();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }    
    /**
     * Reinicia el juego con el mismo modo.
     * 
     * @param modoJuego modo de juego a reiniciar
     */
    public void reiniciarJuego(String modoJuego) {
        if (panelJuego != null) {
            panelJuego.detener();
            getContentPane().remove(panelJuego);
            panelJuego = null;
        }
        iniciarJuego(modoJuego);
    }
    
    /**
     * Vuelve al menú de inicio.
     */
    public void volverAlInicio() {
        if (panelJuego != null) {
            panelJuego.detener();
            panelJuego.setVisible(false);
            getContentPane().remove(panelJuego);
            panelJuego = null;
        }
        panelInicio.setVisible(true);
        getContentPane().revalidate();
        getContentPane().repaint();
    }
    
    /**
     * Configura las acciones de la ventana.
     */
    private void prepareActions() {
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(null, 
                    "¿Estás seguro que deseas salir del juego?", "Salir del Juego",
                    JOptionPane.YES_NO_OPTION);

                if (confirmar == JOptionPane.YES_OPTION) {
                    dispose();
                }
            }
        });
    }
    /**
     * Método principal que inicia la aplicación.
     * Crea la ventana del juego y la hace visible.
     * 
     * @param args argumentos de línea de comandos (no se usan)
     */
    public static void main(String[] args) {
        try {
            BadDopoCreamGUI frame = new BadDopoCreamGUI();
            frame.setVisible(true);
        } catch (Exception e) {
            System.err.println("Error al iniciar el juego:");
            e.printStackTrace();
        }
    }
}
