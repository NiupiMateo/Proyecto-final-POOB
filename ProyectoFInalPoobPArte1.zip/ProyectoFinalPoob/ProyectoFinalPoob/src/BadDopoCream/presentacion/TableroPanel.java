//Clase que deseamos implementar para el tablero de juego 
public class TableroPanel extends JPanel {
    
}
