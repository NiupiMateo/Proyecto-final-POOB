package BadDopoCream.controladores;

import BadDopoCream.dominio.Juego;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.utilidades.EstadoJuego;
import BadDopoCream.presentacion.BadDopoCreamGUI;

/**
 * Controlador principal del patrón MVC para Bad Dopo Cream.
 * Gestiona la comunicación entre el Modelo (Juego) y la Vista (BadDopoCreamGUI).
 * 
 * Responsabilidades:
 * - Recibir eventos de la interfaz (clicks, teclas, botones)
 * - Invocar métodos del modelo según el evento
 * - Solicitar actualización de la vista
 * - Coordinar el flujo del juego
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/02
 */
public class Controlador {
    private Juego juego;
    private BadDopoCreamGUI vista;
    
    // Estado de controles
    private boolean sonidoActivo = true;
    private boolean musicaActiva = true;

    /**
     * Constructor del controlador.
     * @param juego modelo (lógica del juego)
     * @param vista vista (interfaz gráfica)
     */
    public Controlador(Juego juego, BadDopoCreamGUI vista) {
        this.juego = juego;
        this.vista = vista;
    }

    /**
     * Método central para manejar todos los eventos del juego.
     * 
     * @param evento cadena que identifica el evento y sus parámetros
     */
    public void manejarEvento(String evento) {
        if (evento == null || evento.isEmpty()) {
            System.err.println("Controlador: Evento nulo o vacío recibido");
            return;
        }
        
        // Separar el evento de sus parámetros
        String[] partes = evento.split(":");
        String tipoEvento = partes[0];
        
        try {
            switch (tipoEvento) {
                // Eventos de navegacion 
                case "INICIAR_JUEGO":
                    manejarInicioJuego(partes);
                    break;
                    
                case "VOLVER_AL_INICIO":
                    manejarVolverAlInicio();
                    break;
                    
                // Eventos del contrl de juego (pausa, reinicio, siguiente nivel)
                case "PAUSAR_JUEGO":
                    manejarPausaJuego();
                    break;
                    
                case "REINICIAR_JUEGO":
                    manejarReinicioJuego(partes);
                    break;
                    
                case "SIGUIENTE_NIVEL":
                    manejarSiguienteNivel();
                    break;
                    
                // Eventos del movimiento del helado
                case "MOVER_ARRIBA":
                    manejarMovimiento(Direccion.ARRIBA);
                    break;
                    
                case "MOVER_ABAJO":
                    manejarMovimiento(Direccion.ABAJO);
                    break;
                    
                case "MOVER_IZQUIERDA":
                    manejarMovimiento(Direccion.IZQUIERDA);
                    break;
                    
                case "MOVER_DERECHA":
                    manejarMovimiento(Direccion.DERECHA);
                    break;
                    
                // Eventos de accion del helado 
                case "ACCION_BLOQUE":
                    manejarAccionBloque();
                    break;
                    
                // Eventos de audio
                case "TOGGLE_SONIDO":
                    manejarToggleSonido();
                    break;
                    
                case "TOGGLE_MUSICA":
                    manejarToggleMusica();
                    break;
                    
                // Eventos de actualización del juego
                case "ACTUALIZAR":
                    manejarActualizacion();
                    break;
                    
                default:
                    System.out.println("Controlador: Evento no reconocido: " + evento);
            }
        } catch (Exception e) {
            System.err.println("Controlador: Error al manejar evento '" + evento + "': " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // Métodos privados para cada evento
    
    /**
     * Maneja el inicio del juego.
     * Nota: El inicio real se hace en BadDopoCreamGUI.iniciarJuego()
     */
    private void manejarInicioJuego(String[] partes) {
        System.out.println("Controlador: Juego iniciado");
        vista.actualizarVista();
    }
    
    /**
     * Maneja la pausa/reanudación del juego.
     */
    private void manejarPausaJuego() {
        if (juego != null) {
            juego.pausa();
            
            int estadoActual = juego.getEstado().getEstado();
            String mensaje;

            if (estadoActual == EstadoJuego.PAUSADO) {
                mensaje = "pausado";
            } else {
                mensaje = "reanudado";
                // Restaurar el foco cuando se reanuda el juego
                vista.restaurarFoco();
            }

            System.out.println("Controlador: Juego " + mensaje);
            
            vista.actualizarVista();
        } else {
            System.err.println("Controlador: No hay juego activo para pausar");
        }
    }

    
    /**
     * Maneja el reinicio del juego.
     */
    private void manejarReinicioJuego(String[] partes) {
        if (partes.length > 1) {
            String modoJuego = partes[1];
            System.out.println("Controlador: Reiniciando juego en modo " + modoJuego);
            vista.reiniciarJuego(modoJuego);
        } else {
            // Reiniciar con el modo actual
            if (juego != null) {
                System.out.println("Controlador: Reiniciando nivel actual");
                juego.reiniciarNivel();
                vista.actualizarVista();
            }
        }
    }
    
    /**
     * Maneja el avance al siguiente nivel.
     */
    private void manejarSiguienteNivel() {
        if (juego != null) {
            System.out.println("Controlador: Avanzando al siguiente nivel");
            juego.siguienteNivel();
            vista.actualizarVista();
        }
    }
    
    /**
     * Maneja el retorno al menú principal.
     */
    private void manejarVolverAlInicio() {
        System.out.println("Controlador: Volviendo al menú principal");
        if (juego != null) {
            juego.volverAlMenu();
        }
        vista.volverAlInicio();
    }
    
    /**
     * Maneja el movimiento del helado.
     * @param direccion dirección del movimiento
     */
    private void manejarMovimiento(int direccion) {
        if (juego != null && juego.getEstado().getEstado() == EstadoJuego.JUGANDO) {
            Direccion dir = new Direccion(direccion);
            juego.moverHelado(dir);
            
            // NO llamar vista.actualizarVista() aquí
            // Se actualizará automáticamente en el game loop
        }
    }
    
    /**
     * Maneja la acción de crear/romper bloques (tecla ESPACIO).
     */
    private void manejarAccionBloque() {
        if (juego != null && juego.getEstado().getEstado() == EstadoJuego.JUGANDO) {
            juego.accionBloque();
            System.out.println("Controlador: Acción de bloque ejecutada");
            
            // no se llama vista.actualizarVista() ya que se realiza en el game loop
   
        }
    }
    
    /**
     * Alterna el estado del sonido.
     */
    private void manejarToggleSonido() {
        sonidoActivo = !sonidoActivo;

        String mensaje;
        if (sonidoActivo) {
            mensaje = "activado";
        } else {
            mensaje = "desactivado";
        }

        System.out.println("Controlador: Sonido " + mensaje);

        // Aun nos falta implementar lógica real de sonido
        // SistemaAudio.setSonidoActivo(sonidoActivo);

        vista.actualizarEstadoAudio(sonidoActivo, musicaActiva);
    }

    
    /**
    * Alterna el estado de la música.
    */
    private void manejarToggleMusica() {
        musicaActiva = !musicaActiva;

        String mensaje;
        if (musicaActiva) {
            mensaje = "activada";
        } else {
            mensaje = "desactivada";
        }

        System.out.println("Controlador: Música " + mensaje);

        // TODO: Implementar lógica real de música
        // SistemaAudio.setMusicaActiva(musicaActiva);

        vista.actualizarEstadoAudio(sonidoActivo, musicaActiva);
    }

    
    /**
     * Actualiza el estado del juego (llamado por el game loop).
     * Este es el corazón del juego que se ejecuta en cada frame.
     */
    private void manejarActualizacion() {
        if (juego != null) {
            // Actualizar la lógica del juego
            juego.actualizar();
            
            // Verificar cambios de estado (victoria/derrota)
            int estadoActual = juego.getEstado().getEstado();
            
            if (estadoActual == EstadoJuego.VICTORIA) {
                System.out.println("Controlador: ¡Nivel completado!");
                vista.mostrarVictoria();
            } else if (estadoActual == EstadoJuego.DERROTA) {
                System.out.println("Controlador: Nivel perdido");
                vista.mostrarDerrota();
            } else if (estadoActual == EstadoJuego.GAME_OVER) {
                System.out.println("Controlador: ¡Juego completado!");
                vista.mostrarGameOver();
            }
            
            // Actualizar la vista con el nuevo estado
            vista.actualizarVista();
        } else {
            System.err.println("Controlador.manejarActualizacion(): juego es null");
        }
    }
        
    /**
     * Obtiene la vista asociada.
     * @return instancia de BadDopoCreamGUI
     */
    public BadDopoCreamGUI getVista() {
        return vista;
    }
    
    /**
     * Obtiene el modelo asociado.
     * @return instancia de Juego
     */
    public Juego getJuego() {
        return juego;
    }
    
    /**
     * Verifica si el sonido está activo.
     * @return true si el sonido está activo
     */
    public boolean isSonidoActivo() {
        return sonidoActivo;
    }
    
    /**
     * Verifica si la música está activa.
     * @return true si la música está activa
     */
    public boolean isMusicaActiva() {
        return musicaActiva;
    }
}