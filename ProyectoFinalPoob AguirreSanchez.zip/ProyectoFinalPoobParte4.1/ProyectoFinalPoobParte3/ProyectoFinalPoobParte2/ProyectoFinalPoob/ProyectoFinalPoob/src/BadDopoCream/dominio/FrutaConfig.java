package BadDopoCream.dominio;

/**
 * Clase FrutaConfig - Configuración simple de una fruta para un nivel.
 * Solo almacena el tipo de fruta que se debe crear.
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class FrutaConfig {
    private String tipo;
    
    /**
     * Constructor de FrutaConfig
     * @param tipo tipo de fruta (Uva, Platano, Pina, Cereza)
     */
    public FrutaConfig(String tipo) {
        this.tipo = tipo;
    }
    
    /**
     * Obtiene el tipo de fruta
     * @return tipo de fruta
     */
    public String getTipo() {
        return tipo;
    }
    
    /**
     * Establece el tipo de fruta
     * @param tipo nuevo tipo de fruta
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
}
