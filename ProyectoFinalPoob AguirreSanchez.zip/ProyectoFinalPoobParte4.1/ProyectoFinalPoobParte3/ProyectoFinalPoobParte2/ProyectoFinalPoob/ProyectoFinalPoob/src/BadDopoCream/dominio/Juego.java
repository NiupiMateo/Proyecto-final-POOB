package BadDopoCream.dominio;

import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.utilidades.Temporizador;
import BadDopoCream.dominio.utilidades.EstadoJuego;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.componentes.helados.Helado;

/**
 * Clase Juego - es la clase orquestadora principal del juego.
 * Coordina Tablero, Nivel, Temporizador, Estado.
 * Es la responsable de iniciar el juego, actualizar lógica, verificar victoria/derrota,
 * procesar acciones del jugador (mover, crear/romper bloques, pausar).
 * Es el punto de entrada principal para el Controlador.
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/02
 */
public class Juego {
    private Tablero tablero;
    private Nivel nivelActual;
    private Temporizador temporizador;
    private EstadoJuego estado;
    private int numeroNivel;
    private String tipoHelado;
    private String modoJuego; // "PvsP", "PvsM", "MvsM"
    
    /**
     * Constructor del Juego
     */
    public Juego() {
        estado = new EstadoJuego(EstadoJuego.MENU);
        temporizador = new Temporizador();
        numeroNivel = 1;
    }
    
    /**
     * Inicia un nuevo juego
     * @param numeroNivel nivel a jugar (dentro de los requisitos son 1, 2, 3)
     * @param tipoHelado tipo de helado elegido
     * @param modoJuego modo de juego
     */
    public void iniciarJuego(int numeroNivel, String tipoHelado, String modoJuego) {
        System.out.println("Juego.iniciarJuego() - Nivel: " + numeroNivel + ", Helado: " + tipoHelado + ", Modo: " + modoJuego);
        
        this.numeroNivel = numeroNivel;
        this.tipoHelado = tipoHelado;
        this.modoJuego = modoJuego;
        
        // Crear el nivel correspondiente
        if (numeroNivel == 1) {
            nivelActual = new Nivel1();
        } else if (numeroNivel == 2) {
            nivelActual = new Nivel2();
        } else if (numeroNivel == 3) {
            nivelActual = new Nivel3();
        } else {
            nivelActual = new Nivel1(); // Por defecto nivel 1
        }
        
        // Crear el tablero con la configuración del nivel
        tablero = nivelActual.crearTablero(tipoHelado);
        
        System.out.println("Tablero creado - Filas: " + tablero.getFilas() + ", Columnas: " + tablero.getColumnas());
        System.out.println("Frutas en tablero: " + tablero.getFrutas().size());
        System.out.println("Enemigos en tablero: " + tablero.getEnemigos().size());
        
        // Iniciar el temporizador
        temporizador.reiniciar();
        temporizador.iniciar();
        
        estado.setEstado(EstadoJuego.JUGANDO);
        System.out.println("Estado del juego establecido a JUGANDO");
    }
    
    /**
     * Actualiza el estado del juego en cada frame
     */
    public void actualizar() {
        if (estado.getEstado() != EstadoJuego.JUGANDO){        
        return;
        }
        // Actualiza el temporizador
        temporizador.actualizar();
        // Actualiza el tablero (enemigos, frutas)
        tablero.actualizar();
        // Verifica la condicion del juego de victoria/derrota
        verificarEstadoJuego();
    }
    
    /**
     * Verifica las condiciones de victoria o derrota de cada frame.
     * Derrota si: Se acaba el tiempo (3 minutos), o  El helado toca un enemigo.
     * Victoria si: Se recolectan todas las frutas.
     */
    private void verificarEstadoJuego() {
        // Verifica la derrota por tiempo
        if (temporizador.seAcaboElTiempo()) {
            estado.setEstado(EstadoJuego.DERROTA);
            return;
        }
        
        // Verifica la derrota por colisión con enemigo
        if (tablero.hayColisionConEnemigo()) {
            estado.setEstado(EstadoJuego.DERROTA);
            return;
        }
        
        // Verifica la victoria si todas las frutas fueron recolectadas
        if (tablero.contarFrutasActivas() == 0) {
            estado.setEstado(EstadoJuego.VICTORIA);
            temporizador.pausar();
        }
    }
    
    /**
     * Mueve el helado en una dirección
     * @param direccion dirección de movimiento
     */
    public void moverHelado(Direccion direccion) {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null) {
            Helado helado = tablero.getHelado();
            if (helado != null) {
                helado.mover(direccion, tablero);
            }
        }
    }
    
    /**
     * Ejecuta la acción de bloque con la tecla ESPACIO.
     * Si hay un bloque en la dirección actual rompe los bloques en efecto dominó.
     * Si no hay bloque crea un bloque nuevo.
     */
    public void accionBloque() {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null) {
            Helado helado = tablero.getHelado();
            if (helado != null) {
                Posicion posBloque = helado.getDireccion().mover(helado.getPosicion());
                
                if (tablero.hayBloqueEn(posBloque)) {
                    // Romper bloques
                    helado.romperBloques(tablero);
                } else {
                    // Crear bloque
                    helado.crearBloque(tablero);
                }
            }
        }
    }
    
    /**
     * Pausa o reanuda el juego
     */
    public void pausa() {
        if (estado.getEstado() == EstadoJuego.JUGANDO) {
            estado.setEstado(EstadoJuego.PAUSADO);
            temporizador.pausar();
            System.out.println("Juego pausado");
        } else if (estado.getEstado() == EstadoJuego.PAUSADO) {
            estado.setEstado(EstadoJuego.JUGANDO);
            temporizador.iniciar();
            System.out.println("Juego reanudado");
        }
    }
    
    /**
     * Reinicia el nivel actual
     */
    public void reiniciarNivel() {
        iniciarJuego(numeroNivel, tipoHelado, modoJuego);
    }
    
    /**
     * Avanza al siguiente nivel
     */
    public void siguienteNivel() {
        if (numeroNivel < 3) {
            iniciarJuego(numeroNivel + 1, tipoHelado, modoJuego);
        } else {
            estado.setEstado(EstadoJuego.GAME_OVER);
        }
    }
    
    /**
     * Vuelve al menú principal
     */
    public void volverAlMenu() {
        estado.setEstado(EstadoJuego.MENU);
        temporizador.reiniciar();
    }
    
    // Getters
    
    public Tablero getTablero() {
        return tablero;
    }
    
    public EstadoJuego getEstado() {
        return estado;
    }
    
    public Temporizador getTemporizador() {
        return temporizador;
    }
    
    public int getNumeroNivel() {
        return numeroNivel;
    }
    
    public String getModoJuego() {
        return modoJuego;
    }
    
    public int getPuntaje() {
        if (tablero != null && tablero.getHelado() != null) {
            return tablero.getHelado().getPuntaje();
        }
        return 0;
    }
    
    public int getFrutasRestantes() {
        if (tablero != null) {
            return tablero.contarFrutasActivas();
        }
        return 0;
    }
}

