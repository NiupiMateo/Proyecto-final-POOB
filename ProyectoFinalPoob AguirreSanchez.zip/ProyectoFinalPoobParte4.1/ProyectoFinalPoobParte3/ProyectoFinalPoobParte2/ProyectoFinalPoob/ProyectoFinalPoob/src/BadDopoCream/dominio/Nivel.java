package BadDopoCream.dominio;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.componentes.helados.HeladoVainilla;
import BadDopoCream.dominio.componentes.helados.HeladoFresa;
import BadDopoCream.dominio.componentes.helados.HeladoChocolate;
import BadDopoCream.dominio.componentes.frutas.Fruta;
import BadDopoCream.dominio.componentes.frutas.Uva;
import BadDopoCream.dominio.componentes.frutas.Platano;
import BadDopoCream.dominio.componentes.frutas.Pina;
import BadDopoCream.dominio.componentes.frutas.Cereza;
import BadDopoCream.dominio.componentes.frutas.Cactus;
import BadDopoCream.dominio.componentes.enemigos.Enemigo;
import BadDopoCream.dominio.componentes.enemigos.Troll;
import BadDopoCream.dominio.componentes.enemigos.Maceta;
import BadDopoCream.dominio.componentes.enemigos.CalamarNaranja;
import BadDopoCream.dominio.componentes.enemigos.Narval;
import BadDopoCream.dominio.componentes.obstaculos.Fogata;
import BadDopoCream.dominio.componentes.obstaculos.BaldosaCaliente;

/**
 * Clase Nivel - Clase base para definir la configuración de cada nivel.
 * Esta clase se extiende en Nivel1, Nivel2 y Nivel3.
 * Cada nivel especifica qué frutas, enemigos y obstáculos hay.
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class Nivel {
    private int numeroNivel;
    private int ancho;
    private int alto;
    private List<FrutaConfig> frutas;
    private List<EnemigoConfig> enemigos;
    private List<ObstaculoConfig> obstaculos;
    private Posicion posicionInicialHelado;
    
    /**
     * Constructor de Nivel
     * @param numeroNivel número del nivel (1, 2, 3)
     */
    public Nivel(int numeroNivel) {
        this.numeroNivel = numeroNivel;
        this.ancho = 15;
        this.alto = 12;
        this.frutas = new ArrayList<FrutaConfig>();
        this.enemigos = new ArrayList<EnemigoConfig>();
        this.obstaculos = new ArrayList<ObstaculoConfig>();
        this.posicionInicialHelado = new Posicion(7, 9); // Posición por defecto
    }
    
    /**
     * Agrega una fruta a la configuración del nivel
     * @param tipo tipo de fruta (Uva, Platano, Pina, Cereza, Cactus)
     */
    public void agregarFruta(String tipo) {
        FrutaConfig config = new FrutaConfig(tipo);
        frutas.add(config);
    }
    
    /**
     * Agrega un enemigo a la configuración del nivel
     * Verifica que no esté en el área del iglú (centro bloqueado)
     * @param tipo tipo de enemigo (Troll, Maceta, CalamarNaranja, Narval)
     * @param x coordenada x (columna)
     * @param y coordenada y (fila)
     */
    public void agregarEnemigo(String tipo, int x, int y) {
        // Calcular el área del iglú
        int centroX = ancho / 2;
        int centroY = alto / 2;
        
        // Verificar que no esté en el área del iglú
        boolean enAreaIglu = (y == centroY - 1 || y == centroY) && 
                             (x >= centroX - 1 && x <= centroX + 1);
        
        if (!enAreaIglu) {
            EnemigoConfig config = new EnemigoConfig(tipo, x, y);
            enemigos.add(config);
        } else {
            System.err.println("Advertencia: Enemigo no agregado en posición del iglú (" + x + "," + y + ")");
        }
    }
    
    /**
     * Agrega un obstáculo a la configuración del nivel
     * Verifica que no esté en el área del iglú (centro bloqueado)
     * @param tipo tipo de obstáculo (Fogata, BaldosaCaliente)
     * @param x coordenada x (columna)
     * @param y coordenada y (fila)
     */
    public void agregarObstaculo(String tipo, int x, int y) {
        // Calcular el área del iglú
        int centroX = ancho / 2;
        int centroY = alto / 2;
        
        // Verificar que no esté en el área del iglú
        boolean enAreaIglu = (y == centroY - 1 || y == centroY) && 
                             (x >= centroX - 1 && x <= centroX + 1);
        
        if (!enAreaIglu) {
            ObstaculoConfig config = new ObstaculoConfig(tipo, x, y);
            obstaculos.add(config);
        } else {
            System.err.println("Advertencia: Obstáculo no agregado en posición del iglú (" + x + "," + y + ")");
        }
    }
    
    /**
     * Establece la posición inicial del helado
     * @param posicion posición inicial
     */
    public void setPosicionInicialHelado(Posicion posicion) {
        this.posicionInicialHelado = posicion;
    }
    
    /**
     * Obtiene la posición inicial del helado
     * @return posición inicial
     */
    public Posicion getPosicionInicialHelado() {
        return posicionInicialHelado;
    }
    
    /**
     * Obtiene la lista de configuraciones de enemigos
     * @return lista de enemigos
     */
    public List<EnemigoConfig> getEnemigos() {
        return enemigos;
    }
    
    /**
     * Obtiene la lista de configuraciones de obstáculos
     * @return lista de obstáculos
     */
    public List<ObstaculoConfig> getObstaculos() {
        return obstaculos;
    }
    
    /**
     * Obtiene el ancho del tablero
     * @return ancho
     */
    public int getAncho() {
        return ancho;
    }
    
    /**
     * Obtiene el alto del tablero
     * @return alto
     */
    public int getAlto() {
        return alto;
    }
    
    /**
     * Crea el tablero con toda la configuración del nivel.
     * Pasos: 
     * 1) Crea tablero vacío
     * 2) Coloca helado en posición inicial
     * 3) Coloca frutas en posiciones aleatorias
     * 4) Coloca enemigos en posiciones definidas
     * 
     * @param tipoHelado tipo de helado elegido por el jugador (Vainilla, Fresa, Chocolate)
     * @return tablero completamente configurado y listo para jugar
     */
    public Tablero crearTablero(String tipoHelado) {
        Tablero tablero = new Tablero(alto, ancho);
        
        // Paso 1: Crear y colocar el helado
        Helado helado = crearHelado(tipoHelado, posicionInicialHelado);
        tablero.setHelado(helado);
        
        // Paso 2: Crear y colocar las frutas en posiciones aleatorias
        for (int i = 0; i < frutas.size(); i++) {
            FrutaConfig config = frutas.get(i);
            Posicion pos = obtenerPosicionAleatoria(tablero);
            Fruta fruta = crearFruta(config.getTipo(), pos);
            tablero.agregarFruta(fruta);
        }
        
        // Paso 3: Crear y colocar los enemigos en posiciones fijas
        for (int i = 0; i < enemigos.size(); i++) {
            EnemigoConfig config = enemigos.get(i);
            Enemigo enemigo = crearEnemigo(config.getTipo(), config.getPosicion());
            tablero.agregarEnemigo(enemigo);
        }
        
        // Paso 4: Crear y colocar los obstáculos en posiciones fijas
        for (int i = 0; i < obstaculos.size(); i++) {
            ObstaculoConfig config = obstaculos.get(i);
            if (config.getTipo().equals("Fogata")) {
                Fogata fogata = new Fogata(config.getPosicion());
                tablero.agregarFogata(fogata);
            } else if (config.getTipo().equals("BaldosaCaliente")) {
                BaldosaCaliente baldosa = new BaldosaCaliente(config.getPosicion());
                tablero.agregarBaldosaCaliente(baldosa);
            }
        }
        
        return tablero;
    }
    
    /**
     * Crea un helado según el tipo especificado
     * @param tipo tipo de helado
     * @param pos posición
     * @return helado creado
     */
    private Helado crearHelado(String tipo, Posicion pos) {
        if (tipo.equals("Vainilla")) {
            return new HeladoVainilla(pos);
        } else if (tipo.equals("Fresa")) {
            return new HeladoFresa(pos);
        } else if (tipo.equals("Chocolate")) {
            return new HeladoChocolate(pos);
        } else {
            return new HeladoVainilla(pos);
        }
    }
    
    /**
     * Crea una fruta según el tipo especificado
     * @param tipo tipo de fruta
     * @param pos posición
     * @return fruta creada
     */
    private Fruta crearFruta(String tipo, Posicion pos) {
        if (tipo.equals("Uva")) {
            return new Uva(pos);
        } else if (tipo.equals("Platano")) {
            return new Platano(pos);
        } else if (tipo.equals("Pina")) {
            return new Pina(pos);
        } else if (tipo.equals("Cereza")) {
            return new Cereza(pos);
        } else if (tipo.equals("Cactus")) {
            return new Cactus(pos);
        } else {
            return new Uva(pos);
        }
    }
    
    /**
     * Crea un enemigo según el tipo especificado
     * @param tipo tipo de enemigo
     * @param pos posición
     * @return enemigo creado
     */
    private Enemigo crearEnemigo(String tipo, Posicion pos) {
        if (tipo.equals("Troll")) {
            return new Troll(pos);
        } else if (tipo.equals("Maceta")) {
            return new Maceta(pos);
        } else if (tipo.equals("CalamarNaranja")) {
            return new CalamarNaranja(pos);
        } else if (tipo.equals("Narval")) {
            return new Narval(pos);
        } else {
            return new Troll(pos);
        }
    }
    
    /**
     * Obtiene una posición aleatoria válida en el tablero
     * Evita colocar componentes en el área del iglú (centro del tablero)
     * @param tablero tablero donde buscar posición
     * @return posición aleatoria vacía
     */
    private Posicion obtenerPosicionAleatoria(Tablero tablero) {
        Random random = new Random();
        Posicion pos;
        int intentos = 0;
        
        // Calcular el área del iglú (centro del tablero)
        int centroX = ancho / 2;
        int centroY = alto / 2;
        
        do {
            int x = random.nextInt(ancho);
            int y = random.nextInt(alto);
            pos = new Posicion(x, y);
            intentos++;
            
            // Verificar que no esté en el área del iglú
            boolean enAreaIglu = (y == centroY - 1 || y == centroY) && 
                                 (x >= centroX - 1 && x <= centroX + 1);
            
            // Buscar posición que esté vacía Y no esté en el área del iglú
            if (!enAreaIglu && tablero.esPosicionVacia(pos)) {
                break;
            }
        } while (intentos < 100);
        
        return pos;
    }
    
    /**
     * Obtiene el número del nivel
     * @return número del nivel (1, 2, 3)
     */
    public int getNumeroNivel() {
        return numeroNivel;
    }
}

