package BadDopoCream.dominio.componentes;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase abstracta Componente.
 *
 * Representa la base de todos los elementos dinámicos del juego:
 * helados, enemigos y frutas.
 *
 * Cada componente tiene:
 * - Una posición en el tablero.
 * - Un estado activo/inactivo.
 *
 * Las subclases deben implementar los métodos abstractos:
 * - actualizar(): lógica de actualización en cada frame.
 * - getTipo(): devuelve el tipo de componente (para renderizado).
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public abstract class Componente {
    /** Posición actual del componente en el tablero */
    protected Posicion posicion;
    
    /** Indica si el componente está activo (visible y funcional) */
    protected boolean activa;
    
    /**
     * Constructor del Componente.
     *
     * @param posicion posición inicial del componente en el tablero
     */
    public Componente(Posicion posicion) {
        this.posicion = posicion;
        this.activa = true;
    }
    
    /**
     * Obtiene la posición actual del componente.
     *
     * @return posición del componente en el tablero
     */
    public Posicion getPosicion() {
        return posicion;
    }
    
    /**
     * Establece una nueva posición para el componente.
     *
     * @param posicion nueva posición a asignar
     */
    public void setPosicion(Posicion posicion) {
        this.posicion = posicion;
    }
    
    /**
     * Verifica si el componente está activo.
     *
     * @return true si está activo, false si está inactivo
     */
    public boolean isActiva() {
        return activa;
    }
    
    /**
     * Establece el estado activo/inactivo del componente.
     *
     * @param activa true para activar, false para desactivar
     */
    public void setActiva(boolean activa) {
        this.activa = activa;
    }
    
    /**
     * Actualiza el estado del componente.
     * Este método se llama en cada frame del juego.
     * Las subclases deben implementar su lógica específica.
     */
    public abstract void actualizar();
    
    /**
     * Obtiene el tipo de componente.
     *
     * @return cadena que identifica el tipo (para renderizado)
     */
    public abstract String getTipo();
}

