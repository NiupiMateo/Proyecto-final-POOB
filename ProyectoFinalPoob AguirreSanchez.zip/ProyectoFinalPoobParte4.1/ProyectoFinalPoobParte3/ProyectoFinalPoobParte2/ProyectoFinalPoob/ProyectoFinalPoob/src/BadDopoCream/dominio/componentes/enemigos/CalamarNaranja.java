package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.componentes.helados.Helado;
import javax.swing.ImageIcon;

/**
 * Enemigo Calamar Naranja - Enemigo más peligroso del nivel 3.
 * Comportamiento: Persigue al helado Y puede romper bloques de hielo (uno a la vez).
 * Es el enemigo más difícil de evadir porque no puede ser bloqueado con hielo.
 * Combina persecución activa con capacidad de destruir obstáculos.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class CalamarNaranja extends Enemigo {
    private java.awt.Image imagen;
    
    /**
     * Constructor de CalamarNaranja
     * @param posicion posición inicial
     */
    public CalamarNaranja(Posicion posicion) {
        super(posicion, 10, true);
        try {
            imagen = new ImageIcon(
                getClass().getResource("/BadDopoCream/presentacion/recursos/Calamar.png")
            ).getImage();
        } catch (Exception e) {
            System.err.println("Error cargando imagen de CalamarNaranja: " + e.getMessage());
        }
    }
    

    @Override
    public void actualizar() {
        contadorMovimiento++;
    }
    
    /**
     * Calcula el próximo movimiento del Calamar Naranja basado en el tablero y la posición del helado.
     * Intenta moverse hacia el helado, rompiendo bloques de hielo si es necesario.
     * @param tablero tablero del juego
     * @param helado helado del jugador
     **/
    @Override
    public void calcularMovimiento(Tablero tablero, Helado helado) {
        if (contadorMovimiento >= velocidad) {
            contadorMovimiento = 0;
            
            Posicion posHelado = helado.getPosicion();
            int deltaX = posHelado.getX() - posicion.getX();
            int deltaY = posHelado.getY() - posicion.getY();
            
            // Priorizar movimiento en el eje con mayor distancia
            Direccion direccionPreferida;
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 0) {
                    direccionPreferida = new Direccion(Direccion.DERECHA);
                } else {
                    direccionPreferida = new Direccion(Direccion.IZQUIERDA);
                }
            } else {
                if (deltaY > 0) {
                    direccionPreferida = new Direccion(Direccion.ABAJO);
                } else {
                    direccionPreferida = new Direccion(Direccion.ARRIBA);
                }
            }
            
            Posicion nuevaPos = direccionPreferida.mover(posicion);
            
            if (tablero.esPosicionValida(nuevaPos)) {
                Celda celdaDestino = tablero.getCelda(nuevaPos);
                if (celdaDestino != null && celdaDestino.getTipo().esBloqueHielo()) {
                    // Romper el bloque
                    this.direccion = direccionPreferida;
                    romperBloque(tablero);
                } else if (celdaDestino != null && celdaDestino.getTipo().esVacio()) {
                    // Moverse
                    tablero.moverComponente(posicion, nuevaPos);
                    this.posicion = nuevaPos;
                    this.direccion = direccionPreferida;
                }
            } else {
                // Intentar con la dirección alternativa
                Direccion direccionAlternativa;
                if (Math.abs(deltaX) > Math.abs(deltaY)) {
                    if (deltaY > 0) {
                        direccionAlternativa = new Direccion(Direccion.ABAJO);
                    } else {
                        direccionAlternativa = new Direccion(Direccion.ARRIBA);
                    }
                } else {
                    if (deltaX > 0) {
                        direccionAlternativa = new Direccion(Direccion.DERECHA);
                    } else {
                        direccionAlternativa = new Direccion(Direccion.IZQUIERDA);
                    }
                }
                
                nuevaPos = direccionAlternativa.mover(posicion);
                if (tablero.esPosicionValida(nuevaPos)) {
                    Celda celdaDest = tablero.getCelda(nuevaPos);
                    if (celdaDest != null && celdaDest.getTipo().esBloqueHielo()) {
                        this.direccion = direccionAlternativa;
                        romperBloque(tablero);
                    } else if (celdaDest != null && celdaDest.getTipo().esVacio()) {
                        tablero.moverComponente(posicion, nuevaPos);
                        this.posicion = nuevaPos;
                        this.direccion = direccionAlternativa;
                    }
                }
            }
        }
    }
    
    @Override
    public String getTipo() {
        return "CalamarNaranja";
    }
}


