package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.componentes.helados.Helado;

/**
 * Enemigo Maceta.
 *
 * Es el enemigo del nivel 2.
 * A diferencia del Troll, la Maceta persigue activamente al helado.
 *
 * Comportamiento:
 * - Calcula la distancia entre su posición y la del helado.
 * - Se mueve priorizando el eje con mayor distancia (X o Y).
 * - Si no puede avanzar en esa dirección, intenta con la alternativa.
 * - No puede romper bloques de hielo, así que puede ser bloqueada.
 *
 * Velocidad: 12 frames por movimiento (más rápida que el Troll).
 */
public class Maceta extends Enemigo {
    
    /**
     * Constructor de la Maceta.
     * @param posicion posición inicial en el tablero
     *
     * Velocidad = 12 (más rápida que el Troll).
     * No puede romper bloques de hielo.
     */
    public Maceta(Posicion posicion) {
        super(posicion, 12, false);
    }
    
    /**
     * Actualiza el contador de movimiento.
     * Cada llamada suma 1, y cuando llega a la velocidad
     * la Maceta puede intentar moverse.
     */
    @Override
    public void actualizar() {
        contadorMovimiento++;
    }
    
    /**
     * Calcula el movimiento de la Maceta hacia el helado.
     *
     * Algoritmo de persecución:
     * 1. Calcula la distancia en X (deltaX) y Y (deltaY) hacia el helado.
     * 2. Prioriza moverse en el eje con mayor distancia absoluta.
     * 3. Si no puede avanzar en esa dirección, intenta con la alternativa.
     * 4. Si tampoco puede, se queda en su posición.
     *
     * Este algoritmo hace que la Maceta se acerque constantemente al jugador,
     * creando un desafío mayor que el movimiento aleatorio del Troll.
     *
     * @param tablero tablero donde se mueve la Maceta
     * @param helado referencia al helado del jugador
     */
    @Override
    public void calcularMovimiento(Tablero tablero, Helado helado) {
        if (contadorMovimiento >= velocidad) {
            contadorMovimiento = 0;
            
            Posicion posHelado = helado.getPosicion();
            int deltaX = posHelado.getX() - posicion.getX();
            int deltaY = posHelado.getY() - posicion.getY();
            
            // Priorizar movimiento en el eje con mayor distancia
            Direccion direccionPreferida;
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 0) {
                    direccionPreferida = new Direccion(Direccion.DERECHA);
                } else {
                    direccionPreferida = new Direccion(Direccion.IZQUIERDA);
                }
            } else {
                if (deltaY > 0) {
                    direccionPreferida = new Direccion(Direccion.ABAJO);
                } else {
                    direccionPreferida = new Direccion(Direccion.ARRIBA);
                }
            }
            
            Posicion nuevaPos = direccionPreferida.mover(posicion);
            
            if (tablero.esPosicionValida(nuevaPos)) {
                Celda celdaDestino = tablero.getCelda(nuevaPos);
                if (celdaDestino != null && celdaDestino.esTransitable()) {
                    tablero.moverComponente(posicion, nuevaPos);
                    this.posicion = nuevaPos;
                    this.direccion = direccionPreferida;
                }
            } else {
                // Intentar con la dirección alternativa
                Direccion direccionAlternativa;
                if (Math.abs(deltaX) > Math.abs(deltaY)) {
                    if (deltaY > 0) {
                        direccionAlternativa = new Direccion(Direccion.ABAJO);
                    } else {
                        direccionAlternativa = new Direccion(Direccion.ARRIBA);
                    }
                } else {
                    if (deltaX > 0) {
                        direccionAlternativa = new Direccion(Direccion.DERECHA);
                    } else {
                        direccionAlternativa = new Direccion(Direccion.IZQUIERDA);
                    }
                }
                
                nuevaPos = direccionAlternativa.mover(posicion);
                if (tablero.esPosicionValida(nuevaPos)) {
                    Celda celdaDest = tablero.getCelda(nuevaPos);
                    if (celdaDest != null && celdaDest.esTransitable()) {
                        tablero.moverComponente(posicion, nuevaPos);
                        this.posicion = nuevaPos;
                        this.direccion = direccionAlternativa;
                    }
                }
            }
        }
    }
    
    /**
     * Retorna el tipo de enemigo.
     *
     * @return "Maceta"
     */
    @Override
    public String getTipo() {
        return "Maceta";
    }
}


