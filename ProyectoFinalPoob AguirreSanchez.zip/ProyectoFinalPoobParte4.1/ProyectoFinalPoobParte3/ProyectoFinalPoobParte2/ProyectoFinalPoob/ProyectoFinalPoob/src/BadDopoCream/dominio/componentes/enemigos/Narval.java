package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.tablero.TipoCelda;
import BadDopoCream.dominio.componentes.helados.Helado;
import java.util.Random;

/**
 * Enemigo Narval.
 *
 * Es un enemigo peligroso del nivel 3.
 * El Narval patrulla el tablero de forma aleatoria, pero embiste
 * cuando detecta que un helado se alinea con él.
 *
 * Comportamiento:
 * - Patrulla aleatoriamente por el tablero.
 * - Detecta si un helado está en la misma fila o columna.
 * - Cuando detecta alineación, embiste rápidamente en esa dirección.
 * - Durante la embestida, destruye bloques de hielo en su camino.
 *
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class Narval extends Enemigo {
    /** Dirección actual del narval */
    private Direccion direccionActual;
    
    /** Generador de números aleatorios */
    private Random random;
    
    /** Contador para controlar velocidad de patrullaje */
    private int contadorMovimiento;
    
    /** Velocidad de patrullaje normal (frames entre movimientos) */
    private static final int VELOCIDAD_PATRULLAJE = 40;
    
    /** Velocidad de embestida (más rápida) */
    private static final int VELOCIDAD_EMBESTIDA = 10;
    
    /** Indica si está embistiendo actualmente */
    private boolean embistiendo;
    
    /** Contador para la embestida */
    private int contadorEmbestida;
    
    /**
     * Constructor del Narval.
     *
     * @param posicion posición inicial del narval en el tablero
     */
    public Narval(Posicion posicion) {
        super(posicion, 30, true); // velocidad 30 frames, puede romper bloques
        this.random = new Random();
        this.embistiendo = false;
        this.contadorMovimiento = 0;
        this.contadorEmbestida = 0;
        
        // Dirección inicial aleatoria
        int[] direcciones = {Direccion.ARRIBA, Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.DERECHA};
        this.direccionActual = new Direccion(direcciones[random.nextInt(4)]);
    }
    
    /**
     * Actualiza el estado del narval.
     * Incrementa contadores de movimiento.
     */
    @Override
    public void actualizar() {
        contadorMovimiento++;
        if (embistiendo) {
            contadorEmbestida++;
        }
    }
    
    /**
     * Mueve el narval en el tablero.
     * Patrulla aleatoriamente o embiste si detecta alineación con el helado.
     *
     * @param tablero tablero del juego
     */
    public void mover(Tablero tablero) {
        Posicion posHelado = tablero.getHelado().getPosicion();
        
        // Verificar si hay alineación con el helado
        boolean alineado = estaAlineadoConHelado(posHelado);
        
        if (alineado && !embistiendo) {
            // Iniciar embestida
            iniciarEmbestida(posHelado);
        }
        
        if (embistiendo) {
            moverEmbestida(tablero);
        } else {
            moverPatrullaje(tablero);
        }
    }
    
    /**
     * Verifica si el narval está alineado con el helado (misma fila o columna).
     *
     * @param posHelado posición del helado
     * @return true si están alineados
     */
    private boolean estaAlineadoConHelado(Posicion posHelado) {
        return posicion.getX() == posHelado.getX() || posicion.getY() == posHelado.getY();
    }
    
    /**
     * Inicia la embestida hacia el helado.
     *
     * @param posHelado posición del helado
     */
    private void iniciarEmbestida(Posicion posHelado) {
        embistiendo = true;
        contadorEmbestida = 0;
        
        // Determinar dirección de embestida
        if (posicion.getX() == posHelado.getX()) {
            // Alineados verticalmente
            if (posHelado.getY() > posicion.getY()) {
                direccionActual = new Direccion(Direccion.ABAJO);
            } else {
                direccionActual = new Direccion(Direccion.ARRIBA);
            }
        } else {
            // Alineados horizontalmente
            if (posHelado.getX() > posicion.getX()) {
                direccionActual = new Direccion(Direccion.DERECHA);
            } else {
                direccionActual = new Direccion(Direccion.IZQUIERDA);
            }
        }
    }
    
    /**
     * Movimiento durante el patrullaje normal.
     *
     * @param tablero tablero del juego
     */
    private void moverPatrullaje(Tablero tablero) {
        // Solo moverse cada VELOCIDAD_PATRULLAJE frames
        if (contadorMovimiento < VELOCIDAD_PATRULLAJE) {
            return;
        }
        
        contadorMovimiento = 0;
        
        // Cambiar dirección aleatoriamente (20% probabilidad)
        if (random.nextInt(10) < 2) {
            int[] direcciones = {Direccion.ARRIBA, Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.DERECHA};
            direccionActual = new Direccion(direcciones[random.nextInt(4)]);
        }
        
        // Intentar moverse
        Posicion nuevaPos = direccionActual.mover(posicion);
        if (puedeMoverse(tablero, nuevaPos, false)) {
            tablero.moverComponente(posicion, nuevaPos);
            this.posicion = nuevaPos;
        } else {
            // Cambiar a dirección opuesta si choca
            direccionActual = direccionActual.opuesta();
        }
    }
    
    /**
     * Movimiento durante la embestida.
     * Más rápido y destruye bloques de hielo.
     *
     * @param tablero tablero del juego
     */
    private void moverEmbestida(Tablero tablero) {
        // Moverse más rápido durante embestida
        if (contadorEmbestida < VELOCIDAD_EMBESTIDA) {
            return;
        }
        
        contadorEmbestida = 0;
        
        // Intentar moverse en dirección de embestida
        Posicion nuevaPos = direccionActual.mover(posicion);
        
        if (!tablero.esPosicionValida(nuevaPos)) {
            // Llegó al borde, terminar embestida
            embistiendo = false;
            return;
        }
        
        Celda celdaDestino = tablero.getCelda(nuevaPos);
        
        // Si hay bloque de hielo, destruirlo y continuar
        if (celdaDestino.getTipo().esBloqueHielo()) {
            tablero.romperBloque(nuevaPos);
        }
        
        // Moverse si es posible
        if (puedeMoverse(tablero, nuevaPos, true)) {
            tablero.moverComponente(posicion, nuevaPos);
            this.posicion = nuevaPos;
        } else {
            // Terminar embestida si encuentra obstáculo insuperable
            embistiendo = false;
        }
    }
    
    /**
     * Verifica si puede moverse a una posición.
     *
     * @param tablero tablero del juego
     * @param nuevaPos posición destino
     * @param embistiendo si está en modo embestida (puede atravesar bloques)
     * @return true si puede moverse
     */
    private boolean puedeMoverse(Tablero tablero, Posicion nuevaPos, boolean embistiendo) {
        if (!tablero.esPosicionValida(nuevaPos)) {
            return false;
        }
        
        Celda celda = tablero.getCelda(nuevaPos);
        if (celda == null) {
            return false;
        }
        
        // No puede atravesar muros ni iglú
        if (celda.getTipo().esMuro() || celda.getTipo().esIglu()) {
            return false;
        }
        
        // Durante embestida puede atravesar bloques de hielo (los destruye)
        if (embistiendo && celda.getTipo().esBloqueHielo()) {
            return true;
        }
        
        // Normalmente necesita que la celda sea transitable
        return celda.esTransitable();
    }
    
    /**
     * Retorna el tipo de enemigo.
     *
     * @return "Narval"
     */
    @Override
    public String getTipo() {
        return "Narval";
    }
    
    /**
     * Verifica si está embistiendo actualmente.
     *
     * @return true si está embistiendo
     */
    public boolean estaEmbistiendo() {
        return embistiendo;
    }
    
    /**
     * Calcula el próximo movimiento del Narval basado en el tablero y la posición del helado.
     * @param tablero tablero del juego
     * @param helado helado del jugador
     */
    @Override
    public void calcularMovimiento(Tablero tablero, Helado helado) {
        // El movimiento se maneja en el método mover()
    }
}
