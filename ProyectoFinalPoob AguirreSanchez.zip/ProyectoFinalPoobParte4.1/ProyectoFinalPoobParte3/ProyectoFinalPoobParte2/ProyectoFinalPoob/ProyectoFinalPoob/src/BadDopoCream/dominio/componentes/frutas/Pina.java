package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import javax.swing.ImageIcon;

import java.util.Random;

/**
 * Fruta Piña.
 *
 * Es una fruta móvil presente en el nivel 2.
 * La Piña huye del helado, moviéndose en dirección opuesta.
 *
 * Comportamiento:
 * - Se mueve cuando el helado se mueve.
 * - Intenta alejarse del helado (dirección opuesta).
 * - Cambia de dirección cuando choca con un obstáculo.
 *
 * Otorga 200 puntos al ser recolectada.
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class Pina extends Fruta {
    /** Dirección actual del movimiento de la piña */
    private Direccion direccionActual;
    
    /** Generador de números aleatorios para movimiento */
    private Random random;
    
    /** Contador de frames para controlar velocidad de movimiento */
    private int contadorMovimiento;
    
    /** Velocidad de movimiento (frames entre cada movimiento) */
    private static final int VELOCIDAD = 100;
    
    /**
     * Constructor de la Piña.
     *
     * @param posicion posición inicial de la piña en el tablero
     */
    public Pina(Posicion posicion) {
        super(posicion, 200);
        random = new Random();
        int[] direcciones = {Direccion.ARRIBA, Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.DERECHA};
        direccionActual = new Direccion(direcciones[random.nextInt(4)]);
        contadorMovimiento = 0;
        try {
            imagen = new ImageIcon(
                getClass().getResource("/BadDopoCream/presentacion/recursos/Fruta-Piña.jpg")
            ).getImage();
        } catch (Exception e) {
            System.err.println("Error cargando imagen de Pina: " + e.getMessage());
        }
    }
    
    /**
     * Actualiza el estado de la piña.
     *
     * Incrementa el contador de movimiento.
     */
    @Override
    public void actualizar() {
        contadorMovimiento++;
    }
    
    /**
     * Mueve la piña huyendo del helado.
     * La piña intenta moverse en dirección opuesta a donde está el helado.
     *
     * @param tablero tablero del juego donde se mueve la piña
     */
    public void mover(Tablero tablero) {
        // Solo moverse cada VELOCIDAD frames
        if (contadorMovimiento < VELOCIDAD) {
            return;  // No es tiempo de moverse todavía
        }
        
        // Resetear contador
        contadorMovimiento = 0;
        
        // Obtener posición del helado
        Posicion posHelado = tablero.getHelado().getPosicion();
        
        // Calcular dirección para huir del helado
        int deltaX = posicion.getX() - posHelado.getX();
        int deltaY = posicion.getY() - posHelado.getY();
        
        // Determinar dirección de escape
        Direccion direccionEscape;
        if (Math.abs(deltaX) > Math.abs(deltaY)) {
            // Huir horizontalmente
            if (deltaX > 0) {
                direccionEscape = new Direccion(Direccion.DERECHA);
            } else {
                direccionEscape = new Direccion(Direccion.IZQUIERDA);
            }
        } else {
            // Huir verticalmente
            if (deltaY > 0) {
                direccionEscape = new Direccion(Direccion.ABAJO);
            } else {
                direccionEscape = new Direccion(Direccion.ARRIBA);
            }
        }
        
        // Intentar moverse en la dirección de escape
        Posicion nuevaPos = direccionEscape.mover(posicion);
        if (tablero.esPosicionValida(nuevaPos)) {
            Celda celdaDestino = tablero.getCelda(nuevaPos);
            if (celdaDestino != null && celdaDestino.esTransitable() && !celdaDestino.tieneComponente()) {
                tablero.moverComponente(posicion, nuevaPos);
                this.posicion = nuevaPos;
                this.direccionActual = direccionEscape;
            } else {
                // Si no puede huir, intentar moverse en dirección perpendicular
                intentarMovimientoAlternativo(tablero, direccionEscape);
            }
        } else {
            // Si está en el borde, intentar dirección alternativa
            intentarMovimientoAlternativo(tablero, direccionEscape);
        }
    }
    
    /**
     * Intenta moverse en una dirección alternativa cuando no puede huir directamente.
     * 
     * @param tablero tablero del juego
     * @param direccionOriginal dirección en la que intentó moverse
     */
    private void intentarMovimientoAlternativo(Tablero tablero, Direccion direccionOriginal) {
        // Probar direcciones perpendiculares
        int[] direccionesPosibles = {Direccion.ARRIBA, Direccion.ABAJO, Direccion.IZQUIERDA, Direccion.DERECHA};
        
        for (int dir : direccionesPosibles) {
            Direccion nuevaDireccion = new Direccion(dir);
            Posicion nuevaPos = nuevaDireccion.mover(posicion);
            
            if (tablero.esPosicionValida(nuevaPos)) {
                Celda celdaDestino = tablero.getCelda(nuevaPos);
                if (celdaDestino != null && celdaDestino.esTransitable() && !celdaDestino.tieneComponente()) {
                    tablero.moverComponente(posicion, nuevaPos);
                    this.posicion = nuevaPos;
                    this.direccionActual = nuevaDireccion;
                    break; // Salir del bucle cuando logre moverse
                }
            }
        }
    }
    
    /**
     * Retorna el tipo de fruta.
     * @return "Pina"
     */
    @Override
    public String getTipo() {
        return "Pina";
    }
}


