package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.ImageIcon;

/**
 * Fruta Plátano.
 *
 * Es una fruta estática presente en niveles 1 y 2.
 * No se mueve durante el juego, permanece en su posición inicial.
 * Otorga 100 puntos al ser recolectada.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class Platano extends Fruta {
    
    /**
     * Constructor del Plátano.
     *
     * @param posicion posición inicial del plátano en el tablero
     */
    public Platano(Posicion posicion) {
        super(posicion, 100);
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/Fruta-Platano.jpg");
            if (url != null) {
                imagen = new ImageIcon(url).getImage();
                System.out.println("✓ Platano: Imagen Fruta-Platano.jpg cargada correctamente desde: " + url);
            } else {
                System.err.println("✗ Platano: URL es NULL - No se encontró Fruta-Platano.jpg");
            }
        } catch (Exception e) {
            System.err.println("✗ Platano: Error cargando imagen: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    /**
     * Actualiza el estado del plátano.
     * Los plátanos no tienen comportamiento dinámico (no se mueven).
     */
    @Override
    public void actualizar() {
        // Los plátanos no se mueven
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Platano"
     */
    @Override
    public String getTipo() {
        return "Platano";
    }
}


