package BadDopoCream.dominio.componentes.helados;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.ImageIcon;

/**
 * Helado de Chocolate.
 *
 * Es uno de los tres sabores disponibles para el jugador.
 * Su color característico es café oscuro.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class HeladoChocolate extends Helado {
    
    /**
     * Constructor del Helado de Chocolate.
     *
     * @param posicion posición inicial en el tablero
     */
    public HeladoChocolate(Posicion posicion) {
        super(posicion);
        try {
            imagen = new ImageIcon(
                getClass().getResource("/BadDopoCream/presentacion/recursos/helado-Chocolate.jpg")
            ).getImage();
        } catch (Exception e) {
            System.err.println("Error cargando imagen de HeladoChocolate: " + e.getMessage());
        }
    }
    
    /**
     * Retorna el tipo de helado.
     *
     * @return "HeladoChocolate"
     */
    @Override
    public String getTipo() {
        return "HeladoChocolate";
    }
    
    /**
     * Retorna el color del helado.
     *
     * @return "cafe"
     */
    @Override
    public String getColor() {
        return "cafe";
    }
}


