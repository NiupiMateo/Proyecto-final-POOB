package BadDopoCream.dominio.componentes.helados;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.ImageIcon;

/**
 * Helado de Fresa.
 *
 * Es uno de los tres sabores disponibles para el jugador.
 * Su color característico es rosado.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class HeladoFresa extends Helado {
    
    /**
     * Constructor del Helado de Fresa.
     *
     * @param posicion posición inicial en el tablero
     */
    public HeladoFresa(Posicion posicion) {
        super(posicion);
        try {
            imagen = new ImageIcon(
                getClass().getResource("/BadDopoCream/presentacion/recursos/helado-Fresa.jpg")
            ).getImage();
        } catch (Exception e) {
            System.err.println("Error cargando imagen de HeladoFresa: " + e.getMessage());
        }
    }
    
    /**
     * Retorna el tipo de helado.
     *
     * @return "HeladoFresa"
     */
    @Override
    public String getTipo() {
        return "HeladoFresa";
    }
    
    /**
     * Retorna el color del helado.
     *
     * @return "rosado"
     */
    @Override
    public String getColor() {
        return "rosado";
    }
}


