package BadDopoCream.dominio.componentes.helados;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.ImageIcon;

/**
 * Helado de Vainilla.
 *
 * Es uno de los tres sabores disponibles para el jugador.
 * Su color característico es blanco cremoso.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class HeladoVainilla extends Helado {
    
    /**
     * Constructor del Helado de Vainilla.
     *
     * @param posicion posición inicial en el tablero
     */
    public HeladoVainilla(Posicion posicion) {
        super(posicion);
        try {
            imagen = new ImageIcon(
                getClass().getResource("/BadDopoCream/presentacion/recursos/helado-Vainillaa.jpg")
            ).getImage();
        } catch (Exception e) {
            System.err.println("Error cargando imagen de HeladoVainilla: " + e.getMessage());
        }
    }
    
    /**
     * Retorna el tipo de helado.
     *
     * @return "HeladoVainilla"
     */
    @Override
    public String getTipo() {
        return "HeladoVainilla";
    }
    
    /**
     * Retorna el color del helado.
     *
     * @return "Blanco"
     */
    @Override
    public String getColor() {
        return "blanco";
    }
}

