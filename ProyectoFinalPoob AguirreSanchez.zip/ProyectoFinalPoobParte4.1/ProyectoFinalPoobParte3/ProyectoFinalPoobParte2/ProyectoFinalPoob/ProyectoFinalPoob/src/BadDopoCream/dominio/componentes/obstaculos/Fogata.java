package BadDopoCream.dominio.componentes.obstaculos;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase Fogata - Obstáculo peligroso para los helados.
 *
 * Las fogatas eliminan a los helados inmediatamente si entran en contacto.
 * Los enemigos son inmunes al fuego.
 *
 * Comportamiento:
 * - Elimina helados al contacto.
 * - Puede apagarse temporalmente si se crea un bloque de hielo sobre ella.
 * - Después de 5 segundos, el fuego vuelve a encenderse.
 *
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class Fogata {
    /** Posición de la fogata en el tablero */
    private Posicion posicion;
    
    /** Indica si la fogata está encendida */
    private boolean encendida;
    
    /** Contador de frames para reencender la fogata */
    private int contadorReencendido;
    
    /** Tiempo para reencender (5 segundos = 300 frames a 60 FPS) */
    private static final int TIEMPO_REENCENDIDO = 300;
    
    /**
     * Constructor de Fogata.
     *
     * @param posicion posición de la fogata en el tablero
     */
    public Fogata(Posicion posicion) {
        this.posicion = posicion;
        this.encendida = true; // Inicia encendida
        this.contadorReencendido = 0;
    }
    
    /**
     * Actualiza el estado de la fogata.
     * Si está apagada, cuenta el tiempo para reencenderse.
     */
    public void actualizar() {
        if (!encendida) {
            contadorReencendido++;
            
            // Reencender después de 5 segundos
            if (contadorReencendido >= TIEMPO_REENCENDIDO) {
                encendida = true;
                contadorReencendido = 0;
            }
        }
    }
    
    /**
     * Apaga la fogata temporalmente.
     * Esto ocurre cuando se crea y rompe un bloque de hielo sobre ella.
     */
    public void apagar() {
        encendida = false;
        contadorReencendido = 0;
    }
    
    /**
     * Enciende la fogata.
     */
    public void encender() {
        encendida = true;
        contadorReencendido = 0;
    }
    
    /**
     * Verifica si la fogata está encendida.
     *
     * @return true si está encendida
     */
    public boolean estaEncendida() {
        return encendida;
    }
    
    /**
     * Obtiene la posición de la fogata.
     *
     * @return posición
     */
    public Posicion getPosicion() {
        return posicion;
    }
    
    /**
     * Establece la posición de la fogata.
     *
     * @param posicion nueva posición
     */
    public void setPosicion(Posicion posicion) {
        this.posicion = posicion;
    }
}
