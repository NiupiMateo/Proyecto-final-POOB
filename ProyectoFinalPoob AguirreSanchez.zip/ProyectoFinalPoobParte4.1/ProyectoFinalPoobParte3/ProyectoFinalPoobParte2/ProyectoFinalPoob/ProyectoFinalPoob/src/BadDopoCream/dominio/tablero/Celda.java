package BadDopoCream.dominio.tablero;

import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase Celda - Representa una casilla del tablero.
 * 
 * Cada celda tiene un tipo (vacío, muro, bloque de hielo)
 * y puede contener un componente (helado, enemigo, fruta).
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class Celda {
    private TipoCelda tipo;
    private Componente componente;
    private Posicion posicion;
    
    /**
     * Constructor de Celda
     * @param posicion posición de la celda en el tablero
     * @param tipo tipo inicial de la celda
     */
    public Celda(Posicion posicion, int tipo) {
        this.posicion = posicion;
        this.tipo = new TipoCelda(tipo);
        this.componente = null;
    }
    
    /**
     * Obtiene el tipo de celda
     * @return tipo de celda
     */
    public TipoCelda getTipo() {
        return tipo;
    }
    
    /**
     * Establece el tipo de celda
     * @param tipo nuevo tipo
     */
    public void setTipo(TipoCelda tipo) {
        this.tipo = tipo;
    }
    
    /**
     * Obtiene el componente en esta celda
     * @return componente o null si está vacía
     */
    public Componente getComponente() {
        return componente;
    }
    
    /**
     * Coloca un componente en esta celda
     * @param componente componente a colocar
     */
    public void setComponente(Componente componente) {
        this.componente = componente;
    }
    
    /**
     * Remueve el componente de esta celda
     */
    public void removerComponente() {
        this.componente = null;
    }
    
    /**
     * Obtiene la posición de esta celda
     * @return posición
     */
    public Posicion getPosicion() {
        return posicion;
    }
    
    /**
     * Verifica si la celda está completamente vacía (sin componente y tipo VACIO)
     * @return true si está vacía
     */
    public boolean estaVacia() {
        return tipo.esVacio() && componente == null;
    }
    
    /**
     * Verifica si la celda es transitable (puede entrar el helado/enemigo)
     * @return true si es transitable
     */
    public boolean esTransitable() {
        return !tipo.esMuro() && !tipo.esBloqueHielo() && !tipo.esIglu();
    }
    
    /**
     * Verifica si hay un componente en esta celda
     * @return true si hay componente
     */
    public boolean tieneComponente() {
        return componente != null;
    }
}


