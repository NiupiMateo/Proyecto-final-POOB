package BadDopoCream.dominio.tablero;

import java.util.ArrayList;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.componentes.enemigos.Enemigo;
import BadDopoCream.dominio.componentes.frutas.Fruta;
import BadDopoCream.dominio.componentes.frutas.Pina;
import BadDopoCream.dominio.componentes.frutas.Cereza;
import BadDopoCream.dominio.componentes.obstaculos.Fogata;
import BadDopoCream.dominio.componentes.obstaculos.BaldosaCaliente;

/**
 * Clase Tablero - Representa el campo de juego completo con estructura de matriz de Celdas.
 * Organización: Matriz de Celda[filas][columnas] donde cada celda puede contener componentes.
 * Los componentes son: Helado (jugador), Enemigos (Troll, Maceta, Calamar) y Frutas (Uva, Plátano, Piña, Cereza).
 * Contiene y administra: helado, enemigos, frutas y bloques de hielo.
 * Responsable de: detectar colisiones, verificar recolecciones, actualizar componentes.
 * Los bordes del tablero son muros permanentes.
 * El área central (iglú) está bloqueada como área no transitable.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class Tablero {
    private int filas;
    private int columnas;
    private Celda[][] matriz;
    private ArrayList<Fruta> frutas;
    private ArrayList<Enemigo> enemigos;
    private ArrayList<Fogata> fogatas;
    private ArrayList<BaldosaCaliente> baldosasCalientes;
    private Helado helado;
    
    /**
     * Constructor del Tablero con matriz de Celdas.
     * Inicializa la matriz y coloca muros en los bordes.
     * @param filas número de filas del tablero
     * @param columnas número de columnas del tablero
     */
    public Tablero(int filas, int columnas) {
        this.filas = filas;
        this.columnas = columnas;
        matriz = new Celda[filas][columnas];
        frutas = new ArrayList<>();
        enemigos = new ArrayList<>();
        fogatas = new ArrayList<>();
        baldosasCalientes = new ArrayList<>();
        inicializarMatriz();
    }
    
    /**
     * Inicializa la matriz de celdas.
     * Crea todas las celdas: muros en los bordes, vacías en el interior.
     * Bloquea el área central (iglú) como área no transitable.
     */
    private void inicializarMatriz() {
        // Calcular el centro del tablero
        int centroX = columnas / 2;
        int centroY = filas / 2;
        
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                Posicion pos = new Posicion(col, fila);
                
                // Colocar muros en los bordes
                if (fila == 0 || fila == filas - 1 || col == 0 || col == columnas - 1) {
                    matriz[fila][col] = new Celda(pos, TipoCelda.MURO);
                }
                // Bloquear el área central (iglú) - 2 filas x 3 columnas en el centro
                // 2 filas: centroY-1 y centroY (subido una posición hacia arriba)
                // 3 columnas: centroX-1, centroX, centroX+1
                else if ((fila == centroY - 1 || fila == centroY) && 
                         (col >= centroX - 1 && col <= centroX + 1)) {
                    matriz[fila][col] = new Celda(pos, TipoCelda.IGLU);
                }
                else {
                    matriz[fila][col] = new Celda(pos, TipoCelda.VACIO);
                }
            }
        }
    }
    
    /**
     * Obtiene el número de columnas del tablero
     * @return columnas
     */
    public int getColumnas() {
        return columnas;
    }
    
    /**
     * Obtiene el número de filas del tablero
     * @return filas
     */
    public int getFilas() {
        return filas;
    }
    
    /**
     * Obtiene la matriz completa de celdas
     * @return matriz de celdas
     */
    public Celda[][] getMatriz() {
        return matriz;
    }
    
    /**
     * Obtiene una celda específica
     * @param pos posición de la celda
     * @return celda en esa posición
     */
    public Celda getCelda(Posicion pos) {
        if (esPosicionValida(pos)) {
            return matriz[pos.getY()][pos.getX()];
        }
        return null;
    }
    
    // Métodos de compatibilidad con código antiguo
    public int getAncho() {
        return columnas;
    }
    
    public int getAlto() {
        return filas;
    }
    
    /**
     * Establece el helado jugador y lo coloca en el tablero
     * @param helado helado jugador
     */
    public void setHelado(Helado helado) {
        this.helado = helado;
        if (helado != null) {
            Posicion pos = helado.getPosicion();
            if (esPosicionValida(pos)) {
                matriz[pos.getY()][pos.getX()].setComponente(helado);
            }
        }
    }
    
    /**
     * Obtiene el helado jugador
     * @return helado
     */
    public Helado getHelado() {
        return helado;
    }
    
    /**
     * Agrega una fruta al tablero (lista y celda)
     * @param fruta fruta a agregar
     */
    public void agregarFruta(Fruta fruta) {
        frutas.add(fruta);
        Posicion pos = fruta.getPosicion();
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].setComponente(fruta);
        }
    }
    
    /**
     * Agrega un enemigo al tablero (lista y celda)
     * @param enemigo enemigo a agregar
     */
    public void agregarEnemigo(Enemigo enemigo) {
        enemigos.add(enemigo);
        Posicion pos = enemigo.getPosicion();
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].setComponente(enemigo);
        }
    }
    
    /**
     * Agrega una fogata al tablero y marca la celda
     * @param fogata fogata a agregar
     */
    public void agregarFogata(Fogata fogata) {
        fogatas.add(fogata);
        int x = fogata.getPosicion().getX();
        int y = fogata.getPosicion().getY();
        if (y >= 0 && y < filas && x >= 0 && x < columnas) {
            matriz[y][x].getTipo().setTipo(TipoCelda.FOGATA);
        }
    }
    
    /**
     * Agrega una baldosa caliente al tablero y marca la celda
     * @param baldosa baldosa caliente a agregar
     */
    public void agregarBaldosaCaliente(BaldosaCaliente baldosa) {
        baldosasCalientes.add(baldosa);
        int x = baldosa.getPosicion().getX();
        int y = baldosa.getPosicion().getY();
        if (y >= 0 && y < filas && x >= 0 && x < columnas) {
            matriz[y][x].getTipo().setTipo(TipoCelda.BALDOSA_CALIENTE);
        }
    }
    
    /**
     * Agrega un bloque de hielo al tablero
     * Comportamiento especial:
     * - Si hay una fogata, se apaga por 5 segundos
     * - Si hay una baldosa caliente, el hielo se derrite automáticamente
     * @param bloque bloque a agregar (ahora se maneja directamente en la celda)
     */
    public void agregarBloque(BloqueHielo bloque) {
        Posicion pos = bloque.getPosicion();
        if (!esPosicionValida(pos)) return;
        
        int x = pos.getX();
        int y = pos.getY();
        int tipoCelda = matriz[y][x].getTipo().getTipo();
        
        // Si hay una fogata, apagarla temporalmente
        if (tipoCelda == TipoCelda.FOGATA) {
            // Buscar la fogata en la lista y apagarla
            for (Fogata fogata : fogatas) {
                if (fogata.getPosicion().equals(pos)) {
                    fogata.apagar();
                    break;
                }
            }
            // No crear el bloque sobre la fogata apagada
            return;
        }
        
        // Si hay una baldosa caliente, el hielo se derrite automáticamente
        if (tipoCelda == TipoCelda.BALDOSA_CALIENTE) {
            // No crear el bloque, se derrite instantáneamente
            return;
        }
        
        // Crear el bloque normalmente en otras celdas
        matriz[y][x].getTipo().setTipo(TipoCelda.BLOQUE_HIELO);
    }
    
    /**
     * Obtiene todas las frutas del tablero
     * @return lista de frutas
     */
    public ArrayList<Fruta> getFrutas() {
        return frutas;
    }
    
    /**
     * Obtiene todos los enemigos del tablero
     * @return lista de enemigos
     */
    public ArrayList<Enemigo> getEnemigos() {
        return enemigos;
    }
    
    /**
     * Obtiene la lista de fogatas
     * @return lista de fogatas
     */
    public ArrayList<Fogata> getFogatas() {
        return fogatas;
    }
    
    /**
     * Obtiene la lista de baldosas calientes
     * @return lista de baldosas calientes
     */
    public ArrayList<BaldosaCaliente> getBaldosasCalientes() {
        return baldosasCalientes;
    }
    
    /**
     * Obtiene todos los bloques del tablero (recorre la matriz)
     * @return lista de posiciones con bloques de hielo
     */
    public ArrayList<Posicion> getBloques() {
        ArrayList<Posicion> bloques = new ArrayList<>();
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                if (matriz[fila][col].getTipo().esBloqueHielo()) {
                    bloques.add(new Posicion(col, fila));
                }
            }
        }
        return bloques;
    }
    
    /**
     * Verifica si una posición está dentro del tablero
     * @param pos posición a verificar
     * @return true si es válida (dentro de los límites)
     */
    public boolean esPosicionValida(Posicion pos) {
        return pos.getX() >= 0 && pos.getX() < columnas &&
               pos.getY() >= 0 && pos.getY() < filas;
    }
    
    /**
     * Verifica si hay un bloque de hielo en una posición
     * @param pos posición a verificar
     * @return true si hay un bloque
     */
    public boolean hayBloqueEn(Posicion pos) {
        if (!esPosicionValida(pos)) return false;
        return matriz[pos.getY()][pos.getX()].getTipo().esBloqueHielo();
    }
    
    /**
     * Elimina un bloque de hielo en una posición específica
     * @param pos posición del bloque a eliminar
     */
    public void eliminarBloqueEn(Posicion pos) {
        if (esPosicionValida(pos)) {
            matriz[pos.getY()][pos.getX()].getTipo().setTipo(TipoCelda.VACIO);
        }
    }
    
    /**
     * Verifica si una posición está completamente vacía (sin bloques, muros, enemigos ni frutas)
     * @param pos posición a verificar
     * @return true si está vacía y transitable
     */
    public boolean esPosicionVacia(Posicion pos) {
        if (!esPosicionValida(pos)) return false;
        
        Celda celda = matriz[pos.getY()][pos.getX()];
        
        // Verificar que no sea muro, bloque ni iglú
        if (!celda.getTipo().esVacio()) return false;
        
        // Verificar que no tenga componente
        if (celda.tieneComponente()) return false;
        
        return true;
    }
    
    /**
     * Actualiza el estado del tablero (fogatas que se reencienden)
     */
    public void actualizarObstaculos() {
        // Actualizar fogatas (para que se reenciendan después de 5 segundos)
        for (Fogata fogata : fogatas) {
            fogata.actualizar();
            
            // Si la fogata se reencendió, restaurar el tipo de celda
            if (fogata.estaEncendida()) {
                int x = fogata.getPosicion().getX();
                int y = fogata.getPosicion().getY();
                if (y >= 0 && y < filas && x >= 0 && x < columnas) {
                    // Solo restaurar si no hay un bloque de hielo
                    if (matriz[y][x].getTipo().getTipo() != TipoCelda.BLOQUE_HIELO) {
                        matriz[y][x].getTipo().setTipo(TipoCelda.FOGATA);
                    }
                }
            }
        }
    }
    
    /**
     * Mueve un componente de una posición a otra en la matriz
     * @param origen posición origen
     * @param destino posición destino
     */
    public void moverComponente(Posicion origen, Posicion destino) {
        if (!esPosicionValida(origen) || !esPosicionValida(destino)) return;
        
        Celda celdaOrigen = matriz[origen.getY()][origen.getX()];
        Celda celdaDestino = matriz[destino.getY()][destino.getX()];
        
        // Mover el componente
        Componente componente = celdaOrigen.getComponente();
        if (componente != null) {
            celdaDestino.setComponente(componente);
            celdaOrigen.removerComponente();
        }
    }
    
    /**
     * Verifica si el helado colisiona con algún enemigo
     * @return true si hay colisión
     */
    public boolean hayColisionConEnemigo() {
        if (helado == null) return false;
        
        Posicion posHelado = helado.getPosicion();
        for (Enemigo enemigo : enemigos) {
            if (enemigo.isActiva() && enemigo.getPosicion().equals(posHelado)) {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Verifica y recolecta frutas en la posición del helado
     */
    public void verificarRecoleccionFrutas() {
        if (helado == null) return;
        
        Posicion posHelado = helado.getPosicion();
        for (Fruta fruta : frutas) {
            if (fruta.isActiva() && fruta.getPosicion().equals(posHelado)) {
                fruta.recolectar();
                helado.agregarPuntaje(fruta.getPuntaje());
            }
        }
    }
    
    /**
     * Cuenta las frutas activas restantes
     * @return número de frutas sin recolectar
     */
    public int contarFrutasActivas() {
        int contador = 0;
        for (Fruta fruta : frutas) {
            if (fruta.isActiva()) {
                contador++;
            }
        }
        return contador;
    }
    
    /**
     * Actualiza todos los componentes del tablero cada frame.
     * 1. Actualiza frutas (mueve piñas, teletransporta cerezas)
     * 2. Actualiza enemigos (calcula y ejecuta movimientos)
     * 3. Verifica si el helado recogió frutas
     */
    public void actualizar() {
        // Actualizar frutas
        for (Fruta fruta : frutas) {
            if (fruta.isActiva()) {
                fruta.actualizar();
                
                // Lógica especial para frutas que se mueven
                if (fruta instanceof Pina) {
                    ((Pina) fruta).mover(this);
                } else if (fruta instanceof Cereza) {
                    Cereza cereza = (Cereza) fruta;
                    if (cereza.debeTeletransportarse()) {
                        cereza.teletransportar(this);
                    }
                }
            }
        }
        
        // Actualizar enemigos
        for (Enemigo enemigo : enemigos) {
            if (enemigo.isActiva()) {
                enemigo.actualizar();
                enemigo.calcularMovimiento(this, helado);
            }
        }
        
        // Actualizar obstáculos (fogatas que se reencienden)
        actualizarObstaculos();
        
        // Verificar recolección de frutas
        verificarRecoleccionFrutas();
    }
    
    /**
     * Limpia todos los bloques del tablero
     */
    public void limpiarBloques() {
        for (int fila = 0; fila < filas; fila++) {
            for (int col = 0; col < columnas; col++) {
                if (matriz[fila][col].getTipo().esBloqueHielo()) {
                    matriz[fila][col].getTipo().setTipo(TipoCelda.VACIO);
                }
            }
        }
    }
    
    /**
     * Rompe un bloque de hielo en una posición específica
     * @param pos posición del bloque a romper
     */
    public void romperBloque(Posicion pos) {
        if (esPosicionValida(pos)) {
            int x = pos.getX();
            int y = pos.getY();
            if (matriz[y][x].getTipo().esBloqueHielo()) {
                matriz[y][x].getTipo().setTipo(TipoCelda.VACIO);
            }
        }
    }
}

