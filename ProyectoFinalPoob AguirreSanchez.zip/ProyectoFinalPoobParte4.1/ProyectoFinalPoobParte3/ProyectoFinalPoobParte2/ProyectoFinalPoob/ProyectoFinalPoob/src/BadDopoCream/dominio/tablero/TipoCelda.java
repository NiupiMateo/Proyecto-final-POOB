package BadDopoCream.dominio.tablero;

/**
 * Clase TipoCelda - Define los tipos de contenido que puede tener una celda del tablero.
 * VACIO: Celda libre donde se puede mover
 * MURO: Obstáculo permanente (bordes del tablero)
 * BLOQUE_HIELO: Bloque creado por el helado (destruible)
 * IGLU: Área central bloqueada permanentemente
 * FOGATA: Obstáculo que elimina helados (puede apagarse temporalmente)
 * BALDOSA_CALIENTE: Derrite bloques de hielo instantáneamente
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class TipoCelda {
    public static final int VACIO = 0;
    public static final int MURO = 1;
    public static final int BLOQUE_HIELO = 2;
    public static final int IGLU = 3;
    public static final int FOGATA = 4;
    public static final int BALDOSA_CALIENTE = 5;
    
    private int tipo;
    
    /**
     * Constructor de TipoCelda
     * @param tipo tipo de celda (VACIO, MURO, BLOQUE_HIELO)
     */
    public TipoCelda(int tipo) {
        this.tipo = tipo;
    }
    
    /**
     * Obtiene el tipo de celda
     * @return tipo
     */
    public int getTipo() {
        return tipo;
    }
    
    /**
     * Establece el tipo de celda
     * @param tipo nuevo tipo
     */
    public void setTipo(int tipo) {
        this.tipo = tipo;
    }
    
    /**
     * Verifica si la celda está vacía
     * @return true si está vacía
     */
    public boolean esVacio() {
        return tipo == VACIO;
    }
    
    /**
     * Verifica si la celda es un muro
     * @return true si es muro
     */
    public boolean esMuro() {
        return tipo == MURO;
    }
    
    /**
     * Verifica si la celda es un bloque de hielo
     * @return true si es bloque de hielo
     */
    public boolean esBloqueHielo() {
        return tipo == BLOQUE_HIELO;
    }
    
    /**
     * Verifica si la celda es un iglú
     * @return true si es iglú
     */
    public boolean esIglu() {
        return tipo == IGLU;
    }
    
    /**
     * Verifica si la celda es una fogata
     * @return true si es fogata
     */
    public boolean esFogata() {
        return tipo == FOGATA;
    }
    
    /**
     * Verifica si la celda es una baldosa caliente
     * @return true si es baldosa caliente
     */
    public boolean esBaldosaCaliente() {
        return tipo == BALDOSA_CALIENTE;
    }
}

