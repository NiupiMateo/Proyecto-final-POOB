package BadDopoCream.dominio.utilidades;

/**
 * Clase Temporizador - Controla el tiempo límite de 3 minutos por nivel.
 * Si el tiempo se agota antes de recolectar todas las frutas, el nivel se pierde.
 * Funciona con frames (60 frames = 1 segundo), asumiendo 60 FPS.
 *  @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class Temporizador {
    private int tiempoRestante; // en frames (60 frames = 1 segundo)
    private static final int TIEMPO_MAXIMO = 180 * 60; // 3 minutos en frames
    private boolean corriendo;
    
    /**
     * Constructor del Temporizador
     */
    public Temporizador() {
        this.tiempoRestante = TIEMPO_MAXIMO;
        this.corriendo = false;
    }
    
    /**
     * Inicia el temporizador
     */
    public void iniciar() {
        this.corriendo = true;
    }
    
    /**
     * Pausa el temporizador
     */
    public void pausar() {
        this.corriendo = false;
    }
    
    /**
     * Reinicia el temporizador
     */
    public void reiniciar() {
        this.tiempoRestante = TIEMPO_MAXIMO;
        this.corriendo = false;
    }
    
    /**
     * Actualiza el temporizador (llamar cada frame)
     */
    public void actualizar() {
        if (corriendo && tiempoRestante > 0) {
            tiempoRestante--;
        }
    }
    
    /**
     * Obtiene el tiempo restante en segundos
     * @return segundos restantes
     */
    public int getTiempoRestante() {
        return tiempoRestante / 60;
    }
    
    /**
     * Obtiene el tiempo restante en segundos (alias)
     * @return segundos restantes
     */
    public int getSegundosRestantes() {
        return tiempoRestante / 60;
    }
    
    /**
     * Obtiene el tiempo restante en minutos
     * @return minutos restantes
     */
    public int getMinutosRestantes() {
        return getSegundosRestantes() / 60;
    }
    
    /**
     * Obtiene los segundos de la parte decimal del tiempo
     * @return segundos (0-59)
     */
    public int getSegundosParte() {
        return getSegundosRestantes() % 60;
    }
    
    /**
     * Obtiene el tiempo formateado como MM:SS
     * @return tiempo en formato MM:SS
     */
    public String getTiempoFormateado() {
        int segundosTotal = tiempoRestante / 60;
        int minutos = segundosTotal / 60;
        int segundos = segundosTotal % 60;
        return String.format("%02d:%02d", minutos, segundos);
    }
    
    /**
     * Verifica si el tiempo se agotó
     * @return true si no queda tiempo
     */
    public boolean seAcaboElTiempo() {
        return tiempoRestante <= 0;
    }
}



