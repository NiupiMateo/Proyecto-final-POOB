package BadDopoCream.presentacion;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.SwingConstants;
import javax.swing.Timer;

import BadDopoCream.dominio.Juego;
import BadDopoCream.controladores.Controlador;

/**
 * BadDopoCreamGUI - Clase principal de la interfaz gráfica integrada con navegación
 * Incluye: panelInicio, panelModos, panelSeleccionModo, panelSeleccionJugadores,
 * panelSeleccionUnJugadorHelados, panelSelecciondosJugadorHelados, panelSeleccionNiveles,
 * panelJuego (TableroPanel).
 *
 *
 *
 *
 *
 *
 *
 *
 *
 * Flujo:
 *  Botón Jugar, luego panelSeleccionModo, luego panelSeleccionJugadores (1 jugador / 2 jugadores), luego
 *  Selección helado(s) luego, panelSeleccionNiveles y por ultimo iniciar juego 
 */
public class BadDopoCreamGUI extends JFrame {

    private static final long serialVersionUID = 1L;

    // Paneless principales
    private JPanel panelInicio;
    private JPanel panelModos;
    private JPanel panelSeleccionModo;
    private JPanel panelSeleccionNiveles;
    private JPanel panelSeleccionJugadores;
    private JPanel panelSeleccionUnJugadorHelados;
    private JPanel panelSelecciondosJugadorHelados;

    // Panel del juego (dibujo)
    private TableroPanel panelJuego;

    // Modelo y controlador
    private Juego juego;
    private Controlador controlador;

    // Estado / selección
    private String modoJuegoActual;
    private int nivelSeleccionado = 1;
    private String heladoJugador1 = "Vainilla";
    private String heladoJugador2 = "Vainilla";
    private String modoSeleccionado = "";

    // Botones que referenciamos
    private JButton botonJugar;
    private JButton botonPvsP;
    private JButton botonPvsM;
    private JButton botonMvsM;
    private JButton botonJugador1;
    private JButton botonJugador2;
    private JButton botonUnJugadorVainilla;
    private JButton botonUnJugadorChocolate;
    private JButton botonUnJugadorFresa;
    private JButton botonDosJ1Vainilla;
    private JButton botonDosJ1Chocolate;
    private JButton botonDosJ1Fresa;
    private JButton botonDosJ2Vainilla;
    private JButton botonDosJ2Chocolate;
    private JButton botonDosJ2Fresa;
    
    // Temporizador para el juego
    private Timer gameLoopTimer;

    // Constructor
    public BadDopoCreamGUI() {
        setTitle("Bad Dopo Cream");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);
        setResizable(false);
        getContentPane().setLayout(null);

        // Inicializamos el modelo y controlador
        juego = new Juego();
        controlador = new Controlador(juego, this);

        // Crear paneles
        crearPanelInicio();
        crearPanelModos();
        crearPanelSeleccionModo();
        crearPanelSeleccionJugadores();          // pantalla 3
        crearPanelSeleccionUnJugadorHelados();   // pantalla 3.1
        crearPanelSelecciondosJugadorHelados();  // pantalla 3.2
        crearPanelSeleccionNiveles();

        // Añadir paneles al content pane
        getContentPane().add(panelInicio);
        getContentPane().add(panelModos);
        getContentPane().add(panelSeleccionModo);
        getContentPane().add(panelSeleccionJugadores);
        getContentPane().add(panelSeleccionUnJugadorHelados);
        getContentPane().add(panelSelecciondosJugadorHelados);
        getContentPane().add(panelSeleccionNiveles);

        // Iniciar visibilidades
        panelInicio.setVisible(true);
        panelModos.setVisible(false);
        panelSeleccionModo.setVisible(false);
        panelSeleccionJugadores.setVisible(false);
        panelSeleccionUnJugadorHelados.setVisible(false);
        panelSelecciondosJugadorHelados.setVisible(false);
        panelSeleccionNiveles.setVisible(false);

        // Preparar acciones de cada ventana
        prepareActions();
    }

    // Crear panel de inicio
    private void crearPanelInicio() {
        panelInicio = new JPanel();
        panelInicio.setLayout(null);
        panelInicio.setBounds(0, 0, 900, 700);
        panelInicio.setOpaque(false);

        JLabel titulo = new JLabel("BAD DOPO CREAM");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 40));
        titulo.setForeground(Color.BLACK);
        titulo.setBounds(250, 37, 450, 50);
        panelInicio.add(titulo);

        JButton botonStart = new JButton("Click Para Empezar");
        botonStart.setVerticalAlignment(SwingConstants.BOTTOM);
        botonStart.setFont(new Font("Segoe UI", Font.BOLD, 16));
        botonStart.setBounds(320, 623, 250, 28);
        botonStart.setBackground(Color.LIGHT_GRAY);
        botonStart.setForeground(Color.BLACK);
        botonStart.setFocusPainted(false);
        panelInicio.add(botonStart);

        // Fondo como etiqueta de imagen personalizada(inicio)
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
            if (url != null) {
                ImageIcon imagenOriginal = new ImageIcon(url);
                java.awt.Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondo = new ImageIcon(imagenEscalada);
                JLabel fondoLabel = new JLabel(fondo);
                fondoLabel.setBounds(100, 100, 700, 500);
                panelInicio.add(fondoLabel);
            } else {
                System.err.println("Imagen de fondo no encontrada: BadDopoCream.jpeg");
            }
        } catch (Exception ex) {
            System.err.println("Error cargando imagen de inicio: " + ex.getMessage());
        }

        botonStart.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelInicio.setVisible(false);
                panelModos.setVisible(true);
            }
        });
    }

    /* Método: crearPanelModos
    * Crea y configura el panel principal donde se muestran los botones
    * "Jugar", "Configuración" y "Salir", junto con el título y el fondo personalizado inicial.
    **/
    private void crearPanelModos() {
        panelModos = new JPanel();
        panelModos.setLayout(null);
        panelModos.setBounds(0, 0, 900, 700);
        panelModos.setOpaque(false);

        JLabel tituloModos = new JLabel("BAD DOPO CREAM");
        tituloModos.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tituloModos.setForeground(Color.BLACK);
        tituloModos.setBounds(250, 37, 450, 50);
        panelModos.add(tituloModos);

        botonJugar = new JButton("Jugar");
        botonJugar.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonJugar.setBounds(200, 610, 150, 35);
        botonJugar.setBackground(Color.LIGHT_GRAY);
        botonJugar.setForeground(Color.BLACK);
        botonJugar.setFocusPainted(false);
        panelModos.add(botonJugar);

        JButton botonConfig = new JButton("Configuración");
        botonConfig.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonConfig.setBounds(370, 610, 180, 35);
        botonConfig.setBackground(Color.LIGHT_GRAY);
        botonConfig.setForeground(Color.BLACK);
        botonConfig.setFocusPainted(false);
        panelModos.add(botonConfig);

        JButton botonSalir = new JButton("Salir");
        botonSalir.setFont(new Font("Segoe UI", Font.BOLD, 20));
        botonSalir.setBounds(570, 610, 150, 35);
        botonSalir.setBackground(Color.LIGHT_GRAY);
        botonSalir.setForeground(Color.BLACK);
        botonSalir.setFocusPainted(false);
        panelModos.add(botonSalir);

        // Fondo del panel 
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
            // Si se encuentra la imagen, se escala y se agrega al panel
            if (url != null) {
                ImageIcon imagenOriginal = new ImageIcon(url);
                java.awt.Image imagenEscalada = imagenOriginal.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondo = new ImageIcon(imagenEscalada);
                JLabel fondoModos = new JLabel(fondo);
                fondoModos.setBounds(100, 100, 700, 500);
                panelModos.add(fondoModos);
            }
        } catch (Exception ex) {
            System.err.println("Error cargando fondo de modos: " + ex.getMessage());
        }

        // Listeners de los botones

        /* Al presionar "Jugar" se oculta este panel y se muestra el de selección de modo */
        botonJugar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelModos.setVisible(false);
                panelSeleccionModo.setVisible(true);
            }
        });
        /* Al presionar "Configuración" se muestra un mensaje indicando que está pendiente(Falta Implementacion) */
        botonConfig.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(BadDopoCreamGUI.this, "Configuración (pendiente)");
            }
        });
        
        botonSalir.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(BadDopoCreamGUI.this, "¿Estás seguro que deseas salir del juego?", "Salir del Juego", JOptionPane.YES_NO_OPTION);
                if (confirmar == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });
    }

    /** Método: crearPanelSeleccionModo (Pantalla 2)
    * Crea el panel donde el usuario elige
    * el modo de juego: PvP, PvM o MvM.
    **/ 
    private void crearPanelSeleccionModo() {
        panelSeleccionModo = new JPanel();
        panelSeleccionModo.setLayout(null);
        panelSeleccionModo.setBounds(0, 0, 900, 700);
        panelSeleccionModo.setOpaque(false);

        JLabel tituloSeleccion = new JLabel("Selecciona un modo de juego");
        tituloSeleccion.setFont(new Font("Segoe UI", Font.BOLD, 30));
        tituloSeleccion.setForeground(Color.BLACK);
        tituloSeleccion.setBounds(200, 37, 550, 50);
        panelSeleccionModo.add(tituloSeleccion);

        botonPvsP = new JButton("Jugador vs Jugador");
        botonPvsP.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonPvsP.setBounds(300, 200, 300, 45);
        botonPvsP.setBackground(Color.LIGHT_GRAY);
        botonPvsP.setForeground(Color.BLACK);
        botonPvsP.setFocusPainted(false);
        panelSeleccionModo.add(botonPvsP);

        botonPvsM = new JButton("Jugador vs Maquina");
        botonPvsM.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonPvsM.setBounds(300, 280, 300, 45);
        botonPvsM.setBackground(Color.LIGHT_GRAY);
        botonPvsM.setForeground(Color.BLACK);
        botonPvsM.setFocusPainted(false);
        panelSeleccionModo.add(botonPvsM);

        botonMvsM = new JButton("Maquina vs Maquina");
        botonMvsM.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonMvsM.setBounds(300, 360, 300, 45);
        botonMvsM.setBackground(Color.LIGHT_GRAY);
        botonMvsM.setForeground(Color.BLACK);
        botonMvsM.setFocusPainted(false);
        panelSeleccionModo.add(botonMvsM);

        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 440, 300, 45);
        botonVolver.setBackground(Color.LIGHT_GRAY);
        botonVolver.setForeground(Color.BLACK);
        botonVolver.setFocusPainted(false);
        panelSeleccionModo.add(botonVolver);

        // Fondo imagen del panel
        try {
            java.net.URL url = getClass().getResource("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
            /* Si la imagen existe, se escala y se agrega al panel */
            if (url != null) {
                ImageIcon fondoImg = new ImageIcon(url);
                Image imagen = fondoImg.getImage().getScaledInstance(700, 500, java.awt.Image.SCALE_SMOOTH);
                JLabel fondoSeleccion = new JLabel(new ImageIcon(imagen));
                fondoSeleccion.setBounds(100, 100, 700, 500);
                panelSeleccionModo.add(fondoSeleccion);
            }
        } catch (Exception ex) {
            System.err.println("Error cargando fondo de selección de modo: " + ex.getMessage());
        }

        // Listeners
        /* Opción: Jugador vs Jugador*/
        botonPvsP.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modoJuegoActual = "PvsP";
                panelSeleccionModo.setVisible(false);
                panelSeleccionJugadores.setVisible(true);
            }
        });

        /* Opción: Jugador vs Maquina*/
        botonPvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modoJuegoActual = "PvsM";
                panelSeleccionModo.setVisible(false);
                panelSeleccionJugadores.setVisible(true);
            }
        });

        /* Opción: Maquina vs Maquina*/
        botonMvsM.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                modoJuegoActual = "MvsM";
                panelSeleccionModo.setVisible(false);
                // Para MvsM se puede ir directamente a niveles o mostrar otro panel, aquí dejamos a selecciónJugadores
                panelSeleccionJugadores.setVisible(true);
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionModo.setVisible(false);
                panelModos.setVisible(true);
            }
        });
    }

    // -------------------------------
    // Método: crearPanelSeleccionJugadores (Pantalla 3)
    // -------------------------------
    private void crearPanelSeleccionJugadores() {
        panelSeleccionJugadores = new JPanel();
        panelSeleccionJugadores.setLayout(null);
        panelSeleccionJugadores.setBounds(0, 0, 900, 700);
        panelSeleccionJugadores.setOpaque(false);

        JLabel seleccionJugadores = new JLabel("Seleccione cuantos jugadores van a jugar");
        seleccionJugadores.setFont(new Font("Segoe UI", Font.BOLD, 30));
        seleccionJugadores.setForeground(Color.BLACK);
        seleccionJugadores.setBounds(170, 40, 700, 50);
        panelSeleccionJugadores.add(seleccionJugadores);

        JButton botonJugador1 = new JButton();
        botonJugador1.setBounds(150, 220, 170, 170);
        botonJugador1.setFocusPainted(false);
        botonJugador1.setOpaque(false);
        botonJugador1.setContentAreaFilled(false);
        botonJugador1.setBorderPainted(false);
        panelSeleccionJugadores.add(botonJugador1);

        JButton botonJugador2 = new JButton();
        botonJugador2.setBounds(550, 220, 170, 170);
        botonJugador2.setFocusPainted(false);
        botonJugador2.setFocusPainted(false);
        botonJugador2.setOpaque(false);
        botonJugador2.setContentAreaFilled(false);
        botonJugador2.setBorderPainted(false);
        panelSeleccionJugadores.add(botonJugador2);

        JButton botonAtras = new JButton("Volver");
        botonAtras.setFont(new Font("Segoe UIi", Font.BOLD, 22));
        botonAtras.setBounds(372, 560, 150, 45);
        botonAtras.setBackground(new Color(245,222,179));
        botonAtras.setContentAreaFilled(true);
        botonAtras.setFocusPainted(false);
        botonAtras.setBorderPainted(false);
        panelSeleccionJugadores.add(botonAtras);

        // FONDO - Se agrega AL FINAL para que quede detrás
        try {
            ImageIcon imagenOriginalJugadores = new ImageIcon(getClass().getResource("/BadDopoCream/presentacion/recursos/Jugadores.jpg"));
            if (imagenOriginalJugadores.getImage() != null) {
                java.awt.Image imagenEscaladaJugadores = imagenOriginalJugadores.getImage().getScaledInstance(900, 700, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondoJugadores = new ImageIcon(imagenEscaladaJugadores);
                JLabel fondoLabelJugadores = new JLabel(fondoJugadores);
                fondoLabelJugadores.setBounds(0, 0, 900, 700);
                panelSeleccionJugadores.add(fondoLabelJugadores);
            } else {
                // Si no se carga la imagen, usar un fondo de color
                JLabel fondoColor = new JLabel();
                fondoColor.setOpaque(true);
                fondoColor.setBackground(new Color(70, 130, 180));
                fondoColor.setBounds(0, 0, 900, 700);
                panelSeleccionJugadores.add(fondoColor);
            }
        } catch (Exception ex) {
            System.err.println("No se pudo cargar Jugadores.jpg: " + ex.getMessage());
            // Fondo de color alternativo
            JLabel fondoColor = new JLabel();
            fondoColor.setOpaque(true);
            fondoColor.setBackground(new Color(70, 130, 180));
            fondoColor.setBounds(0, 0, 900, 700);
            panelSeleccionJugadores.add(fondoColor);
        }

        // Listeners para abrir pantallas 3.1 y 3.2
        botonJugador1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Un jugador -> ir a selección de helado 1 jugador
                panelSeleccionJugadores.setVisible(false);
                panelSeleccionUnJugadorHelados.setVisible(true);
            }
        });

        botonJugador2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // Dos jugadores -> ir a selección de helados para dos jugadores
                panelSeleccionJugadores.setVisible(false);
                panelSelecciondosJugadorHelados.setVisible(true);
            }
        });

        botonAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionJugadores.setVisible(false);
                panelSeleccionModo.setVisible(true);
            }
        });
    }

    // -------------------------------
    // Método: crearPanelSeleccionUnJugadorHelados (Pantalla 3.1)
    // -------------------------------
    private void crearPanelSeleccionUnJugadorHelados() {
        panelSeleccionUnJugadorHelados = new JPanel();
        panelSeleccionUnJugadorHelados.setLayout(null);
        panelSeleccionUnJugadorHelados.setBounds(0, 0, 900, 700);
        panelSeleccionUnJugadorHelados.setOpaque(false);

        JLabel titulo = new JLabel("Seleccione un tipo de helado");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 36));
        titulo.setForeground(Color.WHITE);
        titulo.setBounds(200, 30, 600, 50);
        panelSeleccionUnJugadorHelados.add(titulo);

        JButton botonVainilla = new JButton("");
        botonVainilla.setBounds(420, 220, 75, 75);
        botonVainilla.setFocusPainted(false);
        botonVainilla.setFocusPainted(false);
        botonVainilla.setOpaque(false);
        botonVainilla.setContentAreaFilled(false);
        botonVainilla.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonVainilla);

        JButton botonChocolate = new JButton("");
        botonChocolate.setBounds(325, 200, 75, 75);
        botonChocolate.setFocusPainted(false);
        botonChocolate.setFocusPainted(false);
        botonChocolate.setOpaque(false);
        botonChocolate.setContentAreaFilled(false);
        botonChocolate.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonChocolate);

        JButton botonFresa = new JButton("");
        botonFresa.setBounds(515, 200,75, 75);
        botonFresa.setFocusPainted(false);
        botonFresa.setFocusPainted(false);
        botonFresa.setOpaque(false);
        botonFresa.setContentAreaFilled(false);
        botonFresa.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonFresa);
        
        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UIi", Font.BOLD, 22));
        botonVolver.setBounds(372, 560, 150, 45);
        botonVolver.setBackground(new Color(245,222,179));
        botonVolver.setContentAreaFilled(true);
        botonVolver.setFocusPainted(false);
        botonVolver.setBorderPainted(false);
        panelSeleccionUnJugadorHelados.add(botonVolver);

        // Listeners: guardar selección y avanzar a niveles
        botonVainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Vainilla";
                panelSeleccionUnJugadorHelados.setVisible(false);
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonChocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Chocolate";
                panelSeleccionUnJugadorHelados.setVisible(false);
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonFresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Fresa";
                panelSeleccionUnJugadorHelados.setVisible(false);
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionUnJugadorHelados.setVisible(false);
                panelSeleccionJugadores.setVisible(true);
            }
        });

        // FONDO - Se agrega AL FINAL para que quede detrás
        try {
            ImageIcon imagenOriginalPlayer1 = new ImageIcon(getClass().getResource("/BadDopoCream/presentacion/recursos/JugadorUno.jpg"));
            if (imagenOriginalPlayer1.getImage() != null) {
                java.awt.Image imagenEscaladaPlayer1 = imagenOriginalPlayer1.getImage().getScaledInstance(900, 700, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondoPlayer1 = new ImageIcon(imagenEscaladaPlayer1);
                JLabel fondoLabelPlayer1 = new JLabel(fondoPlayer1);
                fondoLabelPlayer1.setBounds(0, 0, 900, 700);
                panelSeleccionUnJugadorHelados.add(fondoLabelPlayer1);
            } else {
                JLabel fondoColor = new JLabel();
                fondoColor.setOpaque(true);
                fondoColor.setBackground(new Color(100, 180, 100));
                fondoColor.setBounds(0, 0, 900, 700);
                panelSeleccionUnJugadorHelados.add(fondoColor);
            }
        } catch (Exception ex) {
            System.err.println("No se pudo cargar JugadorUno.jpg: " + ex.getMessage());
            JLabel fondoColor = new JLabel();
            fondoColor.setOpaque(true);
            fondoColor.setBackground(new Color(100, 180, 100));
            fondoColor.setBounds(0, 0, 900, 700);
            panelSeleccionUnJugadorHelados.add(fondoColor);
        }
    }

    /* -------------------------------
    * Método: crearPanelSelecciondosJugadorHelados (Pantalla 3.2)
    * Pantalla donde el usuario elige si jugará 1 jugador o 2.
    */
    private void crearPanelSelecciondosJugadorHelados() {
        panelSelecciondosJugadorHelados = new JPanel();
        panelSelecciondosJugadorHelados.setLayout(null);
        panelSelecciondosJugadorHelados.setBounds(0, 0, 900, 700);
        panelSelecciondosJugadorHelados.setOpaque(false);

        JLabel titulo = new JLabel("Seleccione helado para cada jugador");
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 30));
        titulo.setForeground(Color.WHITE);
        titulo.setBounds(160, 20, 700, 50);
        panelSelecciondosJugadorHelados.add(titulo);

        // Jugador 1 columna
        JButton j1Vainilla = new JButton("Vainilla");
        j1Vainilla.setBounds(220, 200, 75, 75);
        j1Vainilla.setFocusPainted(false);
        j1Vainilla.setFocusPainted(false);
        j1Vainilla.setOpaque(false);
        j1Vainilla.setContentAreaFilled(false);
        j1Vainilla.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j1Vainilla);

        JButton j1Chocolate = new JButton("Chocolate");
        j1Chocolate.setBounds(130, 180, 75, 75);
        j1Chocolate.setFocusPainted(false);
        j1Chocolate.setFocusPainted(false);
        j1Chocolate.setOpaque(false);
        j1Chocolate.setContentAreaFilled(false);
        j1Chocolate.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j1Chocolate);

        JButton j1Fresa = new JButton("Fresa");
        j1Fresa.setBounds(310, 180, 75, 75);
        j1Fresa.setFocusPainted(false);
        j1Fresa.setFocusPainted(false);
        j1Fresa.setOpaque(false);
        j1Fresa.setContentAreaFilled(false);
        j1Fresa.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j1Fresa);

        // Jugador 2 columna
     
        JButton j2Vainilla = new JButton("");
        j2Vainilla.setBounds(610, 200, 75, 75);
        j2Vainilla.setFocusPainted(false);
        j2Vainilla.setFocusPainted(false);
        j2Vainilla.setOpaque(false);
        j2Vainilla.setContentAreaFilled(false);
        j2Vainilla.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j2Vainilla);

        JButton j2Chocolate = new JButton("");
        j2Chocolate.setBounds(520,180, 75, 75);
        j2Chocolate.setBounds(130, 180, 75, 75);
        j2Chocolate.setFocusPainted(false);
        j2Chocolate.setFocusPainted(false);
        j2Chocolate.setOpaque(false);
        j2Chocolate.setContentAreaFilled(false);
        j2Chocolate.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j2Chocolate);

        JButton j2Fresa = new JButton("");
        j2Fresa.setBounds(700, 180, 75, 75);
        j2Fresa.setFocusPainted(false);
        j2Fresa.setFocusPainted(false);
        j2Fresa.setOpaque(false);
        j2Fresa.setContentAreaFilled(false);
        j2Fresa.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(j2Fresa);

        // Boton continuar 
        JButton botonContinuar = new JButton("Continuar");
        botonContinuar.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonContinuar.setBackground(new Color(245,222,179));
        botonContinuar.setContentAreaFilled(true);
        botonContinuar.setFocusPainted(false);
        botonContinuar.setBorderPainted(false);
        botonContinuar.setBounds(300, 480, 300, 45);
        panelSelecciondosJugadorHelados.add(botonContinuar);

        //Boton volver
        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 560, 300, 45);
        botonVolver.setBackground(new Color(245,222,179));
        botonVolver.setContentAreaFilled(true);
        botonVolver.setFocusPainted(false);
        botonVolver.setBorderPainted(false);
        panelSelecciondosJugadorHelados.add(botonVolver);

        // Listeners helados para J1
        j1Vainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Vainilla";
            }
        });
        j1Chocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Chocolate";
            }
        });
        j1Fresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador1 = "Fresa";
            }
        });

        // Listeners helados para J2
        j2Vainilla.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador2 = "Vainilla";
            }
        });
        j2Chocolate.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador2 = "Chocolate";
            }
        });
        j2Fresa.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                heladoJugador2 = "Fresa";
            }
        });

        // Botón continuar para ir a niveles (guardamos helados seleccionados)
        botonContinuar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                // si no se seleccionó alguno, se asume el helado Vainilla por defecto
                if (heladoJugador1 == null || heladoJugador1.isEmpty()) heladoJugador1 = "Vainilla";
                if (heladoJugador2 == null || heladoJugador2.isEmpty()) heladoJugador2 = "Vainilla";

                panelSelecciondosJugadorHelados.setVisible(false);
                panelSeleccionNiveles.setVisible(true);
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSelecciondosJugadorHelados.setVisible(false);
                panelSeleccionJugadores.setVisible(true);
            }
        });

        // Fondo de la pantalla al final
        try {
            ImageIcon imagenOriginalPlayer2 = new ImageIcon(getClass().getResource("/BadDopoCream/presentacion/recursos/JugadoresDos.jpg"));
            if (imagenOriginalPlayer2.getImage() != null) {
                java.awt.Image imagenEscaladaPlayer2 = imagenOriginalPlayer2.getImage().getScaledInstance(900, 700, java.awt.Image.SCALE_SMOOTH);
                ImageIcon fondoPlayer2 = new ImageIcon(imagenEscaladaPlayer2);
                JLabel fondoLabelPlayer2 = new JLabel(fondoPlayer2);
                fondoLabelPlayer2.setBounds(0, 0, 900, 700);
                panelSelecciondosJugadorHelados.add(fondoLabelPlayer2);
            } else {
                JLabel fondoColor = new JLabel();
                fondoColor.setOpaque(true);
                fondoColor.setBackground(new Color(180, 100, 150));
                fondoColor.setBounds(0, 0, 900, 700);
                panelSelecciondosJugadorHelados.add(fondoColor);
            }
        } catch (Exception ex) {
            System.err.println("No se pudo cargar JugadoresDos.jpg: " + ex.getMessage());
            JLabel fondoColor = new JLabel();
            fondoColor.setOpaque(true);
            fondoColor.setBackground(new Color(180, 100, 150));
            fondoColor.setBounds(0, 0, 900, 700);
            panelSelecciondosJugadorHelados.add(fondoColor);
        }
    }

    /**
    * Método: crearPanelSeleccionNiveles
    * Pantalla donde se elige el nivel antes de iniciar el juego.
    */
    private void crearPanelSeleccionNiveles() {
        // Panel con fondo personalizado (clase PanelConFondo)
        panelSeleccionNiveles = new PanelConFondo("/BadDopoCream/presentacion/recursos/BadDopoCream.jpeg");
        panelSeleccionNiveles.setLayout(null);
        panelSeleccionNiveles.setBounds(0, 0, 900, 700);

        JLabel tituloNiveles = new JLabel("Selecciona un nivel");
        tituloNiveles.setFont(new Font("Segoe UI", Font.BOLD, 40));
        tituloNiveles.setForeground(Color.BLACK);
        tituloNiveles.setBounds(270, 37, 450, 50);
        panelSeleccionNiveles.add(tituloNiveles);

        //Boton del nivel uno
        JButton botonNivelUno = new JButton("Nivel 1");
        botonNivelUno.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonNivelUno.setBounds(300, 250, 300, 45);
        panelSeleccionNiveles.add(botonNivelUno);

        //Boton del nivel dos
        JButton botonNivelDos = new JButton("Nivel 2");
        botonNivelDos.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonNivelDos.setBounds(300, 320, 300, 45);
        panelSeleccionNiveles.add(botonNivelDos);


        //Boton del nivel tres  
        JButton botonNivelTres = new JButton("Nivel 3");
        botonNivelTres.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonNivelTres.setBounds(300, 390, 300, 45);
        panelSeleccionNiveles.add(botonNivelTres);

        //Boton volver
        JButton botonVolver = new JButton("Volver");
        botonVolver.setFont(new Font("Segoe UI", Font.BOLD, 22));
        botonVolver.setBounds(300, 460, 300, 45);
        panelSeleccionNiveles.add(botonVolver);

        // Listeners de los botones de nivel
        botonNivelUno.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nivelSeleccionado = 1;
                iniciarJuegoDesdeSeleccion();  // Método que inicia el juego según el nivel elegido
            }
        });
    
        botonNivelDos.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nivelSeleccionado = 2;
                iniciarJuegoDesdeSeleccion();
            }
        });

        botonNivelTres.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                nivelSeleccionado = 3;
                iniciarJuegoDesdeSeleccion();
            }
        });

        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                panelSeleccionNiveles.setVisible(false);
                // Volver a la pantalla según modo
                if ("PvsP".equals(modoJuegoActual) || "PvsM".equals(modoJuegoActual) || "MvsM".equals(modoJuegoActual)) {
                    // si venimos de selección de jugadores, regresar a ella
                    panelSeleccionJugadores.setVisible(true);
                } else {
                    panelSeleccionModo.setVisible(true);
                }
            }
        });
    }

    /**
    * Método: iniciarJuegoDesdeSeleccion
    * Se ejecuta después de elegir nivel y helado(s).
    * Prepara el juego, crea el panel del tablero y arranca el game loop.
    **/ 
    private void iniciarJuegoDesdeSeleccion() {
        // configurar modo y tipo de helado(s) en el juego
        try {
            // Detener game loop anterior si existe
            detenerGameLoop();
            
            // Se define el modo de juego
            String modo = modoJuegoActual;
            if (modo == null || modo.isEmpty()){
             modo = "PvsM"; // por defecto
            }
            // Elegimos helado 1 (en modo 1 jugador usamos heladoJugador1, en 2 jugadores ambos)
            String tipoHelado;
            if (heladoJugador1 != null) {
                tipoHelado = heladoJugador1;
            } else {
                tipoHelado = "Vainilla"; // por defecto
            }

            // Iniciamos el juego primero con la logica.
            juego.iniciarJuego(nivelSeleccionado, tipoHelado, modo);

            // Si se tenia un panelJuego anterior, quitarlo
            if (panelJuego != null) {
                getContentPane().remove(panelJuego);
                panelJuego = null;
            }

            // Crear nuevo TableroPanel 
            panelJuego = new TableroPanel(juego, modo, controlador);
            panelJuego.setBounds(0, 0, 900, 700);
            getContentPane().add(panelJuego);

            // Se ocultan todos los paneles de menú
            panelInicio.setVisible(false);
            panelModos.setVisible(false);
            panelSeleccionModo.setVisible(false);
            panelSeleccionJugadores.setVisible(false);
            panelSeleccionUnJugadorHelados.setVisible(false);
            panelSelecciondosJugadorHelados.setVisible(false);
            panelSeleccionNiveles.setVisible(false);

            panelJuego.setVisible(true);

            // Actualizamos componentes 
            getContentPane().revalidate();
            getContentPane().repaint();

            // Configurar controles de teclado
            configurarControles();
            
            // Iniciar game loop despues de configurar todo
            iniciarGameLoop();
            
            // Asegurar foco despues de iniciar el game loop
            SwingUtilities.invokeLater(new Runnable() {
                public void run() {
                    requestFocusInWindow();
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error al iniciar el juego: " + e.getMessage());
        }
    }

    /**
    * Método: prepareActions (cerrar ventana)
    * Configura la acción al intentar cerrar la ventana del juego.
    **/
    private void prepareActions() {
        // Evita que la ventana se cierre automáticamente al pulsar la X.
        // Deja el control del cierre en manos del WindowListener.
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        // Añade un listener para detectar cuando el usuario intenta cerrar la ventana
        addWindowListener(new java.awt.event.WindowAdapter() {
            // Este método se ejecuta cuando se intenta cerrar la ventana.
            public void windowClosing(java.awt.event.WindowEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(
                        null,
                        "¿Estás seguro que deseas salir del juego?",
                        "Salir del Juego",
                        JOptionPane.YES_NO_OPTION
                    );
                    if (confirmar == JOptionPane.YES_OPTION) {
                        System.exit(0); // termina toda la aplicación
                    }
            }   
        });
    }
   
    /** 
    * Clase interna: PanelConFondo (para fondos)
    * Permite crear un JPanel con una imagen de fondo.
    **/
    private static class PanelConFondo extends JPanel {
        private static final long serialVersionUID = 1L;  // Para la serialización de la clase
        private Image imagen; //Imagen de fondo
        //Constructor que recibe la ruta de la imagen
        public PanelConFondo(String ruta) {
            // Cargar la imagen desde los recursos de la clase
            try {
                ImageIcon icon = new ImageIcon(PanelConFondo.class.getResource(ruta));
                imagen = icon.getImage();
                // Comprobar si la imagen se cargó correctamente
                if (imagen == null) {
                    System.err.println("No se pudo cargar la imagen: " + ruta);
                }
            } catch (Exception e) {
                // Captura cualquier error al cargar la imagen
                System.err.println("Error al cargar imagen: " + ruta);
                e.printStackTrace();
                imagen = null; // En caso de error, la imagen queda como null
            } 
            // Configuraciones del panel
            setLayout(null); //Layout nulo, para posicionar componentes manualmente
            setOpaque(true); //Debe ser opaco para que se pinte el fondo
        }

        
        /* Método que dibuja el panel con su imagen de fondo */
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g); // Llama al método padre para mantener el pintado normal
            if (imagen != null) {
                g.drawImage(imagen, 0, 0, getWidth(), getHeight(), this); //Dibuja la imagen escalada al tamaño del panel
            } else {
                // Si no hay imagen, pintar un color de fondo para debug
                g.setColor(new Color(240, 240, 240));
                g.fillRect(0, 0, getWidth(), getHeight());
            }
        }
    }

    /*Metodos para el controlador */
    
    /**
     * Configura los controles del teclado para el juego
     */
    private void configurarControles() {
        // Remover listeners previos del frame
        for (KeyListener kl : getKeyListeners()) {
            removeKeyListener(kl);
        }
        
        // Remover listeners previos del panel si existe
        if (panelJuego != null) {
            for (KeyListener kl : panelJuego.getKeyListeners()) {
                panelJuego.removeKeyListener(kl);
            }
        }
        
        // Crear el KeyListener
        KeyAdapter keyAdapter = new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                int key = e.getKeyCode();
                
                // Controles de movimiento (flechas)
                if (key == KeyEvent.VK_UP) {
                    controlador.manejarEvento("MOVER_ARRIBA");
                } else if (key == KeyEvent.VK_DOWN) {
                    controlador.manejarEvento("MOVER_ABAJO");
                } else if (key == KeyEvent.VK_LEFT) {
                    controlador.manejarEvento("MOVER_IZQUIERDA");
                } else if (key == KeyEvent.VK_RIGHT) {
                    controlador.manejarEvento("MOVER_DERECHA");
                }
                
                // Acción de bloque (espacio)
                else if (key == KeyEvent.VK_SPACE) {
                    controlador.manejarEvento("ACCION_BLOQUE");
                }
                
                // Pausa (P o ESC)
                else if (key == KeyEvent.VK_P || key == KeyEvent.VK_ESCAPE) {
                    controlador.manejarEvento("PAUSAR_JUEGO");
                }
            }
        };
        
        // Añadir el listener tanto al frame como al panel de juego
        addKeyListener(keyAdapter);
        if (panelJuego != null) {
            panelJuego.addKeyListener(keyAdapter);
            panelJuego.setFocusable(true);
        }
        
        setFocusable(true);
        requestFocusInWindow();
    }
    
    /**
     * Inicia el game loop que actualiza el juego constantemente
     */
    private void iniciarGameLoop() {
        // Detener timer anterior si existe
        if (gameLoopTimer != null && gameLoopTimer.isRunning()) {
            gameLoopTimer.stop();
        }
        
        System.out.println("Iniciando game loop...");
        
        // Crear nuevo timer: 60 FPS (16ms por frame)
        gameLoopTimer = new Timer(16, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.manejarEvento("ACTUALIZAR");
            }
        });
        gameLoopTimer.start();
        
        System.out.println("Game loop iniciado. Timer activo: " + gameLoopTimer.isRunning());
    }
    
    /**
     * Detiene el game loop
     */
    private void detenerGameLoop() {
        if (gameLoopTimer != null && gameLoopTimer.isRunning()) {
            gameLoopTimer.stop();
        }
    }
    
    /**
     * Actualiza la vista (llamado por el controlador)
     */
    public void actualizarVista() {
        if (panelJuego != null && panelJuego.isVisible()) {
            panelJuego.repaint();
        }
    }
    
    /**
     * Reinicia el juego con el modo actual
     */
    public void reiniciarJuego(String modoJuego) {
        this.modoJuegoActual = modoJuego;
        iniciarJuegoDesdeSeleccion();
        // Restaurar el foco después de reiniciar
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                requestFocusInWindow();
            }
        });
    }
    
    /**
     * Vuelve al menú principal
     */
    public void volverAlInicio() {
        detenerGameLoop();
        
        // Ocultar panel de juego
        if (panelJuego != null) {
            panelJuego.setVisible(false);
            getContentPane().remove(panelJuego);
            panelJuego = null;
        }
        
        // Mostrar panel de selección de niveles
        panelSeleccionNiveles.setVisible(true);
        
        getContentPane().revalidate();
        getContentPane().repaint();
    }
    
    /**
     * Restaura el foco a la ventana principal
     */
    public void restaurarFoco() {
        requestFocusInWindow();
    }
    
    /**
     * Muestra mensaje de victoria
     */
    public void mostrarVictoria() {
        detenerGameLoop();
        int opcion = JOptionPane.showOptionDialog(
            this,
            "¡Felicidades! Has completado el nivel " + nivelSeleccionado,
            "¡Victoria!",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.INFORMATION_MESSAGE,
            null,
            new Object[]{"Siguiente Nivel", "Menú Principal"},
            "Siguiente Nivel"
        );
        
        if (opcion == 0) {
            // Siguiente nivel
            if (nivelSeleccionado < 3) {
                nivelSeleccionado++;
                iniciarJuegoDesdeSeleccion();
            } else {
                mostrarGameOver();
            }
        } else {
            // Volver al menú
            volverAlInicio();
        }
    }
    
    /**
     * Muestra mensaje de derrota
     */
    public void mostrarDerrota() {
        detenerGameLoop();
        int opcion = JOptionPane.showOptionDialog(
            this,
            "Has perdido. ¿Qué deseas hacer?",
            "Derrota",
            JOptionPane.YES_NO_OPTION,
            JOptionPane.WARNING_MESSAGE,
            null,
            new Object[]{"Reintentar", "Menú Principal"},
            "Reintentar"
        );
        
        if (opcion == 0) {
            // Reintentar
            iniciarJuegoDesdeSeleccion();
        } else {
            // Volver al menú
            volverAlInicio();
        }
    }
    
    /**
     * Muestra mensaje de juego completado
     */
    public void mostrarGameOver() {
        detenerGameLoop();
        JOptionPane.showMessageDialog(
            this,
            "¡Felicidades! Has completado todos los niveles\nPuntaje final: " + juego.getPuntaje(),
            "¡Juego Completado!",
            JOptionPane.INFORMATION_MESSAGE
        );
        volverAlInicio();
    }
    
    /**
     * Actualiza el estado del audio (llamado por el controlador)
     */
    public void actualizarEstadoAudio(boolean sonidoActivo, boolean musicaActiva) {
        // Pendiente por implementar cuando se agregue sistema de audio
        System.out.println("Audio - Sonido: " + sonidoActivo + ", Música: " + musicaActiva);
    }

   /*Metodo Main */ 
    public static void main(String[] args) {
        try {
            BadDopoCreamGUI frame = new BadDopoCreamGUI();
            frame.setVisible(true);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}