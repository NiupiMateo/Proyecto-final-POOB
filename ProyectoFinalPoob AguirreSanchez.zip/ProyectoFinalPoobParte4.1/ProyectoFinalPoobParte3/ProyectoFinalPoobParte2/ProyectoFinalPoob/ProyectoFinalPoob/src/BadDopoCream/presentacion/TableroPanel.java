package BadDopoCream.presentacion;


import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import BadDopoCream.dominio.Juego;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.Timer;
import java.awt.Graphics;
import java.awt.Graphics2D;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.tablero.TipoCelda;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.controladores.Controlador;
import BadDopoCream.dominio.componentes.obstaculos.Fogata;
import BadDopoCream.dominio.componentes.obstaculos.BaldosaCaliente;

/**
 * Panel donde se muestra el tablero del juego Bad Dopo Cream.
 * Aquí puedes agregar botones, textos, imágenes o dibujar con Shapes.
 * 
 * @author Camilo Aguirre-Mateo Sanchez 
 * versión 02/12/2025
 */
public class TableroPanel extends JPanel {

    private static final long serialVersionUID = 1L;

    /** Referencia a la lógica del juego */
    private Juego juego;

    /** Modo de juego activo */
    private String modoJuego;

    /** Controlador para manejar eventos */
    private Controlador controlador;

    /** Timer para actualizar el panel dinámicamente */
    private Timer timer;
    
    // Imágenes del tablero (las imágenes de frutas y helados se cargan en sus respectivas clases)
    private Image imgFondoTablero;
    private Image imgBloqueHielo;
    private Image imgFogata;
    private Image imgBaldosaCaliente;
    private Image imgTroll;
    private Image imgMaceta;
    private Image imgCalamarNaranja;
    private Image imgNarval;

    /**
     * Constructor del panel del tablero.
     * @param juego instancia del juego
     * @param modoJuego modo de juego seleccionado
     * @param controlador instancia del controlador para manejar eventos
     */
    public TableroPanel(Juego juego, String modoJuego, Controlador controlador) {
        this.juego = juego;
        this.modoJuego = modoJuego;
        this.controlador = controlador;

        setLayout(null);  // Usamos layout nulo para posicionar los componentes manualmente
        
        // Cargar imágenes necesarias personalizadas para el tablero
        cargarImagenes();
        
        // Botón para pausar el juego
        JButton botonPausar = new JButton("Pausar");
        botonPausar.setBounds(800, 11, 75, 25);
        botonPausar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.manejarEvento("PAUSAR_JUEGO");
            }
        });
        add(botonPausar);

        // Botón para reiniciar el juego
        JButton botonReiniciar= new JButton("Reiniciar");
        botonReiniciar.setBounds(800, 40, 75, 25);
        botonReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                controlador.manejarEvento("REINICIAR_JUEGO");
            }
        });
        add(botonReiniciar);
        
        JButton botonSonido = new JButton("Sonido");
        botonSonido.setBounds(800, 69, 75, 25);
        add(botonSonido);
        
        JButton botonMusica = new JButton("Musica");
        botonMusica.setBounds(800, 98, 75, 25);
        add(botonMusica);
        
        JButton botonVolver = new JButton("Volver");
        botonVolver.setBounds(800, 127, 75, 25);
        botonVolver.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int opcion = JOptionPane.showConfirmDialog(
                    TableroPanel.this,
                    "¿Estás seguro de que deseas volver al menú principal?",
                    "Confirmar",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE
                );
                if (opcion == JOptionPane.YES_OPTION) {
                    controlador.manejarEvento("VOLVER_INICIO");
                }
            }
        });
        add(botonVolver);
    
        
        JPanel panel_1 = new JPanel();
        panel_1.setBounds(0, 0, 10, 10);
        add(panel_1);
        

        
        botonMusica.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            }
        });
        
        // No agregamos un panel gris que tape el dibujo
        // El tablero se dibujará directamente en paintComponent
        // La información (tiempo, puntaje, frutas) se dibuja en paintComponent
        
        // Timer para actualizar el panel
        timer = new Timer(1000 / 60, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                repaint();
            }
        }); // 60 FPS
        timer.start();
    }
    
    /**
     * Carga las imágenes del tablero.
     * 
     * Nota: Las imágenes de frutas y helados se cargan automáticamente
     * en sus respectivas clases (Fruta.java y Helado.java).
     * 
     * Este método solo carga:
     * - Fondo del tablero (que incluye el iglú dibujado)
     * - Bloques de hielo
     * 
     * El iglú NO se dibuja porque ya está en la imagen de fondo.
     * Las celdas tipo IGLU solo bloquean el movimiento.
     */
    private void cargarImagenes() {
            try {
                java.net.URL url;
                
                // Carga el fondo del tablero (incluye el iglú dibujado)
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Tablerooo.jpeg");
                if (url != null) {
                    imgFondoTablero = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen de fondo no encontrada: Tablerooo.jpeg");
                }

                // Carga el bloque de hielo
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/bloqueHielo.jpeg");
                if (url != null) {
                    imgBloqueHielo = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: bloqueHielo.jpeg");
                }
                
                // Carga la fogata
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Fogata.png");
                if (url != null) {
                    imgFogata = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: Fogata.png");
                }
                
                // Carga la baldosa caliente
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/BaldosaCaliente.png");
                if (url != null) {
                    imgBaldosaCaliente = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: BaldosaCaliente.png");
                }
                
                // Carga enemigos
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Troll.png");
                if (url != null) {
                    imgTroll = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: Troll.png");
                }
                
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Maceta.png");
                if (url != null) {
                    imgMaceta = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: Maceta.png");
                }
                
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Calamar.png");
                if (url != null) {
                    imgCalamarNaranja = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: Calamar.png");
                }
                
                url = getClass().getResource("/BadDopoCream/presentacion/recursos/Narval.png");
                if (url != null) {
                    imgNarval = new ImageIcon(url).getImage();
                } else {
                    System.err.println("Imagen no encontrada: Narval.png");
                }

            } catch (Exception e) {
                System.err.println("Error cargando imágenes del tablero: " + e.getMessage());
                e.printStackTrace();
            }
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;

        // Calcular dimensiones del tablero primero
        Tablero tablero;
        if (juego != null) {
            tablero = juego.getTablero();
        } else {
            tablero = null;
        }
        int celdaSize = 40; // Tamaño de cada celda
        int offsetX = 120; // Offset X ajustado (horizontal - correcto)
        int offsetY = 40;  // Offset Y ajustado (vertical - movido hacia arriba)
        
        // Si tenemos tablero, calcular el tamaño exacto
        if (tablero != null) {
            int anchoTablero = tablero.getColumnas() * celdaSize; // 15 * 40 = 600
            int altoTablero = tablero.getFilas() * celdaSize;     // 12 * 40 = 480
            
            // Dibujar fondo del tablero con imagen ajustada al tamaño exacto del tablero
            if (imgFondoTablero != null) {
                // Ajustar la imagen de fondo para que coincida exactamente con las celdas
                g2d.drawImage(imgFondoTablero, offsetX, offsetY, anchoTablero, altoTablero, this);
            } else {
                // Fallback: dibujar fondo gris
                g2d.setColor(new Color(192, 192, 192));
                g2d.fillRect(offsetX, offsetY, anchoTablero, altoTablero);
            }
        } else {
            // Si no hay tablero aún, dibujar fondo por defecto
            if (imgFondoTablero != null) {
                g2d.drawImage(imgFondoTablero, offsetX, offsetY, 600, 480, this);
            } else {
                g2d.setColor(new Color(192, 192, 192));
                g2d.fillRect(offsetX, offsetY, 600, 480);
            }
        }

        // Verificación con logging
        if (juego == null) {
            g2d.setColor(Color.RED);
            g2d.drawString("Error: Juego es null", 300, 300);
            return;
        }
        
        if (tablero == null) {
            g2d.setColor(Color.RED);
            g2d.drawString("Esperando tablero...", 300, 300);
            return;
        }
        
        Celda[][] matriz = tablero.getMatriz();
        if (matriz == null) {
            g2d.setColor(Color.RED);
            g2d.drawString("Error: Matriz es null", 300, 300);
            return;
        }
        
        // Dibujar solo los bloques de hielo (el fondo ya tiene el diseño del tablero)
        for (int fila = 0; fila < tablero.getFilas(); fila++) {
            for (int col = 0; col < tablero.getColumnas(); col++) {
                Celda celda = matriz[fila][col];
                int x = offsetX + col * celdaSize;
                int y = offsetY + fila * celdaSize;

                    // Dibujar solo bloques de hielo (el iglú ya está en la imagen de fondo)
                    int tipoCelda = celda.getTipo().getTipo();
                    if (tipoCelda == TipoCelda.BLOQUE_HIELO) {
                        if (imgBloqueHielo != null) {
                            g2d.drawImage(imgBloqueHielo, x, y, celdaSize, celdaSize, this);
                        } else {
                            // Fallback: dibujar bloque de hielo con color
                            g2d.setColor(new Color(150, 220, 255));
                            g2d.fillRect(x, y, celdaSize, celdaSize);
                            g2d.setColor(Color.WHITE);
                            g2d.drawRect(x + 2, y + 2, celdaSize - 4, celdaSize - 4);
                        }
                    } else if (tipoCelda == TipoCelda.FOGATA) {
                        if (imgFogata != null) {
                            g2d.drawImage(imgFogata, x, y, celdaSize, celdaSize, this);
                        } else {
                            // Fallback: dibujar fogata con color
                            g2d.setColor(new Color(255, 69, 0));
                            g2d.fillRect(x, y, celdaSize, celdaSize);
                        }
                    } else if (tipoCelda == TipoCelda.BALDOSA_CALIENTE) {
                        if (imgBaldosaCaliente != null) {
                            g2d.drawImage(imgBaldosaCaliente, x, y, celdaSize, celdaSize, this);
                        } else {
                            // Fallback: dibujar baldosa caliente con color amarillo
                            g2d.setColor(new Color(255, 215, 0));
                            g2d.fillRect(x, y, celdaSize, celdaSize);
                        }
                    }
                    // Las celdas IGLU no dibujan nada - el iglú ya está en el fondo
                    // Solo bloquean el movimiento del jugador
                }
            }
            
            // Dibujar frutas
            if (tablero.getFrutas() != null) {
                for (BadDopoCream.dominio.componentes.frutas.Fruta fruta : tablero.getFrutas()) {
                    if (fruta.isActiva()) {
                        Posicion pos = fruta.getPosicion();
                        int x = offsetX + pos.getX() * celdaSize;
                        int y = offsetY + pos.getY() * celdaSize;
                        
                        // Dibujar imagen según tipo de fruta - Ahora cada fruta carga su propia imagen
                        String tipoFruta = fruta.getClass().getSimpleName();
                        Image imgFruta = fruta.getImagen();
                        
                        if (imgFruta != null) {
                            g2d.drawImage(imgFruta, x, y, celdaSize, celdaSize, this);
                        } else {
                            System.err.println("WARNING: Imagen NULL para fruta tipo: " + tipoFruta);
                            // Fallback: dibujar círculo con color
                            if (tipoFruta.equals("Uva")) {
                                g2d.setColor(new Color(148, 0, 211));
                            } else if (tipoFruta.equals("Platano")) {
                                g2d.setColor(new Color(255, 255, 0));
                            } else if (tipoFruta.equals("Pina")) {
                                g2d.setColor(new Color(255, 200, 0));
                            } else if (tipoFruta.equals("Cereza")) {
                                g2d.setColor(new Color(220, 20, 60));
                            }
                            g2d.fillOval(x + 8, y + 8, celdaSize - 16, celdaSize - 16);
                        }
                    }
                }
            }
            
            // Dibujar enemigos
            if (tablero.getEnemigos() != null) {
                for (BadDopoCream.dominio.componentes.enemigos.Enemigo enemigo : tablero.getEnemigos()) {
                    if (enemigo.isActiva()) {
                        Posicion pos = enemigo.getPosicion();
                        int x = offsetX + pos.getX() * celdaSize;
                        int y = offsetY + pos.getY() * celdaSize;
                        
                        // Dibujar imagen según tipo de enemigo
                        String tipoEnemigo = enemigo.getClass().getSimpleName();
                        Image imgEnemigo = null;
                        
                        if (tipoEnemigo.equals("Troll")) {
                            imgEnemigo = imgTroll;
                        } else if (tipoEnemigo.equals("Maceta")) {
                            imgEnemigo = imgMaceta;
                        } else if (tipoEnemigo.equals("CalamarNaranja")) {
                            imgEnemigo = imgCalamarNaranja;
                        } else if (tipoEnemigo.equals("Narval")) {
                            imgEnemigo = imgNarval;
                        }
                        
                        if (imgEnemigo != null) {
                            g2d.drawImage(imgEnemigo, x, y, celdaSize, celdaSize, this);
                        } else {
                            // Fallback: dibujar con color
                            if (tipoEnemigo.equals("Troll")) {
                                g2d.setColor(new Color(0, 128, 0)); // Verde
                            } else if (tipoEnemigo.equals("Maceta")) {
                                g2d.setColor(new Color(139, 69, 19)); // Marrón
                            } else if (tipoEnemigo.equals("CalamarNaranja")) {
                                g2d.setColor(new Color(255, 140, 0)); // Naranja
                            } else if (tipoEnemigo.equals("Narval")) {
                                g2d.setColor(new Color(100, 149, 237)); // Azul
                            }
                            g2d.fillRect(x + 5, y + 5, celdaSize - 10, celdaSize - 10);
                            g2d.setColor(Color.BLACK);
                            g2d.drawRect(x + 5, y + 5, celdaSize - 10, celdaSize - 10);
                        }
                    }
                }
            }
            
        // Dibujar el helado (jugador)
        if (tablero.getHelado() != null) {
            BadDopoCream.dominio.componentes.helados.Helado helado = tablero.getHelado();
            Posicion pos = helado.getPosicion();
            int x = offsetX + pos.getX() * celdaSize;
            int y = offsetY + pos.getY() * celdaSize;
            
            // Obtener la imagen del helado
            Image imgHelado = helado.getImagen();
            
            if (imgHelado != null) {
                g2d.drawImage(imgHelado, x, y, celdaSize, celdaSize, this);
            } else {
                // Fallback: dibujar círculo con color según tipo
                String nombreClase = helado.getClass().getSimpleName();
                if (nombreClase.equals("HeladoVainilla")) {
                    g2d.setColor(new Color(255, 248, 220));
                } else if (nombreClase.equals("HeladoChocolate")) {
                    g2d.setColor(new Color(139, 69, 19));
                } else if (nombreClase.equals("HeladoFresa")) {
                    g2d.setColor(new Color(255, 182, 193));
                }
                g2d.fillOval(x + 6, y + 6, celdaSize - 12, celdaSize - 12);
                g2d.setColor(Color.BLACK);
                g2d.drawOval(x + 6, y + 6, celdaSize - 12, celdaSize - 12);
            }
        }
        
        // Dibujar la información del juego en la parte superior
        g2d.setColor(Color.BLACK);
        g2d.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 14));
        
        if (juego != null) {
            // Puntaje
            g2d.drawString("Puntos: " + juego.getPuntaje(), 190, 28);
            
            // Tiempo
            if (juego.getTemporizador() != null) {
                g2d.drawString(juego.getTemporizador().getTiempoFormateado(), 460, 28);
            }
            
            // Frutas restantes
            g2d.drawString("Frutas: " + juego.getFrutasRestantes(), 320, 28);
        }
    }

    /**
     * Método opcional para detener animaciones o hilos si los tienes.
     */
    public void detener() {
        if (timer != null) {
            timer.stop();
        }
    }
    public static void main (String[] args) {
    }
}
