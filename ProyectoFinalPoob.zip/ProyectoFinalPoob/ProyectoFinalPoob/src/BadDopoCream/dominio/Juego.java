package BadDopoCream.dominio;

import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.utilidades.Temporizador;
import BadDopoCream.dominio.utilidades.EstadoJuego;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.componentes.helados.Helado;

/**
 * Clase Juego - ORQUESTADOR PRINCIPAL del juego.
 * Coordina: Tablero, Nivel, Temporizador, Estado.
 * Responsable de: iniciar juegos, actualizar lógica, verificar victoria/derrota,
 * procesar acciones del jugador (mover, crear/romper bloques, pausar).
 * Es el punto de entrada principal para el Controlador.
 */
public class Juego {
    private Tablero tablero;
    private Nivel nivelActual;
    private Temporizador temporizador;
    private EstadoJuego estado;
    private int numeroNivel;
    private String tipoHelado;
    private String modoJuego; // "PvsP", "PvsM", "MvsM"
    
    /**
     * Constructor del Juego
     */
    public Juego() {
        this.estado = new EstadoJuego(EstadoJuego.MENU);
        this.temporizador = new Temporizador();
        this.numeroNivel = 1;
    }
    
    /**
     * Inicia un nuevo juego
     * @param numeroNivel nivel a jugar (1, 2, 3)
     * @param tipoHelado tipo de helado elegido
     * @param modoJuego modo de juego
     */
    public void iniciarJuego(int numeroNivel, String tipoHelado, String modoJuego) {
        this.numeroNivel = numeroNivel;
        this.tipoHelado = tipoHelado;
        this.modoJuego = modoJuego;
        
        // Crear nivel y tablero
        nivelActual = new Nivel(numeroNivel);
        tablero = nivelActual.crearTablero(tipoHelado);
        
        // Iniciar temporizador
        temporizador.reiniciar();
        temporizador.iniciar();
        
        estado.setEstado(EstadoJuego.JUGANDO);
    }
    
    /**
     * Actualiza el estado del juego cada frame
     */
    public void actualizar() {
        if (estado.getEstado() != EstadoJuego.JUGANDO) return;
        
        // Actualizar temporizador
        temporizador.actualizar();
        
        // Actualizar tablero (enemigos, frutas)
        tablero.actualizar();
        
        // Verificar condiciones de victoria/derrota
        verificarEstadoJuego();
    }
    
    /**
     * Verifica las condiciones de victoria o derrota cada frame.
     * DERROTA si: 1) Se acaba el tiempo (3 minutos), 2) El helado toca un enemigo.
     * VICTORIA si: Se recolectaron todas las frutas.
     */
    private void verificarEstadoJuego() {
        // Verificar derrota por tiempo
        if (temporizador.seAcaboElTiempo()) {
            estado.setEstado(EstadoJuego.DERROTA);
            return;
        }
        
        // Verificar derrota por colisión con enemigo
        if (tablero.hayColisionConEnemigo()) {
            estado.setEstado(EstadoJuego.DERROTA);
            return;
        }
        
        // Verificar victoria (todas las frutas recolectadas)
        if (tablero.contarFrutasActivas() == 0) {
            estado.setEstado(EstadoJuego.VICTORIA);
            temporizador.pausar();
        }
    }
    
    /**
     * Mueve el helado en una dirección
     * @param direccion dirección de movimiento
     */
    public void moverHelado(Direccion direccion) {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null) {
            Helado helado = tablero.getHelado();
            if (helado != null) {
                helado.mover(direccion, tablero);
            }
        }
    }
    
    /**
     * Ejecuta la acción de bloque (tecla ESPACIO).
     * Si hay un bloque en la dirección actual -> ROMPE bloques (efecto dominó).
     * Si NO hay bloque -> CREA un bloque nuevo.
     */
    public void accionBloque() {
        if (estado.getEstado() == EstadoJuego.JUGANDO && tablero != null) {
            Helado helado = tablero.getHelado();
            if (helado != null) {
                Posicion posBloque = helado.getDireccion().mover(helado.getPosicion());
                
                if (tablero.hayBloqueEn(posBloque)) {
                    // Romper bloques
                    helado.romperBloques(tablero);
                } else {
                    // Crear bloque
                    helado.crearBloque(tablero);
                }
            }
        }
    }
    
    /**
     * Pausa o reanuda el juego
     */
    public void togglePausa() {
        if (estado.getEstado() == EstadoJuego.JUGANDO) {
            estado.setEstado(EstadoJuego.PAUSADO);
            temporizador.pausar();
        } else if (estado.getEstado() == EstadoJuego.PAUSADO) {
            estado.setEstado(EstadoJuego.JUGANDO);
            temporizador.iniciar();
        }
    }
    
    /**
     * Reinicia el nivel actual
     */
    public void reiniciarNivel() {
        iniciarJuego(numeroNivel, tipoHelado, modoJuego);
    }
    
    /**
     * Avanza al siguiente nivel
     */
    public void siguienteNivel() {
        if (numeroNivel < 3) {
            iniciarJuego(numeroNivel + 1, tipoHelado, modoJuego);
        } else {
            estado.setEstado(EstadoJuego.GAME_OVER);
        }
    }
    
    /**
     * Vuelve al menú principal
     */
    public void volverAlMenu() {
        estado.setEstado(EstadoJuego.MENU);
        temporizador.reiniciar();
    }
    
    // Getters
    
    public Tablero getTablero() {
        return tablero;
    }
    
    public EstadoJuego getEstado() {
        return estado;
    }
    
    public Temporizador getTemporizador() {
        return temporizador;
    }
    
    public int getNumeroNivel() {
        return numeroNivel;
    }
    
    public String getModoJuego() {
        return modoJuego;
    }
    
    public int getPuntaje() {
        if (tablero != null && tablero.getHelado() != null) {
            return tablero.getHelado().getPuntaje();
        }
        return 0;
    }
    
    public int getFrutasRestantes() {
        if (tablero != null) {
            return tablero.contarFrutasActivas();
        }
        return 0;
    }
}

