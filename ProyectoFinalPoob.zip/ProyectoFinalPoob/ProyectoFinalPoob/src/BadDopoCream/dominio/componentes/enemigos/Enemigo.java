package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.componentes.helados.Helado;

/**
 * Clase abstracta Enemigo - Representa los antagonistas del juego.
 * Los enemigos eliminan al helado si lo tocan.
 * Hay 3 tipos: Troll (patrón fijo), Maceta (persigue), Calamar Naranja (persigue y rompe bloques).
 * Cada enemigo tiene su propia velocidad y comportamiento de movimiento.
 */
public abstract class Enemigo extends Componente {
    protected Direccion direccion;
    protected int velocidad;
    protected boolean puedeRomperBloques;
    protected int contadorMovimiento;
    
    /**
     * Constructor de Enemigo
     * @param posicion posición inicial del enemigo
     * @param velocidad velocidad de movimiento (frames entre movimientos)
     * @param puedeRomperBloques si puede romper bloques de hielo
     */
    public Enemigo(Posicion posicion, int velocidad, boolean puedeRomperBloques) {
        super(posicion);
        this.velocidad = velocidad;
        this.puedeRomperBloques = puedeRomperBloques;
        this.contadorMovimiento = 0;
        this.direccion = new Direccion(Direccion.DERECHA);
    }
    
    /**
     * Verifica si el enemigo puede romper bloques
     * @return true si puede romper bloques
     */
    public boolean puedeRomperBloques() {
        return puedeRomperBloques;
    }
    
    /**
     * Rompe un bloque en la dirección actual (solo si puede)
     * @param tablero tablero del juego
     */
    public void romperBloque(Tablero tablero) {
        if (puedeRomperBloques) {
            Posicion posBloque = direccion.mover(posicion);
            if (tablero.hayBloqueEn(posBloque)) {
                tablero.eliminarBloqueEn(posBloque);
            }
        }
    }
    
    /**
     * Obtiene la dirección actual del enemigo
     * @return dirección actual
     */
    public Direccion getDireccion() {
        return direccion;
    }
    
    /**
     * Calcula el siguiente movimiento del enemigo
     * @param tablero tablero del juego
     * @param helado helado jugador
     */
    public abstract void calcularMovimiento(Tablero tablero, Helado helado);
}


