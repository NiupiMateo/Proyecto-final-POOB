package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.utilidades.Direccion;
import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.tablero.Celda;
import BadDopoCream.dominio.componentes.helados.Helado;
import java.util.Random;

/**
 * Enemigo Troll - Enemigo básico del nivel 1.
 * <p>
 * Comportamiento: Se mueve aleatoriamente por todo el mapa.
 * Cada vez que puede moverse, elige una dirección aleatoria.
 * Si encuentra un obstáculo (muro o bloque de hielo), elige otra dirección.
 * No persigue al jugador y no puede romper bloques de hielo.
 * Es el enemigo más impredecible pero no agresivo.
 * </p>
 * 
 * @author ProyectoFinalPoob
 * @version 2.0
 * @since 2025-11-24
 */
public class Troll extends Enemigo {
    private Random random;
    private Direccion[] direccionesPosibles;
    private int intentosMaximos;
    
    /**
     * Constructor de Troll.
     * <p>
     * Inicializa el enemigo con velocidad 15 (se mueve cada 15 frames)
     * y configura el generador de números aleatorios para movimiento.
     * </p>
     * 
     * @param posicion Posición inicial del Troll en el tablero
     */
    public Troll(Posicion posicion) {
        super(posicion, 15, false); // Velocidad 15, no rompe bloques
        this.random = new Random();
        // Array con las 4 direcciones posibles
        this.direccionesPosibles = new Direccion[]{
            new Direccion(Direccion.ARRIBA),
            new Direccion(Direccion.ABAJO),
            new Direccion(Direccion.IZQUIERDA),
            new Direccion(Direccion.DERECHA)
        };
        this.intentosMaximos = 10; // Intentos máximos para encontrar dirección válida
    }
    
    /**
     * Actualiza el contador de movimiento del Troll.
     * Se incrementa cada frame y se resetea cuando alcanza la velocidad.
     */
    @Override
    public void actualizar() {
        contadorMovimiento++;
    }
    
    /**
     * Calcula y ejecuta el movimiento aleatorio del Troll.
     * <p>
     * Algoritmo:
     * <ol>
     *   <li>Verifica si es momento de moverse (contador >= velocidad)</li>
     *   <li>Elige una dirección aleatoria de las 4 posibles</li>
     *   <li>Verifica si la nueva posición es válida y transitable</li>
     *   <li>Si es válida, mueve el Troll a esa posición</li>
     *   <li>Si no es válida, intenta otra dirección (hasta 10 intentos)</li>
     * </ol>
     * </p>
     * <p>
     * Este comportamiento hace que el Troll explore todo el mapa de forma
     * impredecible, pero sin perseguir activamente al jugador.
     * </p>
     * 
     * @param tablero Tablero del juego para validar movimientos
     * @param helado Helado del jugador (no se usa, el Troll no persigue)
     */
    @Override
    public void calcularMovimiento(Tablero tablero, Helado helado) {
        if (contadorMovimiento >= velocidad) {
            contadorMovimiento = 0;
            
            // Intentar moverse en una dirección aleatoria
            boolean movido = false;
            int intentos = 0;
            
            while (!movido && intentos < intentosMaximos) {
                // Elegir dirección aleatoria
                int indiceAleatorio = random.nextInt(direccionesPosibles.length);
                direccion = direccionesPosibles[indiceAleatorio];
                
                // Calcular nueva posición
                Posicion nuevaPos = direccion.mover(posicion);
                
                // Verificar si la posición es válida y transitable
                if (tablero.esPosicionValida(nuevaPos)) {
                    Celda celdaDestino = tablero.getCelda(nuevaPos);
                    if (celdaDestino != null && celdaDestino.esTransitable()) {
                        // Mover el Troll a la nueva posición
                        tablero.moverComponente(posicion, nuevaPos);
                        this.posicion = nuevaPos;
                        movido = true;
                    }
                }
                
                intentos++;
            }
            
            // Si después de todos los intentos no pudo moverse, se queda en su lugar
            // (esto puede pasar si está rodeado de muros o bloques de hielo)
        }
    }
    
    /**
     * Retorna el tipo de enemigo.
     * 
     * @return String "Troll"
     */
    @Override
    public String getTipo() {
        return "Troll";
    }
}


