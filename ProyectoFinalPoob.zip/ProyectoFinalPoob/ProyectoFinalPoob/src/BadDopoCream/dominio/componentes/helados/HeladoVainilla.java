package BadDopoCream.dominio.componentes.helados;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Helado de Vainilla.
 *
 * Es uno de los tres sabores disponibles para el jugador.
 * Su color característico es blanco cremoso.
 */
public class HeladoVainilla extends Helado {
    
    /**
     * Constructor del Helado de Vainilla.
     *
     * @param posicion posición inicial en el tablero
     */
    public HeladoVainilla(Posicion posicion) {
        super(posicion);
    }
    
    /**
     * Retorna el tipo de helado.
     *
     * @return "HeladoVainilla"
     */
    @Override
    public String getTipo() {
        return "HeladoVainilla";
    }
    
    /**
     * Retorna el color del helado.
     *
     * @return "Blanco"
     */
    @Override
    public String getColor() {
        return "blanco";
    }
}

