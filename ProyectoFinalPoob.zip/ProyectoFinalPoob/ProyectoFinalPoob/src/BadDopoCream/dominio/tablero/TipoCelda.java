package BadDopoCream.dominio.tablero;

/**
 * Clase TipoCelda - Define los tipos de contenido que puede tener una celda del tablero.
 * VACIO: Celda libre donde se puede mover
 * MURO: Obstáculo permanente (bordes del tablero)
 * BLOQUE_HIELO: Bloque creado por el helado (destruible)
 */
public class TipoCelda {
    public static final int VACIO = 0;
    public static final int MURO = 1;
    public static final int BLOQUE_HIELO = 2;
    
    private int tipo;
    
    /**
     * Constructor de TipoCelda
     * @param tipo tipo de celda (VACIO, MURO, BLOQUE_HIELO)
     */
    public TipoCelda(int tipo) {
        this.tipo = tipo;
    }
    
    /**
     * Obtiene el tipo de celda
     * @return tipo
     */
    public int getTipo() {
        return tipo;
    }
    
    /**
     * Establece el tipo de celda
     * @param tipo nuevo tipo
     */
    public void setTipo(int tipo) {
        this.tipo = tipo;
    }
    
    /**
     * Verifica si la celda está vacía
     * @return true si está vacía
     */
    public boolean esVacio() {
        return tipo == VACIO;
    }
    
    /**
     * Verifica si la celda es un muro
     * @return true si es muro
     */
    public boolean esMuro() {
        return tipo == MURO;
    }
    
    /**
     * Verifica si la celda es un bloque de hielo
     * @return true si es bloque de hielo
     */
    public boolean esBloqueHielo() {
        return tipo == BLOQUE_HIELO;
    }
}

