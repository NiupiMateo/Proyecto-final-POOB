package BadDopoCream.presentacion;


import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.JOptionPane;

import BadDopoCream.dominio.Juego;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

/**
 * Panel donde se muestra el tablero del juego Bad Dopo Cream.
 * Aquí puedes agregar botones, textos, imágenes o dibujar con Shapes.
 * 
 * @author (...)
 */
public class TableroPanel extends JPanel {

    private static final long serialVersionUID = 1L;

	private static final ActionListener ActionListener = null;

    /** Referencia a la lógica del juego */
    private Juego juego;

    /** Modo de juego activo */
    private String modoJuego;

    /** Referencia a la ventana principal */
    private BadDopoCreamGUI gui;

    /**
     * Constructor del panel del tablero.
     * @param juego instancia del juego
     * @param modoJuego modo de juego seleccionado
     * @param gui referencia a la ventana principal
     */
    public TableroPanel(Juego juego, String modoJuego, BadDopoCreamGUI gui) {
        this.juego = juego;
        this.modoJuego = modoJuego;
        this.gui = gui;

        setLayout(null);
        
        JButton botonPausar = new JButton("Pausar");
        botonPausar.setBounds(800, 11, 75, 25);
        add(botonPausar);
        
        JButton botonReiniciar= new JButton("Reiniciar");
        botonReiniciar.setBounds(800, 40, 75, 25);
        add(botonReiniciar);
        
        JButton botonSonido = new JButton("Sonido");
        botonSonido.setBounds(800, 69, 75, 25);
        add(botonSonido);
         
        JButton botonMusica = new JButton("Musica");
        botonMusica.setBounds(800, 98, 75, 25);
        add(botonMusica);
       
        // Botón para regresar a la pantalla de niveles
        JButton botonAtras = new JButton("Atrás");
        botonAtras.setBounds(800, 127, 75, 25);
        add(botonAtras);
        
        JPanel panel_1 = new JPanel();
        panel_1.setBounds(0, 0, 10, 10);
        add(panel_1);
        

        
        botonMusica.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        	}
        });
        
        
        JPanel panel = new JPanel();
        panel.setBackground(new Color(192, 192, 192));
        panel.setBounds(120, 61, 650, 500);
        add(panel);
        
        JLabel lblNewLabel = new JLabel("Objetivos");
        lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
        lblNewLabel.setVerticalAlignment(SwingConstants.BOTTOM);
        lblNewLabel.setBackground(new Color(0, 255, 255));
        lblNewLabel.setBounds(400, 700, 101, 25);
        add(lblNewLabel);
       
        JLabel lblNewLabel_1 = new JLabel("Tiempo");
        lblNewLabel_1.setBackground(new Color(128, 128, 128));
        lblNewLabel_1.setBounds(450, 11, 94, 19);
        add(lblNewLabel_1);
        
        JLabel lblNewLabel_1_1 = new JLabel("Puntaje");
        lblNewLabel_1_1.setBackground(new Color(128, 128, 128));
        lblNewLabel_1_1.setBounds(180, 11, 94, 19);
        add(lblNewLabel_1_1);
        

        botonPausar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(
                    null,
                    "¿Estás seguro que deseas pausar el juego?",
                    "Confirmar Pausa",
                    JOptionPane.YES_NO_OPTION
                );

                if (confirmar == JOptionPane.YES_OPTION) {
                  ;
                }
            }
        }); 	
               
        botonReiniciar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                int confirmar = JOptionPane.showConfirmDialog(
                    null,
                    "¿Estás seguro que deseas reiniciar el juego?",
                    "Confirmar Reinicio",
                    JOptionPane.YES_NO_OPTION
                );

                if (confirmar == JOptionPane.YES_OPTION) {
                  ;
                }
            }
        });

        botonSonido.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               
            }
        });

        botonMusica.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              
            }
        });
        
        botonAtras.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	int confirmar = JOptionPane.showConfirmDialog(
                        null,
                        "¿Estás seguro que deseas ir atras?",
                        "Confirmar",
                        JOptionPane.YES_NO_OPTION
                    );

                    if (confirmar == JOptionPane.YES_OPTION) {
                      ;
                    }
                gui.volverAlInicio(); // Asume que volverAlInicio lleva a la pantalla de niveles
            }
        });
    }

    /**
     * Método opcional para detener animaciones o hilos si los tienes.
     */
    public void detener() {
        // Aquí detienes timers o threads si los agregas luego.
    }
    public static void main (String[] args) {
	}
}
