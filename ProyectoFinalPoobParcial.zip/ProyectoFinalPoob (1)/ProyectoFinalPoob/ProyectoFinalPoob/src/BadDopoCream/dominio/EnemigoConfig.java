package BadDopoCream.dominio;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase EnemigoConfig - Configuración simple de un enemigo para un nivel.
 * Almacena el tipo de enemigo y su posición inicial.
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class EnemigoConfig {
    private String tipo;
    private Posicion posicion;
    
    /**
     * Constructor de EnemigoConfig
     * @param tipo tipo de enemigo (Troll, Maceta, CalamarNaranja)
     * @param posicion posición inicial del enemigo
     */
    public EnemigoConfig(String tipo, Posicion posicion) {
        this.tipo = tipo;
        this.posicion = posicion;
    }
    
    /**
     * Constructor alternativo con coordenadas
     * @param tipo tipo de enemigo
     * @param x coordenada x (columna)
     * @param y coordenada y (fila)
     */
    public EnemigoConfig(String tipo, int x, int y) {
        this.tipo = tipo;
        posicion = new Posicion(x, y);
    }
    
    /**
     * Obtiene el tipo de enemigo
     * @return tipo de enemigo
     */
    public String getTipo() {
        return tipo;
    }
    
    /**
     * Obtiene la posición del enemigo
     * @return posición inicial
     */
    public Posicion getPosicion() {
        return posicion;
    }
}
