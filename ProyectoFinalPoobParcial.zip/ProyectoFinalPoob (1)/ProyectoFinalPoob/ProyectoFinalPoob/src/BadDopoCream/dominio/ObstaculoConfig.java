package BadDopoCream.dominio;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase ObstaculoConfig - Configuración simple de un obstáculo para un nivel.
 * Almacena el tipo de obstáculo y su posición.
 * 
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class ObstaculoConfig {
    private String tipo;
    private Posicion posicion;
    
    /**
     * Constructor de ObstaculoConfig
     * @param tipo tipo de obstáculo (Fogata, BaldosaCaliente)
     * @param posicion posición del obstáculo
     */
    public ObstaculoConfig(String tipo, Posicion posicion) {
        this.tipo = tipo;
        this.posicion = posicion;
    }
    
    /**
     * Constructor alternativo con coordenadas
     * @param tipo tipo de obstáculo
     * @param x coordenada x (columna)
     * @param y coordenada y (fila)
     */
    public ObstaculoConfig(String tipo, int x, int y) {
        this.tipo = tipo;
        posicion = new Posicion(x, y);
    }
    
    /**
     * Obtiene el tipo de obstáculo
     * @return tipo de obstáculo
     */
    public String getTipo() {
        return tipo;
    }
    
    /**
     * Obtiene la posición del obstáculo
     * @return posición
     */
    public Posicion getPosicion() {
        return posicion;
    }
}
