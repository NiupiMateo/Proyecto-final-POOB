package BadDopoCream.dominio.componentes;

import BadDopoCream.dominio.utilidades.Posicion;
import java.awt.*;

/**
 * Clase base de cualquier objeto que pueda aparecer en el juego 
 * como helados, enemigos, frutas, etc..
 *
 *solo se maneja la parte de la logica, la posicion y si el componente esta vacio.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public abstract class Componente {

	protected Posicion posicion;
    
    protected boolean activa;
    
    protected Image imagen;
    
    /**
     * Constructor del Componente.
     * guarda la posicion inicial y deja el componente activo por defecto 
     * @param posicion posición inicial del componente en el tablero
     */
    public Componente(Posicion posicion) {
        this.posicion = posicion;
        this.activa = true;
    }
    
    /**
     * Obtiene la posición actual del componente.
     *
     * @return posición del componente en el tablero
     */
    public Posicion getPosicion() {
        return posicion;
    }
    
    /**
     * Verifica si el componente está activo.
     *
     * @return true si está activo, false si está inactivo
     */
    public boolean isActiva() {
        return activa;
    }
    
    /**
     * Actualiza el estado del componente.
     * Este método se llama en cada frame del juego.
     * Las subclases deben implementar su lógica específica.
     */
    public abstract void actualizar();
    
    /**
     * Obtiene el tipo de componente.
     *
     * @return cadena que identifica el tipo (para renderizado)
     */
    public abstract String getTipo();
    
    /**
     * Obtiene la imagen del componente.
     *
     * @return imagen del componente
     */
    public Image getImagen() {
        return imagen;
    }
}

