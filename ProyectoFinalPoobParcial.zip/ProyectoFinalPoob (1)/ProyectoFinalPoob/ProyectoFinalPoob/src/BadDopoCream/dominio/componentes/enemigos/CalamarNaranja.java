package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.componentes.helados.Helado;
import BadDopoCream.dominio.tablero.*;
import BadDopoCream.dominio.utilidades.*;

/**
 * Enemigo Calamar Naranja 
 * Persigue al helado Y puede romper bloques de hielo (uno a la vez).
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class CalamarNaranja extends Enemigo {
    
    /**
     * Constructor de CalamarNaranja
     * @param posicion posición inicial
     */
    public CalamarNaranja(Posicion posicion) {
        super(posicion, 15, true);
    }
 
     /**
      * Se ejecuta en cada frame del juego.
      * solamente se cuentan los passo para sbaer cuando moverlo 
      */
    @Override
    public void actualizar() {
        contadorMovimiento++;
    }
    
    /**
     * Calcula el próximo movimiento del Calamar Naranja basado en el tablero y la posición del helado.
     * Intenta moverse hacia el helado, rompiendo bloques de hielo si es necesario.
     * @param tablero tablero del juego
     * @param helado helado del jugador
     **/
    @Override
    public void calcularMovimiento(Tablero tablero, Helado helado) {
        if (contadorMovimiento >= velocidad) {
            contadorMovimiento = 0;
            
            Posicion posHelado = helado.getPosicion();
            int deltaX = posHelado.getX() - posicion.getX();
            int deltaY = posHelado.getY() - posicion.getY();
            
            // Priorizar movimiento en el eje con mayor distancia
            Direccion direccionPreferida;
            if (Math.abs(deltaX) > Math.abs(deltaY)) {
                if (deltaX > 0) {
                    direccionPreferida = new Direccion(Direccion.DERECHA);
                } else {
                    direccionPreferida = new Direccion(Direccion.IZQUIERDA);
                }
            } else {
                if (deltaY > 0) {
                    direccionPreferida = new Direccion(Direccion.ABAJO);
                } else {
                    direccionPreferida = new Direccion(Direccion.ARRIBA);
                }
            }
            
            //Prueba el movieminto principal
            Posicion nuevaPos = direccionPreferida.mover(posicion);
            
            if (tablero.esPosicionValida(nuevaPos)) {
                Celda celdaDestino = tablero.getCelda(nuevaPos);
                if (celdaDestino != null && celdaDestino.getTipo().esBloqueHielo()) {
                    // Rompe el bloque
                    this.direccion = direccionPreferida;
                    romperBloque(tablero);
                } else if (celdaDestino != null && celdaDestino.getTipo().esVacio()) {
                    // Moverse
                    tablero.moverComponente(posicion, nuevaPos);
                    this.posicion = nuevaPos;
                    this.direccion = direccionPreferida;
                }
            } else {
                // Intentar con la dirección alternativa
                Direccion direccionAlternativa;
                if (Math.abs(deltaX) > Math.abs(deltaY)) {
                    if (deltaY > 0) {
                        direccionAlternativa = new Direccion(Direccion.ABAJO);
                    } else {
                        direccionAlternativa = new Direccion(Direccion.ARRIBA);
                    }
                } else {
                    if (deltaX > 0) {
                        direccionAlternativa = new Direccion(Direccion.DERECHA);
                    } else {
                        direccionAlternativa = new Direccion(Direccion.IZQUIERDA);
                    }
                }
                
                nuevaPos = direccionAlternativa.mover(posicion);
                if (tablero.esPosicionValida(nuevaPos)) {
                    Celda celdaDest = tablero.getCelda(nuevaPos);
                    if (celdaDest != null && celdaDest.getTipo().esBloqueHielo()) {
                        this.direccion = direccionAlternativa;
                        romperBloque(tablero);
                    } else if (celdaDest != null && celdaDest.getTipo().esVacio()) {
                        tablero.moverComponente(posicion, nuevaPos);
                        this.posicion = nuevaPos;
                        this.direccion = direccionAlternativa;
                    }
                }
            }
        }
    }
    
    
    /**
     * Devuelve el nombre del enemigo para el render
     */
    @Override
    public String getTipo() {
        return "CalamarNaranja";
    }
}


