package BadDopoCream.dominio.componentes.enemigos;

import BadDopoCream.dominio.utilidades.*;
import BadDopoCream.dominio.tablero.*;
import BadDopoCream.dominio.componentes.helados.Helado;
import java.util.Random;
import javax.swing.*;

/**
 * Enemigo Troll - Enemigo básico del nivel 1.
 * Se mueve de forma completamente aleatoria.
 * Cada cierto tiempo elige una dirección y trata de avanzar.
 * No persigue al jugador y no puede romper bloques.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class Troll extends Enemigo {
    private Random random;
    private Direccion[] direccionesPosibles;
    private int intentosMaximos;
    
    /**
     * Constructor del Troll.
     * Se inicializa con velocidad 15 (se mueve cada 15 frames)
     * y se configuran las direcciones y el generador aleatorio.
     * @param posicion Posición inicial del Troll en el tablero
     */
    public Troll(Posicion posicion) {
        super(posicion, 15, false);
        random = new Random();
        // Array con las 4 direcciones posibles
        this.direccionesPosibles = new Direccion[]{
            new Direccion(Direccion.ARRIBA),
            new Direccion(Direccion.ABAJO),
            new Direccion(Direccion.IZQUIERDA),
            new Direccion(Direccion.DERECHA)
        };
        intentosMaximos = 10; // Intentos máximos para encontrar dirección válida
    }
    
    /**
     * Actualiza el contador de movimiento del Troll.
     * Se incrementa cada frame y se resetea cuando alcanza la velocidad.
     */
    @Override
    public void actualizar() {
        contadorMovimiento++;
    }
    
    /**
     * Calcula y realiza el movimiento aleatorio del Troll.
     * Solo se moverá cuando el contador llegue a la velocidad asignada.
     * 
     * Proceso:
     * - Revisa si ya puede moverse.
     * - Elige una dirección aleatoria.
     * - Comprueba si la celda a la que quiere ir es válida.
     * - Si puede moverse, actualiza su posición.
     * - Si no, intenta otra dirección hasta agotar los intentos.
     * @param tablero Tablero del juego para validar movimientos
     * @param helado Helado del jugador (no se usa, el Troll no persigue)
     */
    @Override
    public void calcularMovimiento(Tablero tablero, Helado helado) {
        if (contadorMovimiento >= velocidad) {
            contadorMovimiento = 0;
            
            // Intenta moverse en una dirección aleatoria
            boolean movido = false;
            int intentos = 0;
            
            while (!movido && intentos < intentosMaximos) {
                // Elige una dirección aleatoria
                int indiceAleatorio = random.nextInt(direccionesPosibles.length);
                direccion = direccionesPosibles[indiceAleatorio];
                
                // Calcula nueva posición
                Posicion nuevaPos = direccion.mover(posicion);
                
                // Verifica si la posición es válida y transitable
                if (tablero.esPosicionValida(nuevaPos)) {
                    Celda celdaDestino = tablero.getCelda(nuevaPos);
                    if (celdaDestino != null && celdaDestino.esTransitable()) {
                        // Mueve el Troll a la nueva posición
                        tablero.moverComponente(posicion, nuevaPos);
                        this.posicion = nuevaPos;
                        movido = true;
                    }
                }
                
                intentos++;
            }
        }
    }
    
    /**
     * Retorna el tipo de enemigo.
     * 
     * @return String "Troll"
     */
    @Override
    public String getTipo() {
        return "Troll";
    }
}


