package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.tablero.Tablero;
import BadDopoCream.dominio.utilidades.Posicion;
import java.util.Random;

/**
 * Fruta Cereza.
 *
 * Es la fruta más difícil de atrapar del nivel 3.
 * A diferencia de otras frutas, la Cereza se teletransporta
 * a posiciones aleatorias del tablero.
 *
 * Comportamiento:
 * - Cada 3 segundos (180 frames) se teletransporta.
 * - Aparece en una nueva posición vacía aleatoria.
 * - El jugador debe ser rápido para recolectarla.
 *
 * Otorga 150 puntos al ser recolectada.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class Cereza extends Fruta {
    private Random random;
    
    private int contadorTeletransporte;
    
    /** Tiempo entre teletransportes (20 segundos = 1200 frames a 60 FPS) */
    private static final int TIEMPO_TELETRANSPORTE = 1200;
    
    /**
     * Constructor de la Cereza.
     *
     * @param posicion posición inicial de la cereza en el tablero
     */
    public Cereza(Posicion posicion) {
        super(posicion, 150);
        random = new Random();
        contadorTeletransporte = 0;
    }
    
    /**
     * Actualiza el estado de la cereza.
     *
     * Incrementa el contador de teletransporte en cada frame.
     */
    @Override
    public void actualizar() {
        contadorTeletransporte++;
    }
    
    /**
     * Verifica si la cereza debe teletransportarse.
     *
     * @return true si ha pasado suficiente tiempo, false en caso contrario
     */
    public boolean debeTeletransportarse() {
        return contadorTeletransporte >= TIEMPO_TELETRANSPORTE;
    }
    
    /**
     * Teletransporta la cereza a una nueva posición aleatoria.
     *
     * Busca una posición vacía aleatoria en el tablero (hasta 100 intentos).
     * Si encuentra una posición válida, mueve la cereza y resetea el contador.
     *
     * @param tablero tablero del juego donde se teletransporta
     */
    public void teletransportar(Tablero tablero) {
      Posicion nuevaPos = null;
      // Intento de mazimo 100 veces para evitar bucles infinitos
      for (int i= 0; i <100; i++) {
    	  int x = random.nextInt(tablero.getColumnas());
    	  int y = random.nextInt(tablero.getFilas());
    	  
    	  Posicion posible = new Posicion (x,y);
    	  if (tablero.esPosicionVacia(posible)) {
    		  nuevaPos = posible;
    		  break;
    	  }
      }
      //si encuentra un ligar valido mueve la fruta
      if (nuevaPos != null) {
    	  tablero.moverComponente(posicion, nuevaPos);
    	  this.posicion = nuevaPos;
    	  contadorTeletransporte = 0 ; // se reinicia el tiempo
      }
    }
    
    /**
     * Retorna el tipo de fruta.
     *
     * @return "Cereza"
     */
    @Override
    public String getTipo() {
        return "Cereza";
    }
}


