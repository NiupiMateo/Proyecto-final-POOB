package BadDopoCream.dominio.componentes.frutas;

import BadDopoCream.dominio.componentes.Componente;
import BadDopoCream.dominio.utilidades.Posicion;
import BadDopoCream.dominio.tablero.Tablero;
import java.awt.Image;

/**
 * Clase abstracta Fruta.
 *
 * Representa todos los objetos recolectables del juego.
 * El jugador debe recolectar todas las frutas para ganar el nivel.
 *
 * Cada fruta otorga puntos al ser recolectada.
 *
 * Tipos de frutas:
 * - Estáticas: Uva y Plátano (nivel 1) - no se mueven.
 * - Móviles: Piña (nivel 2) - se mueve aleatoriamente.
 * - Teletransportables: Cereza (nivel 3) - cambia de posición aleatoriamente.
 */
public abstract class Fruta extends Componente {
    protected int puntaje;
    
    /**
     * Constructor de la Fruta.
     *
     * @param posicion posición inicial de la fruta en el tablero
     * @param puntaje cantidad de puntos que otorga al recolectarla
     */
    public Fruta(Posicion posicion, int puntaje) {
        super(posicion);
        this.puntaje = puntaje;
    }
    
    /**
     * Obtiene el puntaje que otorga la fruta.
     *
     * @return cantidad de puntos
     */
    public int getPuntaje() {
        return puntaje;
    }
    
    /**
     * Marca la fruta como recolectada.
     * Cambia su estado a inactivo para que no se renderice
     * ni se pueda volver a recolectar.
     */
    public void recolectar() {
        this.activa = false;
    }
}


