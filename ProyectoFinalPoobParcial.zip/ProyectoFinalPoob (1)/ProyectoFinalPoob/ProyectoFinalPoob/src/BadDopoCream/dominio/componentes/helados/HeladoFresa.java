package BadDopoCream.dominio.componentes.helados;

import BadDopoCream.dominio.utilidades.Posicion;
import javax.swing.*;

/**
 * Helado de Fresa.
 *
 * Es uno de los tres sabores disponibles para el jugador.
 * Su color característico es rosado.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class HeladoFresa extends Helado {
    
    /**
     * Constructor del Helado de Fresa.
     * @param posicion posición inicial en el tablero
     */
    public HeladoFresa(Posicion posicion) {
        super(posicion);
    }
    
    /**
     * Retorna el tipo de helado.
     * @return "HeladoFresa"
     */
    @Override
    public String getTipo() {
        return "HeladoFresa";
    }
    
    /**
     * Retorna el color del helado.
     * @return "rosado"
     */
    @Override
    public String getColor() {
        return "rosado";
    }
}


