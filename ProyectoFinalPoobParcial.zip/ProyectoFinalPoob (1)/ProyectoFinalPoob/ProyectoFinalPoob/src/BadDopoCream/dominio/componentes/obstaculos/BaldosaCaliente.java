package BadDopoCream.dominio.componentes.obstaculos;

import BadDopoCream.dominio.utilidades.Posicion;
import java.awt.*;
import javax.swing.*;

/**
 * Clase BaldosaCaliente - Obstáculo que derrite bloques de hielo.
 *
 * Las baldosas calientes derriten instantáneamente cualquier bloque
 * de hielo que se cree sobre ellas
 * @author Camilo Aguirre - Mateo Sanchez
 * @version 2025/12/06
 */
public class BaldosaCaliente {
    /** Posición de la baldosa caliente en el tablero */
    private Posicion posicion;
   
    /**
     * Constructor de BaldosaCaliente.
     *
     * @param posicion posición de la baldosa en el tablero
     */
    public BaldosaCaliente(Posicion posicion) {
        this.posicion = posicion;
    }
    
    /**
     * Obtiene la posición de la baldosa caliente.
     * @return posición
     */
    public Posicion getPosicion() {
        return posicion;
    }
}
