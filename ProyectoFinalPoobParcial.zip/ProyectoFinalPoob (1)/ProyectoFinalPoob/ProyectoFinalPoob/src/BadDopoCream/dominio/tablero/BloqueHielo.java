package BadDopoCream.dominio.tablero;

import BadDopoCream.dominio.utilidades.Posicion;

/**
 * Clase que representa un bloque de hielo creado por el helado.
 * Los bloques pueden ser destruidos por el helado (efecto dominó) o por ciertos enemigos.
 * Se usan como obstáculos y estrategia para atrapar enemigos.
 * @author Camilo Aguirre- Mateo Sanchez
 * @version 2025/06/12
 */
public class BloqueHielo {
    private Posicion posicion;
    private boolean destruible;
    
    /**
     * Constructor de BloqueHielo
     * @param posicion posición del bloque
     */
    public BloqueHielo(Posicion posicion) {
        this.posicion = posicion;
        destruible = true;
    }
    
    /**
     * Obtiene la posición del bloque
     * @return posición del bloque
     */
    public Posicion getPosicion() {
        return posicion;
    }
}


