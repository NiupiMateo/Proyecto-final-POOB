package BadDopoCream.dominio.utilidades;

/**
 * Clase que representa una posición (coordenadas X, Y) en el tablero del juego.
 * Se usa para ubicar helados, enemigos, frutas y bloques.
 *  @author Camilo Aguirre- Mateo Sanchez
 *  @version 2025/06/12
 */
public class Posicion {
    private int x;
    private int y;
    
    /**
     * Constructor de Posicion
     * @param x Coordenada horizontal
     * @param y Coordenada vertical
     */
    public Posicion(int x, int y) {
        this.x = x;
        this.y = y;
    }
    
    /**
     * Obtiene la coordenada X
     * @return coordenada X
     */
    public int getX() {
        return x;
    }
    
    /**
     * Obtiene la coordenada Y
     * @return coordenada Y
     */
    public int getY() {
        return y;
    }
    
    /**
     * Verifica si dos posiciones son iguales
     * @param obj objeto a comparar
     * @return true si las posiciones son iguales
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
        	return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
        	return false;
        }
        Posicion posicion = (Posicion) obj;
        return x == posicion.x && y == posicion.y;
    }
    
    /**
     * Calcula la distancia Manhattan entre dos posiciones
     * @param otra posición a comparar
     * @return distancia Manhattan
     */
    public int distancia(Posicion otra) {
        return Math.abs(this.x - otra.x) + Math.abs(this.y - otra.y);
    }
    
}

